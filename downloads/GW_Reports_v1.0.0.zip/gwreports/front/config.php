<?php
/** GW Reports administrative API configuration. */
include_once '../../../inc/includes.php';
require_once __DIR__ . '/../inc/common.php';
require_once __DIR__ . '/../inc/settings.php';
require_once __DIR__ . '/../inc/api.php';
gwreports_admin();
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Session::checkCSRF($_POST);
    try {
        if (($_POST['action'] ?? '') === 'save') {
            PluginGwreportsSettings::save($_POST);
            $message = 'Configurações salvas. As credenciais foram criptografadas pelo GLPI.';
        } elseif (($_POST['action'] ?? '') === 'test') {
            $message = PluginGwreportsApi::test();
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
$config = PluginGwreportsSettings::get();
$base = gwreports_base_url();
Html::header('GW Reports — Configuração', $_SERVER['PHP_SELF'], 'config', 'plugins');
echo '<div class="container mt-4 mb-5" style="max-width:1000px">';
echo '<h2>GW Reports — Configurações da API</h2>';
echo '<p class="text-muted">A API é opcional: os relatórios consultam diretamente o banco do GLPI local. A configuração abaixo permite testar a autenticação da API do ambiente.</p>';
if ($message !== '') {
    echo '<div class="alert alert-success">' . gwreports_e($message) . '</div>';
}
if ($error !== '') {
    echo '<div class="alert alert-danger">' . gwreports_e($error) . '</div>';
}
echo '<div class="card"><div class="card-body"><form method="post" action="' . gwreports_e($base . '/front/config.php') . '">';
echo '<input type="hidden" name="_glpi_csrf_token" value="' . gwreports_e(Session::getNewCSRFToken()) . '">';
echo '<input type="hidden" name="action" value="save">';
echo '<div class="mb-3"><label class="form-label" for="api-mode">Tipo de autenticação</label><select class="form-select" id="api-mode" name="api_mode">';
foreach (['oauth_password' => 'API v2.3 — OAuth2 (password grant)', 'legacy_basic' => 'API v1 — Basic + App-Token'] as $k => $v) {
    echo '<option value="' . $k . '"' . ($config['api_mode'] === $k ? ' selected' : '') . '>' . gwreports_e($v) . '</option>';
}
echo '</select></div>';
foreach ([
    'api_url' => ['URL da API', 'https://servidor/api.php/v2.3'],
    'api_username' => ['Usuário da API', 'Usuário técnico'],
    'api_client_id' => ['Client ID (OAuth2)', 'Client ID'],
] as $key => [$label, $placeholder]) {
    echo '<div class="mb-3"><label class="form-label" for="' . $key . '">' . gwreports_e($label) . '</label>';
    echo '<input class="form-control" type="text" id="' . $key . '" name="' . $key . '" placeholder="' . gwreports_e($placeholder) . '" value="' . gwreports_e((string) $config[$key]) . '" autocomplete="off"></div>';
}
foreach ([
    'api_password' => 'Senha do usuário da API',
    'api_client_secret' => 'Client Secret (OAuth2)',
    'api_app_token' => 'App-Token (API v1)',
] as $key => $label) {
    echo '<div class="mb-3"><label class="form-label" for="' . $key . '">' . gwreports_e($label) . '</label>';
    echo '<input class="form-control" type="password" id="' . $key . '" name="' . $key . '" placeholder="Deixe vazio para manter o segredo salvo" autocomplete="new-password">';
    echo '<div class="form-text">' . (!empty($config[$key]) ? 'Há um valor protegido salvo.' : 'Nenhum valor configurado.') . '</div></div>';
}
echo '<button class="btn btn-primary" type="submit">Salvar configuração</button>';
echo '</form><hr><form method="post" action="' . gwreports_e($base . '/front/config.php') . '">';
echo '<input type="hidden" name="_glpi_csrf_token" value="' . gwreports_e(Session::getNewCSRFToken()) . '">';
echo '<input type="hidden" name="action" value="test">';
echo '<button class="btn btn-outline-primary" type="submit">Testar conexão com a API</button></form>';
echo '</div></div>';
echo '<p class="mt-3"><a href="' . gwreports_e($base . '/front/report.php') . '">Voltar ao Relatório UST</a></p>';
echo '<p class="text-muted small">As credenciais não são exibidas, exportadas ou enviadas ao navegador após o salvamento. A configuração exige perfil com direito administrativo de Configuração.</p>';
echo '</div>';
Html::footer();
