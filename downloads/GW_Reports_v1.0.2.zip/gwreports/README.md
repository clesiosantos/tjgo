# GW Reports — Relatório UST

**Versão:** 1.0.0 (GLPI 11.0.x, PHP 8.2+)

**Autores:** GlobalWEB e Clesio Santos  
**Licença:** GPL-3.0-or-later

## Instalação

1. Faça backup do GLPI e do banco de dados.
2. Extraia `GW_Reports_v1.0.0.zip` na pasta `/caminho/do/glpi/plugins/`, resultando em `/caminho/do/glpi/plugins/gwreports/setup.php`.
3. Ajuste a propriedade/permissões do diretório conforme o usuário do serviço web (não use `chmod 777`).
4. Em **Configurar → Plugins**, localize **GW Reports**, instale e ative.
5. Abra **Ferramentas → Relatórios → Relatório UST** (o menu pode se chamar apenas *Relatórios*, dependendo do perfil).
6. Para configuração da API, use **Configurar → Plugins → GW Reports → Configurar** ou o link **Configuração da API** dentro do relatório.

O plugin não precisa de Composer, migrações ou tabelas próprias. Não cria nem altera chamados.

## Filtros

Data de **abertura** como referência, intervalos hoje, ontem, esta semana (segunda em diante), este mês, mês passado, últimos 15 dias, últimos 30 dias e datas personalizadas inclusivas. Filtros opcionais de status e grupo técnico atualmente atribuído. Não inclui chamados excluídos.

## Colunas

Número; título; status; grupo solucionador; abertura; fechamento; SLA TTO atendido; SLA TTR atendido; UST. A soma das USTs identificadas é exibida no rodapé, nos indicadores e nas exportações CSV/PDF.

## Regra dos indicadores de SLA

- **Sim**: há data real de atendimento (`takeintoaccountdate`) ou solução (`solvedate`, com fallback para `closedate`) antes ou no vencimento.
- **Não**: a data real excedeu o vencimento, ou o vencimento passou e a etapa não foi concluída.
- **Pendente**: a etapa não foi concluída e ainda não venceu.
- **N/A**: o prazo correspondente não foi definido no chamado.

Os prazos são lidos dos campos **`time_to_own`** e **`time_to_resolve`** já calculados pelo GLPI, que leva em consideração o calendário/SLA aplicado. O plugin não refaz cálculo de horas úteis. O status 'Não' não equivale automaticamente a penalidade contratual; exige verificação das pausas e critérios vigentes.

## UST — fonte e limitações

A UST é lida do campo adicional **`ustfield`** do plugin **Fields**, definido em **Categorias ITIL** (contêiner UST, ID 1 da POC TJ-GO). O plugin descobre a tabela dinâmica do Fields pelas colunas e lê `itemtype='ITILCategory'` e `items_id` correspondente à categoria do chamado.

- Cada chamado com categoria e UST identificada contribui uma UST **unitária** da categoria. UST é métrica de referência; a soma não representa faturamento aprovado.
- Chamados sem valor numérico UST são exibidos como `N/D` e **não entram** no total, mas aparecem no relatório.
- UST, status e grupo são os **valores atuais**. A categoria pode ter sido editada após a abertura; não há congelamento histórico nem multiplicação por quantidade efetivamente executada.
- O grupo é o **grupo técnico solucionador atualmente atribuído** (`glpi_groups_tickets.type=2`), não o que estava atribuído na abertura.

## CSV e PDF

- CSV UTF-8 com BOM, separador `;`, proteção contra interpretação de fórmulas em títulos/grupos.
- PDF A3 paisagem, com paginação, título, período, todos os registros e totalizador.
- O relatório limita a consulta a **10.000 chamados**. Se o filtro exceder o limite, solicita um intervalo menor (não exporta dados incompletos).

## Configuração da API

Tela exclusiva de administradores, com URL HTTPS, método **OAuth2 password (API v2.3)** ou **Basic+App-Token (API v1)**, usuário, senha, Client ID, Client Secret e App-Token. Senhas e tokens são gravados **criptografados** via `GLPIKey`/`glpicrypt.key`, não aparecem nos HTML, CSV, PDF ou ZIP. Campo de senha vazio mantém o valor salvo. O teste usa a configuração salva e valida autenticação (e, no modo OAuth, leitura de Ticket).

**Atenção:** os dados do relatório são lidos diretamente do banco **local** GLPI, respeitando o escopo de entidades ativas. A API configurável é uma integração opcional para autenticação/diagnóstico; ela **não substitui a fonte local**. Isso evita consultas remotas por ticket e preserva os campos de UST que não fazem parte da API de alto nível.

## Segurança

- Somente perfis com direito **Configuração: Atualizar** podem visualizar, exportar ou configurar o relatório nesta versão. Isso evita acesso indevido por um SQL agregado que contorna permissões individuais de chamados.
- A saída CSV/PDF exige sessão GLPI autenticada e permissão administrativa; configurações POST exigem CSRF.
- O filtro é validado e o SQL somente leitura é limitado às entidades selecionadas na sessão.
- Não há credenciais de demonstração, `.env` ou chaves privadas no pacote.

## Verificações da POC

Antes de considerar implantado, verifique em GLPI 11.0.12: entrada em **Relatórios**, autenticação e teste da API, status/grupo/períodos, UST da categoria 952 (1), indicadores SLA dos chamados de teste, exportação CSV/PDF e restrição de acesso. A sintaxe foi validada em PHP 8.4; execução integrada no GLPI real ainda depende da instalação.

## Atualização e remoção

O ZIP deve sempre ser descompactado com a pasta raiz `gwreports/` (não `GW Reports/`). Na desinstalação pelo GLPI, o plugin remove suas configurações e segredos, mas não altera tabelas do GLPI nem do Fields.


## v1.0.2
Aceita HTTP 206 paginado na consulta de teste OAuth e identifica explicitamente o banco local como origem dos dados do relatÃ³rio. A API configurada nÃ£o substitui a consulta local.
