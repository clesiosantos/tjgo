<?php
/** GW Reports installs without custom tables; it reads existing GLPI and Fields tables. */
function plugin_gwreports_install(): bool
{
    return true;
}
function plugin_gwreports_uninstall(): bool
{
    // Delete API secrets upon uninstall. No data from GLPI tickets or Fields is touched.
    (new Config())->deleteByCriteria(['context' => 'plugin:gwreports']);
    return true;
}
