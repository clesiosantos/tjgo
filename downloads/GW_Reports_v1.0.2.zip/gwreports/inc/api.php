<?php
/** Minimal outbound test against configured API; never logs credentials/tokens. */
final class PluginGwreportsApi
{
    private static function request(string $url, string $verb, array $headers, ?string $body = null): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('A extensão PHP cURL não está habilitada no servidor.');
        }
        $ch = curl_init($url);
        if ($ch === false) {
            throw new RuntimeException('Falha ao preparar chamada HTTP.');
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_TIMEOUT => 15,
            CURLOPT_CUSTOMREQUEST => $verb, CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_MAXREDIRS => 0,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $data = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($data === false) {
            throw new RuntimeException('Falha de conexão HTTP: ' . $error);
        }
        $decoded = json_decode((string) $data, true);
        return [$code, is_array($decoded) ? $decoded : null];
    }

    /** GLPI v2.3 paginates lists and may respond with 206 Partial Content. */
    public static function validTicketListStatus(int $status, ?array $decoded): bool
    {
        if (!in_array($status, [200, 206], true) || $decoded === null) {
            return false;
        }
        // GLPI list endpoints normally return a JSON array; empty is valid.
        if (array_is_list($decoded)) {
            return true;
        }
        // Accept an explicitly wrapped list for API deployments that use it.
        return isset($decoded['data']) && is_array($decoded['data'])
            && array_is_list($decoded['data']);
    }

    public static function test(): string
    {
        if (!PluginGwreportsSettings::configured()) {
            throw new RuntimeException('Preencha primeiro a URL da API e as credenciais requeridas.');
        }
        $c = PluginGwreportsSettings::get();
        $input = rtrim((string) $c['api_url'], '/');
        if (!preg_match('~^(https://[^/?#]+(?:/[^?#]*)?)/api\.php(?:/v\d+(?:\.\d+)?)?$~i', $input, $m)) {
            throw new RuntimeException('Informe a URL até /api.php/v2.3 ou /api.php/v1.');
        }
        $apiBase = $m[1] . '/api.php';
        if ($c['api_mode'] === 'oauth_password') {
            [$status, $token] = self::request($apiBase . '/token', 'POST',
                ['Accept: application/json', 'Content-Type: application/x-www-form-urlencoded'],
                http_build_query([
                    'grant_type' => 'password', 'client_id' => $c['api_client_id'],
                    'client_secret' => $c['api_client_secret'],
                    'username' => $c['api_username'], 'password' => $c['api_password'],
                    'scope' => 'api',
                ]));
            if ($status !== 200 || !is_array($token) || empty($token['access_token'])) {
                throw new RuntimeException('A autenticação OAuth2 não foi aceita. HTTP ' . $status . '.');
            }
            [$verify, $ticketList] = self::request($apiBase . '/v2.3/Assistance/Ticket?limit=1', 'GET',
                ['Accept: application/json', 'Authorization: Bearer ' . $token['access_token']]);
            if (!self::validTicketListStatus($verify, $ticketList)) {
                throw new RuntimeException('Token recebido, mas a leitura de chamados não retornou uma lista JSON válida. HTTP ' . $verify . '.');
            }
            return 'Conexão OAuth2 confirmada e leitura de chamados autorizada (HTTP ' . $verify . '). ' .
                'Este é um teste de acesso: os dados do Relatório UST continuam vindo do GLPI local.';
        }
        [$status, $data] = self::request($apiBase . '/v1/initSession', 'GET', [
            'Accept: application/json',
            'Authorization: Basic ' . base64_encode($c['api_username'] . ':' . $c['api_password']),
            'App-Token: ' . $c['api_app_token'],
        ]);
        if ($status !== 200 || empty($data['session_token'])) {
            throw new RuntimeException('A autenticação API v1 não foi aceita. HTTP ' . $status . '.');
        }
        // Invalidate temporary session token; do not display it.
        self::request($apiBase . '/v1/killSession', 'GET', [
            'Accept: application/json', 'Session-Token: ' . $data['session_token'],
            'App-Token: ' . $c['api_app_token'],
        ]);
        return 'Conexão à API legada v1 confirmada (HTTP 200).';
    }
}
