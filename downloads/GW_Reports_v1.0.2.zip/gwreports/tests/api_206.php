<?php
require_once __DIR__ . '/../inc/api.php';
$cases = [
    [200, [], true], [206, [], true],
    [200, [['id' => 8]], true], [206, [['id' => 8]], true],
    [206, ['data' => [['id' => 8]]], true],
    [206, null, false], [401, [], false], [403, [], false], [500, [], false],
    [206, ['message' => 'error'], false],
];
foreach ($cases as [$status, $body, $expected]) {
    if (PluginGwreportsApi::validTicketListStatus($status, $body) !== $expected) {
        fwrite(STDERR, "Falha para HTTP $status\n");
        exit(1);
    }
}
echo "OK: HTTP 200/206 e 8 cenarios invalidos/validos\n";
