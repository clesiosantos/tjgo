<?php
require_once __DIR__ . '/../inc/api.php';
foreach ([[200, [], true], [206, [], true], [206, [['id'=>8]], true], [206, null, false], [401, [], false], [206, ['error'=>'bad'], false]] as [$code, $data, $expected]) {
    if (PluginGwreportsApi::validTicketListStatus($code, $data) !== $expected) {
        exit(1);
    }
}
echo "OK API HTTP 206
";
