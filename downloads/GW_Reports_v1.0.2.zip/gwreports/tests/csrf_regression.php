<?php
/** Regression: GLPI 11 middleware owns CSRF validation for POST forms. */
$root = dirname(__DIR__);
$config = file_get_contents($root . '/front/config.php');
if (strpos($config, 'Session::checkCSRF(') !== false) {
    fwrite(STDERR, "FAIL: duplicate manual CSRF validation\n"); exit(1);
}
if (substr_count($config, 'name="_glpi_csrf_token"') !== 2) {
    fwrite(STDERR, "FAIL: two protected POST forms required\n"); exit(1);
}
if (strpos($config, "gwreports_admin();") === false) {
    fwrite(STDERR, "FAIL: admin permission guard missing\n"); exit(1);
}
if (strpos($config, "if (\$_SERVER['REQUEST_METHOD'] === 'POST')") === false) {
    fwrite(STDERR, "FAIL: POST guard missing\n"); exit(1);
}
echo "OK: GLPI 11 CSRF handling, POST forms and permissions\n";
