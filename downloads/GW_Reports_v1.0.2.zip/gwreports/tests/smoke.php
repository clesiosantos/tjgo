<?php
/** Stand-alone smoke tests. Run: php tests/smoke.php */
require_once __DIR__ . '/../inc/filters.php';
require_once __DIR__ . '/../inc/pdf.php';
function check(bool $ok, string $name): void
{
    if (!$ok) {
        fwrite(STDERR, "FALHA: $name\n");
        exit(1);
    }
    echo "OK: $name\n";
}
$now = new DateTimeImmutable('2026-11-11 13:00:00', new DateTimeZone('America/Sao_Paulo'));
$f = PluginGwreportsFilters::parse(['period' => 'today'], $now);
check($f['start'] === '2026-11-11' && $f['end'] === '2026-11-11', 'Hoje');
$f = PluginGwreportsFilters::parse(['period' => 'yesterday'], $now);
check($f['start'] === '2026-11-10' && $f['end'] === '2026-11-10', 'Ontem');
$f = PluginGwreportsFilters::parse(['period' => 'this_week'], $now);
check($f['start'] === '2026-11-09' && $f['end'] === '2026-11-11', 'Semana inicia segunda');
$f = PluginGwreportsFilters::parse(['period' => 'this_month'], $now);
check($f['start'] === '2026-11-01', 'Este mês');
$f = PluginGwreportsFilters::parse(['period' => 'last_month'], $now);
check($f['start'] === '2026-10-01' && $f['end'] === '2026-10-31', 'Mês passado');
$f = PluginGwreportsFilters::parse(['period' => 'last_15'], $now);
check($f['start'] === '2026-10-28', '15 dias inclusivos');
$f = PluginGwreportsFilters::parse(['period' => 'last_30'], $now);
check($f['start'] === '2026-10-13', '30 dias inclusivos');
$f = PluginGwreportsFilters::parse(['period' => 'custom', 'start'=>'2026-10-01', 'end'=>'2026-11-01'], $now);
check($f['start_sql'] === '2026-10-01 00:00:00' && $f['end_exclusive_sql'] === '2026-11-02 00:00:00', 'Intervalo personalizado inclusivo');
foreach ([['start'=>'2026-02-31','end'=>'2026-03-01'],['start'=>'2026-11-11','end'=>'2026-10-01']] as $bad) {
    try {
        PluginGwreportsFilters::parse(array_merge(['period'=>'custom'], $bad), $now);
        check(false, 'Datas inválidas rejeitadas');
    } catch (InvalidArgumentException $e) {
        check(true, 'Datas inválidas rejeitadas');
    }
}
check(PluginGwreportsFilters::sla('2026-11-11 11:00:00', '2026-11-11 10:00:00') === 'Sim', 'SLA atendido');
check(PluginGwreportsFilters::sla('2026-11-11 11:00:00', '2026-11-11 12:00:00') === 'Não', 'SLA vencido');
check(PluginGwreportsFilters::sla('2026-11-11 16:00:00', null, '2026-11-11 12:00:00') === 'Pendente', 'SLA em andamento');
check(PluginGwreportsFilters::sla(null, null) === 'N/A', 'SLA não configurado');
check(PluginGwreportsFilters::ust('1') === 1.0, 'UST 1');
check(PluginGwreportsFilters::ust('1,5') === 1.5, 'UST decimal BR');
check(PluginGwreportsFilters::ust('abc') === null, 'UST inválida não estimada');
$rows = [];
for ($i=1; $i<=85; $i++) {
    $rows[] = ['id'=>$i, 'title'=>'Solicitação de configuração — Chamado com acentuação',
        'status'=>'Solucionado','group'=>'POC TJGO - Solucionadores N1','opened'=>'2026-11-11 08:10:00',
        'closed'=>'2026-11-11 10:00:00','tto'=>'Sim','ttr'=>'Sim','ust'=>1.0];
}
$pdf = PluginGwreportsPdf::make(['rows'=>$rows,'total_ust'=>85.0,'with_ust'=>85,'without_ust'=>0], $f);
check(str_starts_with($pdf, '%PDF-1.4'), 'PDF válido: cabeçalho');
check(substr_count($pdf, '/Type /Page /Parent') === 3, 'PDF multipágina');
check(str_contains($pdf, 'TOTAL UST IDENTIFICADA'), 'PDF com totalizador');
file_put_contents('/tmp/gwreports_smoketest.pdf', $pdf);
echo "Testes concluídos. PDF: /tmp/gwreports_smoketest.pdf\n";
