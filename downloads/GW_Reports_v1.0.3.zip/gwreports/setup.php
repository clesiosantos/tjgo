<?php
/** GW Reports — GlobalWEB / Clesio Santos — GPL-3.0-or-later. */
if (!defined('PLUGIN_GWREPORTS_VERSION')) {
    define('PLUGIN_GWREPORTS_VERSION', '1.0.3');
}

function plugin_init_gwreports(): void
{
    global $PLUGIN_HOOKS;
    $PLUGIN_HOOKS['csrf_compliant']['gwreports'] = true;
    if (!Plugin::isPluginActive('gwreports')) {
        return;
    }
    // GLPI 11: native Tools > Reports selector; no extra forms or menu duplicates.
    if (Session::haveRight(Config::$rightname, UPDATE)) {
        $PLUGIN_HOOKS['reports']['gwreports'] = ['front/report.php' => 'Relatório UST'];
        $PLUGIN_HOOKS['config_page']['gwreports'] = 'front/config.php';
    }
}

function plugin_version_gwreports(): array
{
    return [
        'name'         => 'GW Reports',
        'version'      => PLUGIN_GWREPORTS_VERSION,
        'author'       => 'GlobalWEB e Clesio Santos',
        'license'      => 'GPLv3+',
        'homepage'     => '',
        'requirements' => [
            'glpi' => ['min' => '11.0.0', 'max' => '11.0.99'],
            'php'  => ['min' => '8.2'],
        ],
    ];
}

function plugin_gwreports_check_prerequisites(): bool
{
    return version_compare(GLPI_VERSION, '11.0.0', '>=')
        && version_compare(GLPI_VERSION, '11.1.0', '<')
        && version_compare(PHP_VERSION, '8.2.0', '>=');
}

function plugin_gwreports_check_config($verbose = false): bool
{
    // API settings are optional: the report uses the local GLPI database.
    return true;
}
