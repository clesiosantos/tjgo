# GW Reports — Relatório UST

**Versão:** 1.0.3 (GLPI 11.0.x, PHP 8.2+)

**Autores:** GlobalWEB e Clesio Santos  
**Licença:** GPL-3.0-or-later

## Instalação

1. Faça backup do GLPI e do banco de dados.
2. Extraia `GW_Reports_v1.0.3.zip` na pasta `/caminho/do/glpi/plugins/`, resultando em `/caminho/do/glpi/plugins/gwreports/setup.php`.
3. Ajuste a propriedade/permissões do diretório conforme o usuário do serviço web (não use `chmod 777`).
4. Em **Configurar → Plugins**, localize **GW Reports**, instale e ative.
5. Abra **Ferramentas → Relatórios → Relatório UST** (o menu pode se chamar apenas *Relatórios*, dependendo do perfil).
6. Para configuração da API, use **Configurar → Plugins → GW Reports → Configurar** ou o link **Configuração da API** dentro do relatório.

O plugin não precisa de Composer, migrações ou tabelas próprias. Não cria nem altera chamados.

## Filtros

Data de **abertura** como referência, intervalos hoje, ontem, esta semana (segunda em diante), este mês, mês passado, últimos 15 dias, últimos 30 dias e datas personalizadas inclusivas. Filtros opcionais de status e grupo técnico atualmente atribuído. Não inclui chamados excluídos.

## Colunas

Chamado; título; **Categoria ITIL**; status; grupo solucionador; abertura; solucionado; fechamento; SLA TTO atendido; SLA TTR atendido; UST. A soma das USTs identificadas é exibida no rodapé, nos indicadores e nas exportações CSV/PDF.

## Regra dos indicadores de SLA

- **Sim**: há data real de atendimento (`takeintoaccountdate`) ou solução (`solvedate`, com fallback para `closedate`) antes ou no vencimento.
- **Não**: a data real excedeu o vencimento, ou o vencimento passou e a etapa não foi concluída.
- **Pendente**: a etapa não foi concluída e ainda não venceu.
- **N/A**: o prazo correspondente não foi definido no chamado.
- **N/D**: a API remota não forneceu os dados necessários para aferir o SLA (não significa descumprimento).

Os prazos são lidos dos campos **`time_to_own`** e **`time_to_resolve`** já calculados pelo GLPI, que leva em consideração o calendário/SLA aplicado. O plugin não refaz cálculo de horas úteis. O status 'Não' não equivale automaticamente a penalidade contratual; exige verificação das pausas e critérios vigentes.

## UST — fonte e limitações

A UST é lida do campo adicional **`ustfield`** do plugin **Fields**, definido em **Categorias ITIL** (contêiner UST, ID 1 da POC TJ-GO). O plugin descobre a tabela dinâmica do Fields pelas colunas e lê `itemtype='ITILCategory'` e `items_id` correspondente à categoria do chamado.

- Cada chamado com categoria e UST identificada contribui uma UST **unitária** da categoria. UST é métrica de referência; a soma não representa faturamento aprovado.
- Chamados sem valor numérico UST são exibidos como `N/D` e **não entram** no total, mas aparecem no relatório.
- UST, status e grupo são os **valores atuais**. A categoria pode ter sido editada após a abertura; não há congelamento histórico nem multiplicação por quantidade efetivamente executada.
- O grupo é o **grupo técnico solucionador atualmente atribuído** (`glpi_groups_tickets.type=2`), não o que estava atribuído na abertura.

## CSV e PDF

- CSV UTF-8 com BOM, separador `;`, proteção contra interpretação de fórmulas em títulos/grupos.
- PDF A3 paisagem, com paginação, título, período, todos os registros e totalizador.
- O relatório limita a consulta a **10.000 chamados**. Se o filtro exceder o limite, solicita um intervalo menor (não exporta dados incompletos).

## Configuração da API

Tela exclusiva de administradores, com URL HTTPS, método **OAuth2 password (API v2.3)** ou **Basic+App-Token (API v1)**, usuário, senha, Client ID, Client Secret e App-Token. Senhas e tokens são gravados **criptografados** via `GLPIKey`/`glpicrypt.key`, não aparecem nos HTML, CSV, PDF ou ZIP. Campo de senha vazio mantém o valor salvo. O teste usa a configuração salva e valida autenticação (e, no modo OAuth, leitura de Ticket).

**Origem dos dados:** escolha **GLPI local** ou **API remota v2.3** no Relatório UST. No modo local, as consultas SQL continuam respeitando as entidades ativas. No modo remoto, os chamados e grupos são consultados pela API com as permissões do usuário OAuth2 configurado; as exportações seguem a mesma origem. A API v2.3 não expõe diretamente o campo `ustfield` e os vencimentos SLA; para enriquecer esses valores, configure App-Token v1 autorizado ou um mapeamento de contingência UST no campo administrativo (sem atribuir prazos SLA presumidos).

## Segurança

- Somente perfis com direito **Configuração: Atualizar** podem visualizar, exportar ou configurar o relatório nesta versão. Isso evita acesso indevido por um SQL agregado que contorna permissões individuais de chamados.
- A saída CSV/PDF exige sessão GLPI autenticada e permissão administrativa; configurações POST exigem CSRF.
- O filtro é validado e o SQL somente leitura é limitado às entidades selecionadas na sessão.
- Não há credenciais de demonstração, `.env` ou chaves privadas no pacote.

## Verificações da POC

Antes de considerar implantado, verifique em GLPI 11.0.12: entrada em **Relatórios**, autenticação e teste da API, status/grupo/períodos, UST da categoria 952 (1), indicadores SLA dos chamados de teste, exportação CSV/PDF e restrição de acesso. A sintaxe foi validada em PHP 8.4; execução integrada no GLPI real ainda depende da instalação.

## Atualização e remoção

O ZIP deve sempre ser descompactado com a pasta raiz `gwreports/` (não `GW Reports/`). Na desinstalação pelo GLPI, o plugin remove suas configurações e segredos, mas não altera tabelas do GLPI nem do Fields.

## Correção v1.0.1 (GLPI 11)

- Corrige o erro `Glpi\Exception\Http\AccessDeniedHttpException` no POST da tela de configuração.
- O GLPI 11 valida automaticamente `_glpi_csrf_token` no `CheckCsrfListener`; o plugin não realiza segunda validação do token já consumido.
- Os formulários de configuração continuam usando `method=post` e campo oculto `_glpi_csrf_token`.
- A permissão administrativa `Session::checkRight(Config::$rightname, UPDATE)` permanece obrigatória.
- Atualização de arquivos sobre a versão anterior sem desinstalação nem perda de configurações.
- Atualização preparada em ambiente local; verificar salvar/testar conexão no GLPI real após publicar o patch.

## Correção v1.0.2 — API paginada e origem dos dados

- Aceita **HTTP 200 ou 206 Partial Content** na listagem de chamados da API v2.3, validando que a resposta seja uma lista JSON. A API pode paginar a listagem mesmo com `limit=1`.
- A tela de configuração e o relatório deixam explícito que a consulta é ao **banco local**. A configuração da API externa é apenas um teste de autenticação/leitura e **não** replica os chamados da POC para o GLPI de homologação.
- Nenhuma credencial é exibida ou incluída no ZIP.
- O relatório remoto completo exigirá outro mecanismo de consulta para categoria ITIL, UST (plugin Fields) e vínculo de grupos; não se deve atribuir UST ao chamado por suposição.


## v1.0.3 — Fonte de dados remota

O relatório contém o seletor **Origem dos dados: GLPI local / API remota v2.3**. Com API remota, usa OAuth2 e consulta GET /Assistance/Ticket e GET /Administration/Group, com paginação, filtro de data de abertura e status. O CSV e o PDF respeitam a mesma origem. O limite é 10.000 chamados (reduzir período quando excedido). A UST é obtida pelo campo `ustfield` do plugin Fields via API v1, quando se configurar também um App-Token com direito de leitura; caso contrário, pode usar um **mapeamento manual de contingência** por ID de categoria, com aviso na tela. Os SLAs são calculados quando datas de vencimento estão disponíveis via API v1; caso contrário, `N/D` sinaliza falta de dados, sem presumir cumprimento. A URL remota não é aplicada à instalação local.

**Segurança:** credenciais criptografadas com GLPIKey, HTTPS obrigatório, sem redirect, requisições de leitura, filtros vinculados à conta da API, validação de respostas e limite de registros. A API v1 é opcional, usando usuário/senha e App-Token da configuração. Todas as consultas são realizadas sob as permissões do usuário técnico da API remota.


## v1.0.4 — data real de atendimento x histórico

- Distingue data nativa de atendimento (GLPI) e primeira atribuição registrada nos logs.
- Caso o GLPI não forneça `take_into_account_date`, consulta (somente leitura) o histórico v1 para confirmar atribuição antes do prazo.
- Se não houver evidência cronológica suficiente, mostra N/D e não inventa atraso.
- `resolution_date` é o prazo de solução, não a data de solução real (`date_solve`).
- Data/hora exibida no formato brasileiro sem conversão silenciosa de fuso.
- A estatística nativa do GLPI pode permanecer pendente mesmo quando o histórico permite classificar o TTO como cumprido; relatório sinaliza a fonte.


## v1.0.5 — Categoria ITIL no Relatório UST

- Adiciona a coluna **Categoria ITIL** à interface web, ao CSV e ao PDF, para ambas as origens (banco local e API remota).
- Consulta local obtém o nome/hierarquia em `glpi_itilcategories`, associando pelo `itilcategories_id`.
- Consulta remota obtém a categoria do objeto `category` do chamado da API v2.3. Ausência de categoria é indicada como `Sem categoria`; ID existente sem nome é exibido como `Categoria #ID`.
- Não altera os SLAs, valores de UST, regra de negócio nem estatísticas do GLPI.
- A regra de negócio atribui o SLA e define os vencimentos. `take_into_account_date` depende de um evento de atendimento processado pelo GLPI; `date_solve` somente é preenchido após solução. Chamados atribuídos automaticamente na abertura podem necessitar de atuação de técnico autorizado para preencher o indicador nativo. O relatório preserva evidência do histórico quando o campo nativo estiver ausente, sem editar o chamado.
