<?php
/** GW Reports — native Reports menu entry. */
include_once '../../../inc/includes.php';
require_once __DIR__ . '/../inc/common.php';
gwreports_require_libs();
gwreports_admin();

global $DB;
$error = '';
$report = ['rows' => [], 'total_ust' => 0, 'with_ust' => 0, 'without_ust' => 0];
try {
    $filters = PluginGwreportsFilters::parse($_GET);
    if ($filters['source'] === 'remote') {
        $repo = new PluginGwreportsRemote();
    } else {
        $repo = new PluginGwreportsRepository($DB);
    }
    $groups = $repo->groups();
    $report = $repo->report($filters);
} catch (Throwable $ex) {
    $error = $ex->getMessage();
    $filters = PluginGwreportsFilters::parse(['source' => ($_GET['source'] ?? 'local') === 'remote' ? 'remote' : 'local']);
    $groups = [];
}

Html::header('GW Reports — Relatório UST', $_SERVER['PHP_SELF'], 'tools', 'report');
$base = gwreports_base_url();
$exportParams = $filters;
unset($exportParams['start_sql'], $exportParams['end_exclusive_sql']);
$csv = $base . '/front/export.php?' . gwreports_qs(array_merge($exportParams, ['format' => 'csv']));
$pdf = $base . '/front/export.php?' . gwreports_qs(array_merge($exportParams, ['format' => 'pdf']));

echo '<div class="container-fluid mt-4 mb-5" style="max-width:1600px">';
echo '<div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-4">';
echo '<div class="d-flex align-items-center gap-3"><img src="https://pbs.twimg.com/profile_images/598117247329112066/wHppHY9-_400x400.png" alt="Logomarca" width="54" height="54" loading="lazy" style="object-fit:contain;border-radius:8px"><div><h2 class="h3 mb-1">Relatório UST</h2><div class="text-muted">GW Reports · GlobalWEB e Clesio Santos · Referência: data de abertura do chamado</div></div></div>';
echo '<div><a class="btn btn-outline-secondary" href="' . gwreports_e($base . '/front/config.php') . '">Configuração da API</a></div>';
echo '</div>';
echo '<div class="alert alert-info py-2" role="status">Origem selecionada: <strong>' . ($filters['source'] === 'remote' ? 'API remota v2.3' : 'GLPI local') . '</strong>. Os dados e as exportações são gerados pela origem selecionada.</div>';
foreach (($report['warnings'] ?? []) as $warning) {
    echo '<div class="alert alert-warning py-2">' . gwreports_e((string) $warning) . '</div>';
}
if ($error !== '') {
    echo '<div class="alert alert-danger" role="alert">' . gwreports_e($error) . '</div>';
}
echo '<div class="card shadow-sm mb-3"><div class="card-body">';
echo '<form method="get" action="' . gwreports_e($base . '/front/report.php') . '">';
echo '<div class="row g-3 align-items-end">';
echo '<div class="col-lg-3 col-md-6"><label class="form-label" for="gw-source">Origem dos dados</label><select class="form-select" id="gw-source" name="source">';
foreach (['local' => 'GLPI local', 'remote' => 'API remota v2.3'] as $key => $label) {
    echo '<option value="' . $key . '"' . ($filters['source'] === $key ? ' selected' : '') . '>' . gwreports_e($label) . '</option>';
}
echo '</select></div>';
echo '<div class="col-lg-2 col-md-4"><label for="gw-period" class="form-label">Período</label><select class="form-select" name="period" id="gw-period">';
foreach (PluginGwreportsFilters::PERIODS as $v => $label) {
    echo '<option value="' . gwreports_e($v) . '"' . ($filters['period'] === $v ? ' selected' : '') . '>' . gwreports_e($label) . '</option>';
}
echo '</select></div>';
echo '<div class="col-lg-2 col-md-4"><label class="form-label" for="gw-start">Data inicial</label><input class="form-control" id="gw-start" name="start" type="date" value="' . gwreports_e($filters['start']) . '"></div>';
echo '<div class="col-lg-2 col-md-4"><label class="form-label" for="gw-end">Data final</label><input class="form-control" id="gw-end" name="end" type="date" value="' . gwreports_e($filters['end']) . '"></div>';
echo '<div class="col-lg-2 col-md-4"><label class="form-label" for="gw-status">Status</label><select class="form-select" id="gw-status" name="status">';
foreach (PluginGwreportsFilters::STATUS as $id => $label) {
    echo '<option value="' . $id . '"' . ($filters['status'] === $id ? ' selected' : '') . '>' . gwreports_e($label) . '</option>';
}
echo '</select></div>';
echo '<div class="col-lg-3 col-md-5"><label class="form-label" for="gw-group">Grupo técnico solucionador</label><select class="form-select" id="gw-group" name="group"><option value="0">Todos os grupos</option>';
foreach ($groups as $group) {
    $id = (int) $group['id'];
    echo '<option value="' . $id . '"' . ($filters['group'] === $id ? ' selected' : '') . '>' . gwreports_e((string) $group['name']) . '</option>';
}
echo '</select></div>';
echo '<div class="col-lg-1 col-md-3"><button type="submit" class="btn btn-primary w-100">Filtrar</button></div>';
echo '</div></form></div></div>';
echo '<div class="row g-3 mb-3">';
echo '<div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Chamados</div><div class="fs-2 fw-bold">' . count($report['rows']) . '</div></div></div></div>';
echo '<div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Total de UST identificadas</div><div class="fs-2 fw-bold">' . number_format((float) $report['total_ust'], 2, ',', '.') . '</div></div></div></div>';
echo '<div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Chamados com UST</div><div class="fs-2 fw-bold">' . $report['with_ust'] . '</div></div></div></div>';
echo '<div class="col-md-3"><div class="card"><div class="card-body"><div class="text-muted">Sem UST na categoria</div><div class="fs-2 fw-bold">' . $report['without_ust'] . '</div></div></div></div>';
echo '</div>';
echo '<div class="card shadow-sm"><div class="card-header d-flex justify-content-between flex-wrap gap-2 align-items-center"><strong>Chamados encontrados</strong><div>';
echo '<a class="btn btn-outline-success btn-sm me-2" href="' . gwreports_e($csv) . '">Exportar CSV</a>';
echo '<a class="btn btn-outline-danger btn-sm" href="' . gwreports_e($pdf) . '">Exportar PDF</a>';
echo '</div></div><div class="table-responsive"><table class="table table-striped table-hover table-sm align-middle mb-0">';
echo '<thead><tr><th>Chamado</th><th>Título</th><th>Categoria ITIL</th><th>Status</th><th>Grupo solucionador</th><th>Abertura</th><th>Solucionado</th><th>Fechamento</th><th>SLA TTO</th><th>SLA TTR</th><th class="text-end">UST</th></tr></thead><tbody>';
foreach (array_slice($report['rows'], 0, 250) as $r) {
    $ticketUrl = $filters['source'] === 'remote' && isset($repo) && $repo instanceof PluginGwreportsRemote
        ? $repo->ticketUrl((int) $r['id'])
        : rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/front/ticket.form.php?id=' . (int) $r['id'];
    echo '<tr><td><a href="' . gwreports_e($ticketUrl) . '">#' . $r['id'] . '</a></td>';
    foreach (['title', 'category', 'status', 'group', 'opened', 'solved', 'closed', 'tto', 'ttr'] as $key) {
        $display = in_array($key, ['opened', 'solved', 'closed'], true)
            ? PluginGwreportsFilters::displayDate((string) ($r[$key] ?? ''))
            : (string) (($r[$key] ?? '') ?: '—');
        if (in_array($key, ['tto', 'ttr'], true)) {
            $colors = ['Sim' => 'bg-success text-white', 'Não' => 'bg-danger text-white',
                'Pendente' => 'bg-warning text-dark', 'N/A' => 'bg-secondary text-white',
                'N/D' => 'bg-light text-dark border'];
            $title = $key === 'tto' ? (string) ($r['tto_source'] ?? '') : '';
            $color = $colors[$display] ?? 'bg-light text-dark';
            $display = '<span class="badge ' . $color . '" title="' . gwreports_e($title) . '">'
                . gwreports_e(PluginGwreportsFilters::upperStatus($display)) . '</span>';
            echo '<td>' . $display . '</td>';
        } else {
            echo '<td>' . gwreports_e($display) . '</td>';
        }
    }
    echo '<td class="text-end">' . ($r['ust'] === null ? '<span class="text-muted">N/D</span>' : number_format((float) $r['ust'], 2, ',', '.')) . '</td></tr>';
}
if (!$report['rows']) {
    echo '<tr><td colspan="11" class="text-muted text-center p-4">Nenhum chamado encontrado para os filtros selecionados.</td></tr>';
}
echo '</tbody><tfoot><tr class="fw-bold"><td colspan="10" class="text-end">TOTAL DE UST IDENTIFICADAS</td><td class="text-end">' . number_format((float) $report['total_ust'], 2, ',', '.') . '</td></tr></tfoot></table></div>';
if (count($report['rows']) > 250) {
    echo '<div class="card-footer text-muted">Exibindo os 250 primeiros registros. CSV e PDF exportam todos os ' . count($report['rows']) . ' chamados do filtro.</div>';
}
echo '</div><div class="text-muted small mt-3" style="line-height:1.8">';
echo '<div><strong>UST:</strong> valor unitário vigente na Categoria ITIL (plugin Fields, campo ustfield). Um chamado = uma unidade de serviço. Valores ausentes não são estimados.</div>';
echo '<div><strong>SLA:</strong> <span class="badge bg-success">SIM</span> cumprimento comprovado; <span class="badge bg-danger">NÃO</span> prazo ultrapassado; <span class="badge bg-warning text-dark">PENDENTE</span> prazo vigente sem conclusão; <span class="badge bg-secondary">N/A</span> sem SLA; <span class="badge bg-light text-dark border">N/D</span> dados insuficientes.</div>';
echo '<div><strong>TTO:</strong> quando a data nativa não existe, o relatório pode validar uma atribuição anterior ao vencimento usando histórico da API v1. Isso não altera a estatística oficial do GLPI. Posicione o cursor sobre o indicador para ver a fonte.</div>';
echo '<div><strong>Datas:</strong> dd/mm/aaaa hh:mm, preservando o horário apresentado pela origem. Os filtros consideram a data de abertura; grupos e UST refletem o cadastro atual.</div>';
echo '</div></div>';
Html::footer();
