<?php
/** Deterministic time range/filter validation; local server timezone is used. */
final class PluginGwreportsFilters
{
    public const STATUS = [
        0 => 'Todos os status',
        1 => 'Novo',
        2 => 'Em atendimento (atribuído)',
        3 => 'Em atendimento (planejado)',
        4 => 'Pendente',
        5 => 'Solucionado',
        6 => 'Fechado',
        10 => 'Aprovação',
    ];
    public const PERIODS = [
        'today' => 'Hoje', 'yesterday' => 'Ontem', 'this_week' => 'Esta semana',
        'this_month' => 'Este mês', 'last_month' => 'Mês passado',
        'last_15' => 'Últimos 15 dias', 'last_30' => 'Últimos 30 dias',
        'custom' => 'Período personalizado',
    ];

    public static function parse(array $input, ?DateTimeImmutable $now = null): array
    {
        $now = $now ?? new DateTimeImmutable('now');
        $base = $now->setTime(0, 0, 0);
        $period = (string) ($input['period'] ?? 'this_month');
        if (!array_key_exists($period, self::PERIODS)) {
            throw new InvalidArgumentException('Período inválido.');
        }
        $start = $base;
        $end = $base->modify('+1 day');
        switch ($period) {
            case 'today': break;
            case 'yesterday': $start = $base->modify('-1 day'); $end = $base; break;
            case 'this_week': $start = $base->modify('-' . ((int) $base->format('N') - 1) . ' days'); break;
            case 'this_month': $start = $base->modify('first day of this month'); break;
            case 'last_month':
                $start = $base->modify('first day of previous month');
                $end = $base->modify('first day of this month');
                break;
            case 'last_15': $start = $base->modify('-14 days'); break;
            case 'last_30': $start = $base->modify('-29 days'); break;
            case 'custom':
                $a = (string) ($input['start'] ?? '');
                $b = (string) ($input['end'] ?? '');
                foreach ([$a, $b] as $d) {
                    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/D', $d)) {
                        throw new InvalidArgumentException('Informe data inicial e final em AAAA-MM-DD.');
                    }
                    $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $d, $now->getTimezone());
                    if (!$dt || $dt->format('Y-m-d') !== $d) {
                        throw new InvalidArgumentException('Data inválida: ' . $d);
                    }
                }
                $start = new DateTimeImmutable($a . ' 00:00:00', $now->getTimezone());
                $end = (new DateTimeImmutable($b . ' 00:00:00', $now->getTimezone()))->modify('+1 day');
                break;
        }
        if ($end <= $start) {
            throw new InvalidArgumentException('A data final precisa ser igual ou posterior à inicial.');
        }
        if ($end->getTimestamp() - $start->getTimestamp() > 10 * 366 * 86400) {
            throw new InvalidArgumentException('O intervalo não pode ultrapassar dez anos.');
        }
        $source = (string) ($input['source'] ?? 'local');
        if (!in_array($source, ['local', 'remote'], true)) {
            throw new InvalidArgumentException('Origem de dados inválida.');
        }
        $status = filter_var($input['status'] ?? 0, FILTER_VALIDATE_INT);
        if ($status === false || !array_key_exists($status, self::STATUS)) {
            throw new InvalidArgumentException('Status inválido.');
        }
        $group = filter_var($input['group'] ?? 0, FILTER_VALIDATE_INT);
        if ($group === false || $group < 0) {
            throw new InvalidArgumentException('Grupo inválido.');
        }
        return [
            'source' => $source, 'period' => $period, 'status' => $status, 'group' => $group,
            'start' => $start->format('Y-m-d'),
            'end' => $end->modify('-1 day')->format('Y-m-d'),
            'start_sql' => $start->format('Y-m-d H:i:s'),
            'end_exclusive_sql' => $end->format('Y-m-d H:i:s'),
        ];
    }

    public static function sla(?string $due, ?string $actual, ?string $now = null): string
    {
        if ($due === null || $due === '' || $due === '0000-00-00 00:00:00') {
            return 'N/A';
        }
        $dueTime = strtotime($due);
        if ($dueTime === false) {
            return 'N/A';
        }
        if ($actual !== null && $actual !== '' && $actual !== '0000-00-00 00:00:00') {
            $actualTime = strtotime($actual);
            return $actualTime !== false && $actualTime <= $dueTime ? 'Sim' : 'Não';
        }
        $nowTime = strtotime($now ?? date('Y-m-d H:i:s'));
        return $nowTime > $dueTime ? 'Não' : 'Pendente';
    }

    /** Display the date/hour fields without silently changing their timezone. */
    public static function upperStatus(string $status): string
    {
        return match ($status) {
            'Sim' => 'SIM', 'Não' => 'NÃO', 'Pendente' => 'PENDENTE',
            default => strtoupper($status),
        };
    }

    public static function displayDate(?string $raw): string
    {
        if (!$raw || $raw === '0000-00-00 00:00:00') {
            return '—';
        }
        if (preg_match('/^(\d{4})-(\d\d)-(\d\d)[T ](\d\d):(\d\d)/', $raw, $m)) {
            return $m[3] . '/' . $m[2] . '/' . $m[1] . ' ' . $m[4] . ':' . $m[5];
        }
        return $raw;
    }

    public static function ust($value): ?float
    {
        if ($value === null) {
            return null;
        }
        $value = trim((string) $value);
        if ($value === '') {
            return null;
        }
        $value = str_replace(',', '.', $value);
        if (!preg_match('/^\d+(?:\.\d+)?$/D', $value)) {
            return null;
        }
        $number = (float) $value;
        return is_finite($number) ? $number : null;
    }
}
