<?php
/** GW Reports: read-only remote GLPI 11 API v2.3 adapter. */
final class PluginGwreportsRemote
{
    private array $config;
    private string $base;
    private string $token = '';
    private ?string $legacyToken = null;
    private bool $legacyAttempted = false;
    private array $warnings = [];
    private array $groupCache = [];
    private $httpTransport = null;
    private const PAGE_SIZE = 100;
    private const MAX_TICKETS = 10000;
    private const MAX_GROUPS = 2000;
    private const MAX_ENRICHED_TICKETS = 75;
    private const MAX_ENRICHED_CATEGORIES = 100;

    public function __construct(?array $config = null, ?callable $httpTransport = null)
    {
        $this->config = $config ?? PluginGwreportsSettings::get();
        $this->httpTransport = $httpTransport;
        $ready = !empty($this->config['api_url']) && !empty($this->config['api_username'])
            && !empty($this->config['api_password']) && !empty($this->config['api_client_id'])
            && !empty($this->config['api_client_secret']);
        if (!$ready || $this->config['api_mode'] !== 'oauth_password') {
            throw new RuntimeException('Para a consulta remota, configure a API v2.3 OAuth2 em Configuração da API.');
        }
        $url = rtrim((string) $this->config['api_url'], '/');
        if (!preg_match('~^(https://[^/?#]+(?:/[^?#]*)?)/api\.php(?:/v\d+(?:\.\d+)?)?$~iD', $url, $m)) {
            throw new RuntimeException('URL remota inválida: informe HTTPS até /api.php/v2.3.');
        }
        $this->base = $m[1];
    }

    public function ticketUrl(int $id): string
    {
        return $this->base . '/front/ticket.form.php?id=' . $id;
    }

    private function request(string $path, array $headers = [], string $method = 'GET', ?string $body = null): array
    {
        if ($this->httpTransport !== null) {
            return ($this->httpTransport)($path, $headers, $method, $body);
        }
        if (!extension_loaded('curl')) {
            throw new RuntimeException('A extensão PHP cURL é necessária para a consulta remota.');
        }
        $url = $this->base . '/api.php' . $path;
        $ch = curl_init($url);
        if ($ch === false) {
            throw new RuntimeException('Falha ao iniciar consulta HTTPS.');
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => array_merge(['Accept: application/json'], $headers),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_MAXREDIRS => 0,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $response = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        if ($response === false) {
            throw new RuntimeException('Falha no acesso HTTPS ao GLPI remoto: ' . $error);
        }
        if (strlen($response) > 12000000) {
            throw new RuntimeException('Resposta remota excede o limite seguro. Reduza o período.');
        }
        $decoded = json_decode($response, true);
        return [$code, is_array($decoded) ? $decoded : null];
    }

    public static function listData(int $status, ?array $payload, string $context): array
    {
        if (!in_array($status, [200, 206], true) || $payload === null) {
            throw new RuntimeException('Falha na listagem remota de ' . $context . ' (HTTP ' . $status . ').');
        }
        $list = array_is_list($payload) ? $payload : ($payload['data'] ?? null);
        if (!is_array($list) || !array_is_list($list)) {
            throw new RuntimeException('Listagem remota de ' . $context . ' não retornou uma lista JSON.');
        }
        return $list;
    }

    private function auth(): void
    {
        if ($this->token !== '') {
            return;
        }
        [$status, $response] = $this->request('/token', ['Content-Type: application/x-www-form-urlencoded'], 'POST',
            http_build_query([
                'grant_type' => 'password',
                'client_id' => $this->config['api_client_id'],
                'client_secret' => $this->config['api_client_secret'],
                'username' => $this->config['api_username'],
                'password' => $this->config['api_password'],
                'scope' => 'api',
            ]));
        if ($status !== 200 || empty($response['access_token']) || !is_string($response['access_token'])) {
            throw new RuntimeException('Não foi possível autenticar na API v2.3 (HTTP ' . $status . ').');
        }
        $this->token = $response['access_token'];
    }

    private function v2(string $path): array
    {
        $this->auth();
        return $this->request('/v2.3' . $path, [
            'Authorization: Bearer ' . $this->token,
            'Accept-Language: pt_BR',
        ]);
    }

    /** Strictly bounded pagination; no partial report when the safety cap is reached. */
    private function collect(string $path, string $context, int $cap): array
    {
        $out = [];
        for ($offset = 0; $offset <= $cap; $offset += self::PAGE_SIZE) {
            $url = $path . (str_contains($path, '?') ? '&' : '?') . http_build_query([
                'start' => $offset, 'limit' => self::PAGE_SIZE,
            ], '', '&', PHP_QUERY_RFC3986);
            [$code, $payload] = $this->v2($url);
            $batch = self::listData($code, $payload, $context);
            foreach ($batch as $record) {
                if (!is_array($record)) {
                    throw new RuntimeException('Registro remoto malformado em ' . $context . '.');
                }
                $out[] = $record;
            }
            if (count($out) > $cap) {
                throw new RuntimeException('Limite de ' . $cap . ' registros remotos excedido. Reduza o período.');
            }
            if (count($batch) < self::PAGE_SIZE) {
                return $out;
            }
        }
        throw new RuntimeException('Limite de paginação remota atingido. Reduza o período.');
    }

    public function groups(): array
    {
        if ($this->groupCache) {
            return $this->groupCache;
        }
        try {
            $groups = $this->collect('/Administration/Group', 'grupos', self::MAX_GROUPS);
        } catch (RuntimeException $e) {
            $this->warnings[] = 'Lista de grupos remota indisponível para este usuário da API; os chamados ainda poderão ser consultados.';
            return [];
        }
        $out = [];
        foreach ($groups as $item) {
            $id = (int) ($item['id'] ?? 0);
            if ($id > 0) {
                $out[$id] = ['id' => $id, 'name' => (string) ($item['name'] ?? ('Grupo ' . $id))];
            }
        }
        uasort($out, static fn (array $a, array $b) => strcasecmp($a['name'], $b['name']));
        return $this->groupCache = array_values($out);
    }

    /** Interpret only team members of type Group with role assigned. */
    public static function assignedGroups(array $ticket): array
    {
        $groups = [];
        foreach (($ticket['team'] ?? []) as $member) {
            if (!is_array($member)
                || strcasecmp((string) ($member['type'] ?? ''), 'Group') !== 0
                || strcasecmp((string) ($member['role'] ?? ''), 'assigned') !== 0) {
                continue;
            }
            $id = (int) ($member['id'] ?? 0);
            if ($id > 0) {
                $groups[$id] = (string) ($member['name'] ?? ('Grupo ' . $id));
            }
        }
        return $groups;
    }

    private static function idOf($v): int
    {
        if (is_array($v)) {
            return (int) ($v['id'] ?? 0);
        }
        return is_numeric($v) ? (int) $v : 0;
    }

    public static function statusId(array $ticket): int
    {
        return self::idOf($ticket['status'] ?? null);
    }

    public static function opened(array $ticket): string
    {
        return (string) ($ticket['date'] ?? '');
    }

    /** RSQL supported by GLPI v2.3; also perform local validation of every result. */
    public static function remoteFilter(array $filters): string
    {
        return 'date=ge=' . $filters['start_sql'] . ';date=lt=' . $filters['end_exclusive_sql'];
    }

    private static function inPeriod(string $opened, array $filters): bool
    {
        $when = strtotime($opened);
        $start = strtotime($filters['start_sql']);
        $end = strtotime($filters['end_exclusive_sql']);
        return $when !== false && $when >= $start && $when < $end;
    }

    private function loginLegacy(): bool
    {
        if ($this->legacyAttempted) {
            return $this->legacyToken !== null;
        }
        $this->legacyAttempted = true;
        if (empty($this->config['api_app_token'])) {
            return false;
        }
        try {
            [$status, $data] = $this->request('/v1/initSession', [
                'Authorization: Basic ' . base64_encode($this->config['api_username'] . ':' . $this->config['api_password']),
                'App-Token: ' . $this->config['api_app_token'],
            ]);
            if ($status === 200 && !empty($data['session_token'])) {
                $this->legacyToken = (string) $data['session_token'];
            }
        } catch (Throwable $e) {
            $this->legacyToken = null;
        }
        return $this->legacyToken !== null;
    }

    private function v1(string $path): array
    {
        if (!$this->loginLegacy()) {
            throw new RuntimeException('API v1 de leitura não está autorizada.');
        }
        return $this->request('/v1' . $path, [
            'Session-Token: ' . $this->legacyToken,
            'App-Token: ' . $this->config['api_app_token'],
        ]);
    }

    private function closeLegacy(): void
    {
        if ($this->legacyToken !== null) {
            try {
                $this->request('/v1/killSession', [
                    'Session-Token: ' . $this->legacyToken,
                    'App-Token: ' . $this->config['api_app_token'],
                ]);
            } catch (Throwable $e) {
                // Closing a read-only temporary session is best effort.
            }
            $this->legacyToken = null;
        }
    }

    private function legacyUst(array $categories): array
    {
        if (!$categories || !$this->loginLegacy()) {
            return [];
        }
        [$code, $options] = $this->v1('/listSearchOptions/ITILCategory');
        if ($code !== 200 || !is_array($options)) {
            $this->warnings[] = 'A API v1 não permitiu descobrir o campo UST do plugin Fields.';
            return [];
        }
        $fieldOption = null;
        $idOption = null;
        foreach ($options as $id => $opt) {
            if (!is_array($opt) || !ctype_digit((string) $id)) {
                continue;
            }
            if (strcasecmp((string) ($opt['table'] ?? ''), 'glpi_itilcategories') === 0 && ($opt['field'] ?? '') === 'id') {
                $idOption = (int) $id;
            }
            if (str_starts_with((string) ($opt['table'] ?? ''), 'glpi_plugin_fields_')
                && ($opt['field'] ?? '') === 'ustfield') {
                if ($fieldOption !== null) {
                    $this->warnings[] = 'Há múltiplas opções UST na API v1; confira o campo Fields.';
                    return [];
                }
                $fieldOption = (int) $id;
            }
        }
        if ($fieldOption === null || $idOption === null) {
            $this->warnings[] = 'O campo ustfield não está acessível nas opções de pesquisa da API v1.';
            return [];
        }
        if (count($categories) > self::MAX_ENRICHED_CATEGORIES) {
            $this->warnings[] = 'Mais de 100 categorias: UST remota não foi enriquecida nesta consulta.';
            return [];
        }
        $map = [];
        foreach ($categories as $id) {
            $query = http_build_query([
                'criteria' => [[ 'field' => $idOption, 'searchtype' => 'equals', 'value' => (string) $id ]],
                'forcedisplay' => [$idOption, $fieldOption],
            ], '', '&', PHP_QUERY_RFC3986);
            try {
                [$status, $payload] = $this->v1('/search/ITILCategory?' . $query);
                if ($status !== 200 && $status !== 206) {
                    continue;
                }
                $rows = $payload['data'] ?? [];
                if (!is_array($rows)) {
                    continue;
                }
                if (!array_is_list($rows)) {
                    $rows = array_values($rows);
                }
                foreach ($rows as $row) {
                    if (is_array($row) && (int) ($row[(string) $idOption] ?? -1) === $id
                        && array_key_exists((string) $fieldOption, $row)) {
                        $map[$id] = PluginGwreportsFilters::ust($row[(string) $fieldOption]);
                    }
                }
            } catch (Throwable $e) {
                $this->warnings[] = 'Falha parcial ao recuperar UST de uma Categoria ITIL pela API v1.';
                break;
            }
        }
        return $map;
    }

    /**
     * Historical event must ADD an assigned Group/User; a removed group or the
     * current team alone cannot establish when service was taken into account.
     * This is supporting evidence, not a replacement for GLPI's official metric.
     */
    public static function firstAssignmentFromLogs(array $logs, ?int $ticketId = null): ?string
    {
        $events = [];
        foreach ($logs as $record) {
            if (!is_array($record)) {
                continue;
            }
            if ($ticketId !== null && isset($record['items_id']) && (int) $record['items_id'] !== $ticketId) {
                continue;
            }
            $link = strtolower((string) ($record['itemtype_link'] ?? ''));
            $new = (string) ($record['new_value'] ?? '');
            $old = (string) ($record['old_value'] ?? '');
            $haystack = strtolower($new . ' ' . $link);
            $isGroup = str_contains($link, 'group') || str_contains($haystack, 'grupo técnico')
                || str_contains($haystack, 'technical group');
            $isTechUser = (str_contains($link, 'user') || str_contains($link, 'technician'))
                && (str_contains($haystack, '(técnico)') || str_contains($haystack, '(technician)')
                    || str_contains($haystack, '(técnica)'));
            if ((!$isGroup && !$isTechUser) || $new === ''
                || preg_match('/\b(remov|exclu|delet|unlink)/i', $new)) {
                continue;
            }
            // Do not interpret transfers out of a group as first assignment.
            if ($old !== '' && preg_match('/\b(remov|exclu|delet|unlink)/i', $old)) {
                continue;
            }
            $date = trim((string) ($record['date_mod'] ?? $record['date'] ?? ''));
            if (!$date || strtotime($date) === false) {
                continue;
            }
            $events[] = $date;
        }
        if (!$events) {
            return null;
        }
        usort($events, static fn (string $a, string $b): int => strtotime($a) <=> strtotime($b));
        return $events[0];
    }

    private function legacyTicket(int $id): ?array
    {
        try {
            [$status, $payload] = $this->v1('/Ticket/' . $id . '?get_hateoas=false&with_logs=true');
            return $status === 200 && is_array($payload) ? $payload : null;
        } catch (Throwable $e) {
            return null;
        }
    }

    private function legacyFirstAssignment(int $id, array $ticket): ?string
    {
        foreach (['logs', '_logs', 'Log', 'history'] as $key) {
            if (isset($ticket[$key]) && is_array($ticket[$key])) {
                $value = self::firstAssignmentFromLogs($ticket[$key], $id);
                if ($value !== null) {
                    return $value;
                }
            }
        }
        // The legacy API explicitly documents /Ticket/{id}/Log as read-only.
        try {
            [$code, $logs] = $this->v1('/Ticket/' . $id . '/Log?range=0-199');
            if (!in_array($code, [200, 206], true) || !is_array($logs)) {
                return null;
            }
            $rows = array_is_list($logs) ? $logs : ($logs['data'] ?? null);
            if (!is_array($rows)) {
                return null;
            }
            return self::firstAssignmentFromLogs($rows, $id);
        } catch (Throwable $e) {
            return null;
        }
    }

    public function report(array $filters): array
    {
        $query = http_build_query([
            'filter' => self::remoteFilter($filters),
            'sort' => 'date:desc',
        ], '', '&', PHP_QUERY_RFC3986);
        try {
            $tickets = $this->collect('/Assistance/Ticket?' . $query, 'chamados', self::MAX_TICKETS);
        } catch (RuntimeException $e) {
            // No silent switch to local data. A remote filter unsupported by the endpoint
            // is a visible error, not a justification to mix environments.
            throw new RuntimeException('Consulta remota não concluída: ' . $e->getMessage());
        }
        $selected = [];
        foreach ($tickets as $ticket) {
            if ((int) ($ticket['id'] ?? 0) <= 0 || !empty($ticket['is_deleted'])) {
                continue;
            }
            if (!self::inPeriod(self::opened($ticket), $filters)
                || ($filters['status'] && self::statusId($ticket) !== $filters['status'])) {
                continue;
            }
            if (!array_key_exists('team', $ticket)) {
                [$tc, $team] = $this->v2('/Assistance/Ticket/' . (int) $ticket['id'] . '/TeamMember');
                $ticket['team'] = self::listData($tc, $team, 'atores do chamado');
            }
            $groups = self::assignedGroups($ticket);
            if ($filters['group'] && !array_key_exists($filters['group'], $groups)) {
                continue;
            }
            $selected[] = [$ticket, $groups];
        }
        $categories = array_values(array_unique(array_filter(array_map(
            static fn (array $item) => self::idOf($item[0]['category'] ?? null), $selected
        ))));
        $ust = [];
        $legacyOk = $this->loginLegacy();
        if ($legacyOk) {
            try {
                $ust = $this->legacyUst($categories);
            } catch (Throwable $e) {
                $this->warnings[] = 'A consulta à UST na API v1 falhou; nenhum valor foi presumido.';
            }
        } else {
            $this->warnings[] = 'UST remota indisponível: para ler o campo Fields, configure um App-Token v1 com acesso de leitura.';
        }
        // Never guess UST. A manually entered value is explicitly a fallback,
        // used only when the server did not expose Fields via the v1 search.
        $manual = PluginGwreportsSettings::ustFallbackMap($this->config);
        $usedManual = false;
        foreach ($categories as $category) {
            if (!isset($ust[$category]) && isset($manual[$category])) {
                $ust[$category] = $manual[$category];
                $usedManual = true;
            }
        }
        if ($usedManual) {
            $this->warnings[] = 'Algumas UST usam valores manuais de contingência, informados na configuração; confira com o catálogo oficial.';
        }
        $sum = 0.0;
        $count = 0;
        $now = date('Y-m-d H:i:s');
        $result = [];
        $canEnrichTickets = $legacyOk && count($selected) <= self::MAX_ENRICHED_TICKETS;
        if ($legacyOk && !$canEnrichTickets) {
            $this->warnings[] = 'Mais de 75 chamados: datas de vencimento SLA não foram enriquecidas pela API v1.';
        }
        try {
            foreach ($selected as [$t, $assigned]) {
                $id = (int) $t['id'];
                $category = self::idOf($t['category'] ?? null);
                $unit = $ust[$category] ?? null;
                if ($unit !== null) {
                    $sum += $unit;
                    $count++;
                }
                $oldTicket = $canEnrichTickets ? $this->legacyTicket($id) : null;
                $hasTto = self::idOf($t['sla_tto'] ?? null) > 0;
                $hasTtr = self::idOf($t['sla_ttr'] ?? null) > 0;
                $tto = !$hasTto ? 'N/A' : 'N/D';
                $ttr = !$hasTtr ? 'N/A' : 'N/D';
                $ttoSource = '';
                if ($hasTto && $oldTicket !== null) {
                    $due = $oldTicket['time_to_own'] ?? null;
                    $native = $oldTicket['takeintoaccountdate'] ?? null;
                    if (!$native) {
                        $native = $t['take_into_account_date'] ?? null;
                    }
                    if ($native) {
                        $tto = PluginGwreportsFilters::sla($due, (string) $native, $now);
                        $ttoSource = 'Data nativa do GLPI';
                    } elseif ($due) {
                        $historical = $this->legacyFirstAssignment($id, $oldTicket);
                        if ($historical && strtotime($historical) <= strtotime((string) $due)) {
                            $tto = 'Sim';
                            $ttoSource = 'Histórico de atribuição (estatística nativa sem data)';
                            $this->warnings[] = 'Alguns TTO foram considerados SIM pelo histórico de atribuição; confira divergências com a estatística nativa do GLPI.';
                        } else {
                            $hasAssignee = false;
                            foreach (($t['team'] ?? []) as $actor) {
                                if (is_array($actor) && strcasecmp((string) ($actor['role'] ?? ''), 'assigned') === 0) {
                                    $hasAssignee = true;
                                    break;
                                }
                            }
                            if (!$hasAssignee) {
                                // Still unassigned: count against the due date as of now.
                                $tto = PluginGwreportsFilters::sla((string) $due, null, $now);
                                $ttoSource = 'Sem atribuição atual; prazo avaliado na data da consulta';
                            } else {
                                // Group currently assigned is not proof of first-assignment date.
                                $tto = 'N/D';
                                $ttoSource = 'Atribuição sem data nativa e sem histórico conclusivo';
                            }
                        }
                    }
                }
                if ($hasTtr) {
                    $dueTtr = ($oldTicket['time_to_resolve'] ?? null) ?: ($t['resolution_date'] ?? null);
                    $actualTtr = ($oldTicket['solvedate'] ?? null) ?: ($t['date_solve'] ?? ($t['date_close'] ?? null));
                    $ttr = $dueTtr ? PluginGwreportsFilters::sla((string) $dueTtr,
                        $actualTtr ? (string) $actualTtr : null, $now) : 'N/D';
                }
                $statusId = self::statusId($t);
                $categoryRecord = $t['category'] ?? null;
                $categoryLabel = is_array($categoryRecord)
                    ? (string) ($categoryRecord['completename'] ?? $categoryRecord['name'] ?? '') : '';
                $categoryLabel = html_entity_decode(strip_tags($categoryLabel), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                if ($categoryLabel === '') {
                    $categoryLabel = $category > 0 ? 'Categoria #' . $category : 'Sem categoria';
                }
                $names = array_values($assigned);
                natcasesort($names);
                $result[] = [
                    'id' => $id,
                    'title' => html_entity_decode(strip_tags((string) ($t['name'] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8'),
                    'status' => PluginGwreportsFilters::STATUS[$statusId] ?? ((string) ($t['status']['name'] ?? ('Status ' . $statusId))),
                    'category' => $categoryLabel,
                    'group' => $names ? implode(', ', $names) : 'Sem grupo',
                    'opened' => (string) ($t['date'] ?? ''),
                    'solved' => (string) ($t['date_solve'] ?? ''),
                    'closed' => (string) ($t['date_close'] ?? ''),
                    'tto' => $tto,
                    'tto_source' => $ttoSource,
                    'ttr' => $ttr,
                    'ust' => $unit,
                ];
            }
        } finally {
            $this->closeLegacy();
        }
        usort($result, static fn ($a, $b) => strcmp($b['opened'], $a['opened']) ?: ($b['id'] <=> $a['id']));
        return [
            'rows' => $result,
            'total_ust' => $sum,
            'with_ust' => $count,
            'without_ust' => count($result) - $count,
            'warnings' => array_values(array_unique($this->warnings)),
            'source' => 'remote',
        ];
    }
}
