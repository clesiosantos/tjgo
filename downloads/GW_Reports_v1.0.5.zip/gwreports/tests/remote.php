<?php
/** Isolated remote tests: no HTTP, no secrets, no GLPI server required. */
require_once __DIR__ . '/../inc/filters.php';
require_once __DIR__ . '/../inc/settings.php';
require_once __DIR__ . '/../inc/remote.php';
function assert_true($condition, string $message): void {
    if (!$condition) { throw new RuntimeException('FALHOU: ' . $message); }
    echo 'OK: ' . $message . PHP_EOL;
}
$now = new DateTimeImmutable('2026-11-11 10:00:00', new DateTimeZone('America/Sao_Paulo'));
$f = PluginGwreportsFilters::parse([
    'period' => 'custom', 'start' => '2026-11-09', 'end' => '2026-11-11',
    'source' => 'remote', 'group' => '13',
], $now);
assert_true($f['source'] === 'remote' && $f['group'] === 13, 'Seletor da API remota validado');
try {
    PluginGwreportsFilters::parse(['source' => 'arquivo'], $now);
    throw new RuntimeException('Origem inválida foi aceita');
} catch (InvalidArgumentException $e) {
    assert_true(true, 'Origem inválida rejeitada');
}
$mapping = "953=1,25\n952=1\n";
assert_true(PluginGwreportsSettings::validatedUstFallback($mapping) === "952=1\n953=1.25", 'Mapeamento manual validado e ordenado');
assert_true(PluginGwreportsSettings::ustFallbackMap(['ust_fallback' => $mapping])[953] === 1.25, 'Valor decimal de UST preservado');
try {
    PluginGwreportsSettings::validatedUstFallback("952=1\n952=2");
    throw new RuntimeException('Duplicata foi aceita');
} catch (InvalidArgumentException $e) {
    assert_true(true, 'Categoria duplicada rejeitada');
}
$ticket = static function (int $id, string $date, int $category, int $group): array {
    return [
        'id' => $id, 'name' => 'Solicitação nº ' . $id, 'date' => $date,
        'status' => ['id' => 2, 'name' => 'Em atendimento (atribuído)'],
        'category' => ['id' => $category, 'name' => 'POC'],
        'team' => [['id' => $group, 'name' => 'Grupo ' . $group, 'type' => 'Group', 'role' => 'assigned'],
            ['id' => 5, 'name' => 'Solicitante', 'type' => 'User', 'role' => 'requester']],
        'sla_tto' => ['id' => 1, 'name' => 'TTO'], 'sla_ttr' => ['id' => 2, 'name' => 'TTR'],
        'date_close' => null,
    ];
};
$requests = [];
$mock = static function (string $path, array $headers, string $method, ?string $body) use (&$requests, $ticket): array {
    $requests[] = [$path, $method];
    if ($path === '/token') { return [200, ['access_token' => 'mock-not-real']]; }
    if (str_starts_with($path, '/v2.3/Administration/Group')) {
        return [206, [['id' => 12, 'name' => 'N1'], ['id' => 13, 'name' => 'N2']]];
    }
    if (str_starts_with($path, '/v2.3/Assistance/Ticket?')) {
        return [206, [$ticket(8, '2026-11-10 12:00:00', 952, 13),
            $ticket(9, '2026-11-10 14:00:00', 953, 12),
            $ticket(10, '2026-10-10 14:00:00', 952, 13)]];
    }
    throw new RuntimeException('Endpoint não esperado: ' . $path);
};
$config = [
    'api_url' => 'https://poc.exemplo.tld/api.php/v2.3',
    'api_mode' => 'oauth_password', 'api_username' => 'usuario_teste',
    'api_password' => 'valor_ficticio', 'api_client_id' => 'client_teste',
    'api_client_secret' => 'valor_ficticio', 'api_app_token' => '',
    'ust_fallback' => "952=1\n953=1.25",
];
$repo = new PluginGwreportsRemote($config, $mock);
assert_true(count($repo->groups()) === 2, 'Listagem remota de grupos aceita HTTP 206');
$report = $repo->report($f);
assert_true(count($report['rows']) === 1 && $report['rows'][0]['id'] === 8, 'Filtros remotos de grupo e data aplicados');
assert_true($report['total_ust'] === 1.0 && $report['with_ust'] === 1, 'UST remota por mapeamento explícito totalizada');
assert_true($report['rows'][0]['group'] === 'Grupo 13', 'Grupo atribuído exibido (não o solicitante)');
assert_true($report['rows'][0]['category'] === 'POC', 'Nome da Categoria ITIL obtido do chamado remoto');
assert_true($report['rows'][0]['tto'] === 'N/D' && $report['rows'][0]['ttr'] === 'N/D', 'SLA indisponível não é presumido');
assert_true($repo->ticketUrl(8) === 'https://poc.exemplo.tld/front/ticket.form.php?id=8', 'Link abre chamado no ambiente remoto');
assert_true(str_contains($requests[2][0], 'filter='), 'Filtro RSQL incluído na consulta v2.3');
assert_true(count($report['warnings']) >= 1, 'Alertas de origem manual da UST são emitidos');
assert_true(PluginGwreportsRemote::listData(206, [], 'test') === [], 'HTTP 206 com lista vazia não causa erro');
try {
    PluginGwreportsRemote::listData(403, [], 'chamados');
    throw new RuntimeException('HTTP 403 indevidamente aceito');
} catch (RuntimeException $e) {
    assert_true(true, 'HTTP 403 corretamente bloqueado');
}
// Verify legacy v1 used only for enriching UST and SLA with read endpoints.
$requests = [];
$config['api_app_token'] = 'app_token_ficticio';
$mockLegacy = static function (string $path, array $headers, string $method, ?string $body) use (&$requests, $ticket): array {
    $requests[] = [$path, $method];
    if ($path === '/token') return [200, ['access_token' => 'mock']];
    if (str_starts_with($path, '/v2.3/Assistance/Ticket?')) return [206, [$ticket(8, '2026-11-10 12:00:00', 952, 13)]];
    if ($path === '/v1/initSession') return [200, ['session_token' => 'session_fake']];
    if ($path === '/v1/listSearchOptions/ITILCategory') return [200, [
        '2' => ['table' => 'glpi_itilcategories', 'field' => 'id'],
        '76666' => ['table' => 'glpi_plugin_fields_ust', 'field' => 'ustfield'],
    ]];
    if (str_starts_with($path, '/v1/search/ITILCategory?')) return [200, ['data' => [
        ['2' => '952', '76666' => '2,5'],
    ]]];
    if ($path === '/v1/Ticket/8?get_hateoas=false&with_logs=true') return [200, [
        'time_to_own' => '2026-11-10 14:00:00',
        'takeintoaccountdate' => '2026-11-10 13:00:00',
        'time_to_resolve' => '2026-11-10 18:00:00',
        'solvedate' => '2026-11-10 17:00:00',
    ]];
    if ($path === '/v1/killSession') return [200, []];
    throw new RuntimeException('Endpoint não esperado: ' . $path);
};
$f['group'] = 0;
$repo = new PluginGwreportsRemote($config, $mockLegacy);
$report = $repo->report($f);
assert_true($report['total_ust'] === 2.5, 'Valor real de UST na API legada tem prioridade sobre mapeamento manual');
assert_true($report['rows'][0]['category'] === 'POC', 'Categoria ITIL preservada no modo remoto com API v1');
assert_true($report['rows'][0]['tto'] === 'Sim' && $report['rows'][0]['ttr'] === 'Sim', 'Datas reais do SLA via API v1 calculadas');
assert_true(in_array(['/v1/killSession', 'GET'], $requests, true), 'Sessão legada encerrada');
foreach ($requests as [$url, $method]) assert_true($method === 'GET' || ($url === '/token' && $method === 'POST'), 'Nenhuma gravação na API remota');
echo "TESTES REMOTOS CONCLUÍDOS\n";
