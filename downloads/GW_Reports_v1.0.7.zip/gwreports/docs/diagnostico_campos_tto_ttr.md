# Diagnóstico — TTO/TTR e regras GLPI 11 (POC TJ-GO)

## O que foi comprovado

- Chamado #8: categoria 952; regra atribuiu SLA TTO ID 1 e SLA TTR ID 2; grupo N1 ID 12 adicionado na criação, depois N2 ID 13.
- API v2.3: `take_into_account_date=null` e `take_into_account_duration=0` após as atribuições; `resolution_date=2026-11-11T15:00:00+00:00`; `date_solve=null` e `date_close=null`.
- O campo `resolution_date` é **prazo de solução**, não data da conclusão. A ausência de `date_solve` é normal enquanto status em atendimento.
- O histórico é diferente do indicador nativo de tempo de atendimento. O evento de atribuição pode existir sem o carimbo estatístico nativo; **a causa exata ainda não está confirmada**.

## Hipótese

Atribuição automática pela categoria e regras que preenchem SLA executam na abertura, mas não necessariamente geram a atualização de atendimento (primeira ação executada por técnico autorizado) que o GLPI usa para o campo estatístico. Confirmar em um chamado de teste antes de classificar como bug.

## Teste 100% pela interface web + Swagger

1. Abrir uma requisição nova na categoria 952 pelo formulário geral.
2. Consultar JSON GET `/Assistance/Ticket/{id}` no Swagger e anotar `take_into_account_date`, `take_into_account_duration`, `sla_tto`, `sla_ttr`, `resolution_date`, `date_solve`. Registrar a aba Estatísticas e o histórico.
3. Entrar com **técnico efetivamente membro do grupo N1**, com direitos de atendimento, e registrar acompanhamento ou tarefa real no chamado de teste.
4. Consultar novamente os campos e a aba Estatísticas. Se o campo ganhar data, confirmou-se a diferença entre associação de SLA/grupo e primeiro atendimento registrado.
5. Se continuar nulo, pedir à Infra análise da versão GLPI, direitos efetivos do executor, comportamento do mecanismo `takeintoaccount` e logs da aplicação.

Não retroagir datas, não ajustar diretamente o banco, não disparar atualização artificial em chamado de produção. O relógio de SLA respeita o calendário do SLM e deve ser comparado em um único fuso.

Referências oficiais:
- https://help.glpi-project.org/documentation/modules/configuration/service_levels
- https://help.glpi-project.org/faq/glpi/service_levels
- https://help.glpi-project.org/documentation/modules/assistance/tickets/ticketlifecycle
- https://glpi-developer-documentation.readthedocs.io/en/latest/devapi/itilobjects.html
