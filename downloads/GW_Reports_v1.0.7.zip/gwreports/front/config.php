<?php
/** GW Reports administrative API configuration. */
include_once '../../../inc/includes.php';
require_once __DIR__ . '/../inc/common.php';
require_once __DIR__ . '/../inc/settings.php';
require_once __DIR__ . '/../inc/api.php';
require_once __DIR__ . '/../inc/brand.php';
gwreports_admin();
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // GLPI 11 CheckCsrfListener validates POST requests before executing this file.
    // Do not check the token again: the first validation consumes it.
    try {
        if (($_POST['action'] ?? '') === 'save') {
            PluginGwreportsSettings::save($_POST);
            $message = 'Configurações salvas. As credenciais foram criptografadas pelo GLPI.';
        } elseif (($_POST['action'] ?? '') === 'test') {
            $message = PluginGwreportsApi::test();
        } elseif (($_POST['action'] ?? '') === 'logo_import') {
            $message = PluginGwreportsBrand::importUserReference();
        } elseif (($_POST['action'] ?? '') === 'logo_upload') {
            PluginGwreportsBrand::upload($_FILES['logo_file'] ?? []);
            $message = 'Logomarca enviada e ativada para todas as exportações PDF.';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}
$config = PluginGwreportsSettings::get();
$base = gwreports_base_url();
Html::header('GW Reports — Configuração', $_SERVER['PHP_SELF'], 'config', 'plugins');
echo '<div class="container mt-4 mb-5" style="max-width:1000px">';
echo '<h2>GW Reports — Configurações da API</h2>';
echo '<div class="alert alert-info">O Relatório UST permite selecionar GLPI local ou API remota v2.3. Para usar a origem remota, salve as credenciais OAuth2. Para UST e prazo SLA, configure opcionalmente também um App-Token v1 com leitura autorizada, ou informe um mapeamento UST de contingência.</div>';
if ($message !== '') {
    echo '<div class="alert alert-success">' . gwreports_e($message) . '</div>';
}
if ($error !== '') {
    echo '<div class="alert alert-danger">' . gwreports_e($error) . '</div>';
}
echo '<div class="card"><div class="card-body"><form method="post" action="' . gwreports_e($base . '/front/config.php') . '">';
echo '<input type="hidden" name="_glpi_csrf_token" value="' . gwreports_e(Session::getNewCSRFToken()) . '">';
echo '<input type="hidden" name="action" value="save">';
echo '<div class="mb-3"><label class="form-label" for="api-mode">Tipo de autenticação</label><select class="form-select" id="api-mode" name="api_mode">';
foreach (['oauth_password' => 'API v2.3 — OAuth2 (password grant)', 'legacy_basic' => 'API v1 — Basic + App-Token'] as $k => $v) {
    echo '<option value="' . $k . '"' . ($config['api_mode'] === $k ? ' selected' : '') . '>' . gwreports_e($v) . '</option>';
}
echo '</select></div>';
foreach ([
    'api_url' => ['URL da API', 'https://servidor/api.php/v2.3'],
    'api_username' => ['Usuário da API', 'Usuário técnico'],
    'api_client_id' => ['Client ID (OAuth2)', 'Client ID'],
] as $key => [$label, $placeholder]) {
    echo '<div class="mb-3"><label class="form-label" for="' . $key . '">' . gwreports_e($label) . '</label>';
    echo '<input class="form-control" type="text" id="' . $key . '" name="' . $key . '" placeholder="' . gwreports_e($placeholder) . '" value="' . gwreports_e((string) $config[$key]) . '" autocomplete="off"></div>';
}
foreach ([
    'api_password' => 'Senha do usuário da API',
    'api_client_secret' => 'Client Secret (OAuth2)',
    'api_app_token' => 'App-Token (API v1)',
] as $key => $label) {
    echo '<div class="mb-3"><label class="form-label" for="' . $key . '">' . gwreports_e($label) . '</label>';
    echo '<input class="form-control" type="password" id="' . $key . '" name="' . $key . '" placeholder="Deixe vazio para manter o segredo salvo" autocomplete="new-password">';
    echo '<div class="form-text">' . (!empty($config[$key]) ? 'Há um valor protegido salvo.' : 'Nenhum valor configurado.') . '</div></div>';
}
echo '<div class="mb-3"><label for="ust_fallback" class="form-label">UST por Categoria ITIL (contingência opcional)</label>';
echo '<textarea class="form-control font-monospace" id="ust_fallback" name="ust_fallback" rows="5" placeholder="952=1&#10;953=1">' . gwreports_e((string) $config['ust_fallback']) . '</textarea>';
echo '<div class="form-text">Informe apenas valores confirmados (ID da categoria = UST). O campo Fields remoto tem prioridade; esse mapeamento só preenche UST não acessível pela API.</div></div>';
echo '<button class="btn btn-primary" type="submit">Salvar configuração</button>';
echo '</form><hr><form method="post" action="' . gwreports_e($base . '/front/config.php') . '">';
echo '<input type="hidden" name="_glpi_csrf_token" value="' . gwreports_e(Session::getNewCSRFToken()) . '">';
echo '<input type="hidden" name="action" value="test">';
echo '<button class="btn btn-outline-primary" type="submit">Testar conexão com a API</button></form>';
echo '</div></div>';
echo '<div class="card mt-4"><div class="card-body">';
echo '<h3 class="h5">Logomarca GlobalWEB no PDF</h3>';
echo '<p class="text-muted">A logomarca pode ser importada do link indicado ou enviada por JPG/PNG. Depois de salva, fica no armazenamento interno do GLPI; a exportação PDF não usa internet.</p>';
echo '<p><img src="' . gwreports_e($base . '/front/logo.php') . '" alt="Logomarca atualmente usada no PDF" style="max-width:260px;max-height:120px;object-fit:contain;background:#fff;padding:8px;border:1px solid #ddd" /></p>';
echo '<div class="mb-2 small">' . (PluginGwreportsBrand::jpeg()['custom'] ?? false ? '<strong>Fonte:</strong> logomarca personalizada armazenada no GLPI.' : '<strong>Fonte:</strong> monograma GW do pacote; importe a logomarca oficial para substituí-lo.') . '</div>';
echo '<form method="post" action="' . gwreports_e($base . '/front/config.php') . '" class="mb-3">';
echo '<input type="hidden" name="_glpi_csrf_token" value="' . gwreports_e(Session::getNewCSRFToken()) . '">';
echo '<input type="hidden" name="action" value="logo_import">';
echo '<button class="btn btn-outline-primary" type="submit">Importar logomarca GlobalWEB do link informado</button>';
echo '</form>';
echo '<form method="post" enctype="multipart/form-data" action="' . gwreports_e($base . '/front/config.php') . '">';
echo '<input type="hidden" name="_glpi_csrf_token" value="' . gwreports_e(Session::getNewCSRFToken()) . '">';
echo '<input type="hidden" name="action" value="logo_upload">';
echo '<label for="logo_pdf" class="form-label">Ou envie o arquivo da logomarca (JPG/PNG, até 1 MB)</label>';
echo '<input class="form-control mb-2" type="file" name="logo_file" id="logo_pdf" accept="image/jpeg,image/png" required>';
echo '<button class="btn btn-primary" type="submit">Salvar logomarca para os PDFs</button>';
echo '</form></div></div>';

echo '<p class="mt-3"><a href="' . gwreports_e($base . '/front/report.php') . '">Voltar ao Relatório UST</a></p>';
echo '<p class="text-muted small">As credenciais não são exibidas, exportadas ou enviadas ao navegador após o salvamento. A configuração exige perfil com direito administrativo de Configuração.</p>';
echo '</div>';
Html::footer();
