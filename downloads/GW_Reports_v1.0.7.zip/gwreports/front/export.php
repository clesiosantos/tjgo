<?php
/** Export read-only; administrator permission required for CSV and PDF. */
include_once '../../../inc/includes.php';
require_once __DIR__ . '/../inc/common.php';
gwreports_require_libs();
gwreports_admin();
global $DB;
try {
    $filters = PluginGwreportsFilters::parse($_GET);
    $repo = $filters['source'] === 'remote' ? new PluginGwreportsRemote() : new PluginGwreportsRepository($DB);
    $report = $repo->report($filters);
} catch (Throwable $e) {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Não foi possível exportar: ' . $e->getMessage();
    return;
}
$format = (string) ($_GET['format'] ?? 'csv');
$name = 'gwreports_ust_' . date('Ymd_His');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
if ($format === 'csv') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $name . '.csv"');
    $fp = fopen('php://output', 'wb');
    fwrite($fp, "\xEF\xBB\xBF");
    fputcsv($fp, ['Chamado', 'Título', 'Categoria ITIL', 'Status', 'Grupo solucionador', 'Data abertura',
        'Data solução', 'Data fechamento', 'SLA TTO atendido', 'SLA TTR atendido', 'UST'], ';', '"', '');
    foreach ($report['rows'] as $r) {
        // Protect spreadsheet consumers from formula injection in untrusted ticket titles/group names.
        $safe = static function (string $s): string {
            return preg_match('/^[\s]*[=+@\-\t\r]/u', $s) ? "'" . $s : $s;
        };
        fputcsv($fp, [
            $r['id'], $safe($r['title']), $safe((string) ($r['category'] ?? 'Sem categoria')),
            $safe($r['status']), $safe($r['group']),
            PluginGwreportsFilters::displayDate($r['opened']), PluginGwreportsFilters::displayDate($r['solved'] ?? ''),
            PluginGwreportsFilters::displayDate($r['closed']), PluginGwreportsFilters::upperStatus($r['tto']), PluginGwreportsFilters::upperStatus($r['ttr']),
            $r['ust'] === null ? 'N/D' : number_format((float) $r['ust'], 2, ',', '.'),
        ], ';', '"', '');
    }
    fputcsv($fp, ['', 'TOTAL UST', '', '', '', '', '', '', '', '', number_format((float) $report['total_ust'], 2, ',', '.')], ';', '"', '');
    fclose($fp);
    return;
}
if ($format !== 'pdf') {
    http_response_code(400);
    header('Content-Type: text/plain; charset=UTF-8');
    echo 'Formato inválido.';
    return;
}
$pdf = PluginGwreportsPdf::make($report, $filters);
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $name . '.pdf"');
header('Content-Length: ' . strlen($pdf));
echo $pdf;
