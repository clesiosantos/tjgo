<?php
/** Admin-only preview of the PDF logo. Never expose remote credentials. */
include_once '../../../inc/includes.php';
require_once __DIR__ . '/../inc/common.php';
require_once __DIR__ . '/../inc/brand.php';
gwreports_admin();
$logo = PluginGwreportsBrand::jpeg();
if ($logo === null) {
    http_response_code(404);
    exit;
}
header('Content-Type: image/jpeg');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
header('Content-Length: ' . strlen($logo['data']));
echo $logo['data'];
