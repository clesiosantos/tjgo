<?php
/** GW Reports — brand manager. Imports an approved logo from the GLPI web UI,
 * stores it outside the public document root, and embeds it in PDF exports.
 */
final class PluginGwreportsBrand
{
    public const USER_LOGO_URL = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSCRlq5z_k6muxSmVCdXMvz9lee9R0QeBJdZR-o97qKk87K8PV8sZLShKF&s=10';
    private const MAX_BYTES = 1048576; // 1 MiB upload/download (PDF has an additional 350-KiB limit).

    public static function customPath(): string
    {
        if (!defined('GLPI_VAR_DIR')) {
            throw new RuntimeException('O diretório de dados do GLPI não está configurado.');
        }
        return rtrim((string) GLPI_VAR_DIR, '/\\') . '/_plugins/gwreports/globalweb_pdf_logo.jpg';
    }

    public static function bundledPath(): string
    {
        return __DIR__ . '/../assets/gw_logo.jpg';
    }

    /** Return the chosen image, or the packaged GW fallback when no official logo was saved. */
    public static function jpeg(): ?array
    {
        $paths = [];
        if (defined('GLPI_VAR_DIR')) {
            $paths[] = self::customPath();
        }
        $paths[] = self::bundledPath();
        foreach ($paths as $file) {
            if (!is_file($file) || !is_readable($file)) {
                continue;
            }
            $bytes = file_get_contents($file);
            if ($bytes === false || strlen($bytes) > 350000) {
                continue;
            }
            $info = @getimagesizefromstring($bytes);
            if (!$info || ($info[2] ?? 0) !== IMAGETYPE_JPEG || $info[0] <= 0 || $info[1] <= 0) {
                continue;
            }
            return [
                'data' => $bytes,
                'width' => (int) $info[0],
                'height' => (int) $info[1],
                'custom' => $file !== self::bundledPath(),
            ];
        }
        return null;
    }

    /** Normalize a JPEG (or PNG when GD is available) to PDF-compatible RGB JPEG. */
    public static function normalizeToJpeg(string $data): string
    {
        $length = strlen($data);
        if ($length === 0 || $length > self::MAX_BYTES) {
            throw new InvalidArgumentException('A imagem deve ter no máximo 1 MB.');
        }
        $info = @getimagesizefromstring($data);
        if (!$info || (int) $info[0] < 24 || (int) $info[1] < 24 || $info[0] > 4000 || $info[1] > 4000) {
            throw new InvalidArgumentException('Imagem inválida ou com dimensões insuficientes (mínimo 24 pixels).');
        }
        $type = (int) ($info[2] ?? 0);
        if (!in_array($type, [IMAGETYPE_JPEG, IMAGETYPE_PNG], true)) {
            throw new InvalidArgumentException('Envie uma imagem JPG ou PNG.');
        }
        if (function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
            $original = @imagecreatefromstring($data);
            if ($original === false) {
                throw new InvalidArgumentException('Imagem não pôde ser decodificada.');
            }
            $width = imagesx($original);
            $height = imagesy($original);
            if ($width > 1400 || $height > 1400) {
                $scale = min(1400 / $width, 1400 / $height);
                $newWidth = max(1, (int) round($width * $scale));
                $newHeight = max(1, (int) round($height * $scale));
                $resized = imagecreatetruecolor($newWidth, $newHeight);
                imagefill($resized, 0, 0, imagecolorallocate($resized, 255, 255, 255));
                imagecopyresampled($resized, $original, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
                imagedestroy($original);
                $original = $resized;
            }
            $rgb = imagecreatetruecolor(imagesx($original), imagesy($original));
            imagefill($rgb, 0, 0, imagecolorallocate($rgb, 255, 255, 255));
            imagecopy($rgb, $original, 0, 0, 0, 0, imagesx($original), imagesy($original));
            imagedestroy($original);
            foreach ([90, 80, 70, 60] as $quality) {
                ob_start();
                imagejpeg($rgb, null, $quality);
                $jpeg = (string) ob_get_clean();
                if (strlen($jpeg) <= 350000) {
                    imagedestroy($rgb);
                    return $jpeg;
                }
            }
            imagedestroy($rgb);
            throw new InvalidArgumentException('Imagem não pôde ser compactada para o PDF.');
        }
        if ($type !== IMAGETYPE_JPEG || $length > 350000) {
            throw new InvalidArgumentException('Este servidor necessita GD para converter PNG ou compactar JPG. Envie JPG menor que 350 KB.');
        }
        return $data;
    }

    /** Persist only in GLPI_VAR_DIR; no writes to plugins/ and no shell required. */
    public static function saveBytes(string $raw): void
    {
        $jpeg = self::normalizeToJpeg($raw);
        $path = self::customPath();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new RuntimeException('O GLPI não conseguiu criar a pasta de logomarcas no diretório de dados.');
        }
        $temp = @tempnam($dir, 'gw_logo_');
        if ($temp === false) {
            throw new RuntimeException('Não foi possível criar um arquivo temporário para a logomarca.');
        }
        try {
            if (file_put_contents($temp, $jpeg, LOCK_EX) !== strlen($jpeg)) {
                throw new RuntimeException('Falha ao salvar a imagem da logomarca.');
            }
            @chmod($temp, 0600);
            if (!@rename($temp, $path)) {
                throw new RuntimeException('Falha ao publicar a logomarca no diretório de dados do GLPI.');
            }
        } finally {
            if (is_file($temp)) {
                @unlink($temp);
            }
        }
    }

    public static function upload(array $upload): void
    {
        if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException('Selecione uma imagem JPG ou PNG válida para enviar.');
        }
        $temp = (string) ($upload['tmp_name'] ?? '');
        if (!is_uploaded_file($temp) || (int) ($upload['size'] ?? 0) > self::MAX_BYTES) {
            throw new InvalidArgumentException('Upload inválido ou acima de 1 MB.');
        }
        $bytes = file_get_contents($temp);
        if ($bytes === false) {
            throw new RuntimeException('Falha ao ler o arquivo recebido.');
        }
        self::saveBytes($bytes);
    }

    /** Fetch only the fixed, user-specified Google thumbnail source; no arbitrary URL/SSRF. */
    public static function importUserReference(): string
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('A extensão cURL é necessária para importar a imagem. Use o envio JPG/PNG.');
        }
        $errors = [];
        foreach ([400, 300, 10] as $size) {
            $url = preg_replace('/&s=10$/', '&s=' . $size, self::USER_LOGO_URL);
            $buffer = '';
            $curl = curl_init($url);
            if ($curl === false) {
                continue;
            }
            curl_setopt_array($curl, [
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 12,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (GW-Reports-logo-import)',
                CURLOPT_HTTPHEADER => ['Accept: image/jpeg,image/png'],
                CURLOPT_WRITEFUNCTION => static function ($ch, string $part) use (&$buffer): int {
                    if (strlen($buffer) + strlen($part) > 1048576) {
                        return 0;
                    }
                    $buffer .= $part;
                    return strlen($part);
                },
            ]);
            if (defined('CURLOPT_PROTOCOLS')) {
                curl_setopt($curl, CURLOPT_PROTOCOLS, CURLPROTO_HTTPS);
            }
            $ok = curl_exec($curl);
            $http = curl_getinfo($curl, CURLINFO_HTTP_CODE);
            $mime = (string) curl_getinfo($curl, CURLINFO_CONTENT_TYPE);
            curl_close($curl);
            if (!$ok || $http !== 200 || !preg_match('~^image/(jpeg|png)\b~i', $mime)) {
                $errors[] = 'HTTP ' . $http . ' ou formato indisponível (s=' . $size . ')';
                continue;
            }
            try {
                self::saveBytes($buffer);
                return 'Logomarca da URL indicada importada e armazenada no GLPI para uso offline no PDF.';
            } catch (InvalidArgumentException $e) {
                $errors[] = $e->getMessage();
            }
        }
        throw new RuntimeException('Não foi possível importar a imagem do Google Imagens. Salve a imagem em JPG ou PNG e utilize o formulário de envio. Detalhes: ' . implode('; ', $errors));
    }
}
