<?php
/** Common access checks and utilities for GW Reports. */
function gwreports_admin(): void
{
    Session::checkRight(Config::$rightname, UPDATE);
}
function gwreports_e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function gwreports_base_url(): string
{
    global $CFG_GLPI;
    return rtrim((string) ($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/gwreports';
}
function gwreports_qs(array $data): string
{
    return http_build_query($data, '', '&', PHP_QUERY_RFC3986);
}
function gwreports_require_libs(): void
{
    require_once __DIR__ . '/filters.php';
    require_once __DIR__ . '/repository.php';
    require_once __DIR__ . '/settings.php';
    require_once __DIR__ . '/remote.php';
    require_once __DIR__ . '/pdf.php';
}
