<?php
/** Dependency-free, paginated A3 landscape PDF; WinAnsi + Helvetica. */
final class PluginGwreportsPdf
{
    private const W = 1190;
    private const H = 842;
    private const X = 32;
    // 11 columns, 1120 pt total inside the A3 landscape 1190 pt page.
    private const COLUMNS = [62, 170, 144, 96, 138, 110, 110, 110, 60, 60, 60];

    private static function latin(string $text): string
    {
        $out = function_exists('iconv') ? iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $text) : false;
        return $out === false ? preg_replace('/[^\x20-\x7E]/', '?', $text) : $out;
    }
    private static function literal(string $text): string
    {
        return str_replace(["\\", '(', ')', "\r", "\n"], ["\\\\", '\\(', '\\)', '', ' '], self::latin($text));
    }
    private static function label(float $x, float $y, string $s, int $size = 9, string $color = '0.13 0.18 0.24'): string
    {
        return "BT /F1 {$size} Tf {$color} rg " . number_format($x, 1, '.', '') . ' '
            . number_format($y, 1, '.', '') . ' Td (' . self::literal($s) . ") Tj ET\n";
    }
    private static function crop(string $s, int $max): string
    {
        if (function_exists('mb_strimwidth')) {
            return mb_strimwidth($s, 0, $max, '…', 'UTF-8');
        }
        return strlen($s) > $max ? substr($s, 0, $max - 3) . '...' : $s;
    }
    private static function pdate(string $datetime): string
    {
        if ($datetime === '' || $datetime === '0000-00-00 00:00:00') {
            return '—';
        }
        return PluginGwreportsFilters::displayDate($datetime);
    }
    private static function ust(?float $u): string
    {
        return $u === null ? 'N/D' : number_format($u, 2, ',', '.');
    }

    /** Image saved through the GLPI web interface; fallback to bundled visual mark. */
    private static function brandJpeg(): ?array
    {
        require_once __DIR__ . '/brand.php';
        return PluginGwreportsBrand::jpeg();
    }

    public static function make(array $report, array $filters): string
    {
        $brand = self::brandJpeg();
        $pages = [];
        $chunks = array_chunk($report['rows'], 38);
        if (!$chunks) {
            $chunks = [[]];
        }
        $columns = self::COLUMNS;
        $headers = ['Chamado', 'Título', 'Categoria ITIL', 'Status', 'Grupo solucionador', 'Abertura', 'Solucionado', 'Fechamento', 'SLA TTO', 'SLA TTR', 'UST'];
        foreach ($chunks as $pageNumber => $chunk) {
            $cmd = '0.93 0.95 0.98 rg 0 770 1190 72 re f' . "\n";
            if ($brand !== null) {
                // Fit within the logo area without distorting its original proportions.
                $maxW = 152.0;
                $maxH = 50.0;
                $scale = min($maxW / $brand['width'], $maxH / $brand['height']);
                $width = $brand['width'] * $scale;
                $height = $brand['height'] * $scale;
                $xBrand = 32.0 + ($maxW - $width) / 2.0;
                $yBrand = 782.0 + ($maxH - $height) / 2.0;
                $cmd .= sprintf("q %.2f 0 0 %.2f %.2f %.2f cm /ImGW Do Q\n", $width, $height, $xBrand, $yBrand);
            } else {
                $cmd .= self::label(40, 791, 'GW | GLOBALWEB', 15);
            }
            $cmd .= self::label(200, 805, 'GW Reports | Relatório UST', 18);
            $cmd .= self::label(200, 780, 'Origem: ' . (($filters['source'] ?? 'local') === 'remote' ? 'API remota' : 'GLPI local')
                . ' | Abertura: ' . $filters['start'] . ' até ' . $filters['end']
                . '  |  Registros: ' . count($report['rows']) . '  |  Gerado: ' . date('d/m/Y H:i'), 10);
            $cmd .= self::label(self::X, 755, 'Serviço: ' . (($filters['service'] ?? 0) > 0
                ? ('Categoria ITIL #' . (int) $filters['service']) : 'Todos os serviços'), 9);
            $cmd .= '0.82 0.86 0.92 rg 32 722 1125 25 re f' . "\n";
            $x = self::X + 4;
            foreach ($headers as $i => $h) {
                $cmd .= self::label($x, 730, $h, 8);
                $x += $columns[$i];
            }
            $y = 698;
            foreach ($chunk as $i => $row) {
                if ($i % 2 === 0) {
                    $cmd .= '0.975 0.98 0.99 rg 32 ' . ($y - 8) . ' 1125 20 re f' . "\n";
                }
                $values = [
                    '#' . $row['id'], self::crop($row['title'], 32),
                    self::crop((string) ($row['category'] ?? 'Sem categoria'), 26),
                    self::crop($row['status'], 17), self::crop($row['group'], 25),
                    self::pdate($row['opened']), self::pdate($row['solved'] ?? ''),
                    self::pdate($row['closed']), strtoupper($row['tto']), strtoupper($row['ttr']), self::ust($row['ust']),
                ];
                $x = self::X + 4;
                foreach ($values as $n => $v) {
                    $color = '0.13 0.18 0.24';
                    if ($n === 8 || $n === 9) {
                        $color = match (PluginGwreportsFilters::upperStatus((string) $v)) {
                            'SIM' => '0.05 0.48 0.19',
                            'NÃO' => '0.75 0.09 0.12',
                            'PENDENTE' => '0.64 0.39 0.02',
                            default => '0.38 0.41 0.46',
                        };
                    }
                    $cmd .= self::label($x, $y, (string) $v, 8, $color);
                    $x += $columns[$n];
                }
                $y -= 17;
            }
            if ($pageNumber === count($chunks) - 1) {
                $cmd .= self::label(self::X, 44,
                    'TOTAL UST IDENTIFICADA: ' . self::ust((float) $report['total_ust']) .
                    '   |   Chamados sem UST: ' . $report['without_ust'], 12);
            }
            $cmd .= self::label(1050, 18, 'Página ' . ($pageNumber + 1) . '/' . count($chunks), 9);
            $pages[] = $cmd;
        }
        return self::assemble($pages, $brand);
    }

    private static function assemble(array $contents, ?array $brand): string
    {
        $objects = [
            1 => '<< /Type /Catalog /Pages 2 0 R >>',
            2 => '',
            3 => '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
        ];
        $children = [];
        $number = 4;
        $imageId = null;
        if ($brand !== null) {
            $imageId = $number++;
            $bytes = $brand['data'];
            $objects[$imageId] = '<< /Type /XObject /Subtype /Image /Width ' . $brand['width']
                . ' /Height ' . $brand['height']
                . ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' . strlen($bytes)
                . ">>\nstream\n" . $bytes . "\nendstream";
        }
        foreach ($contents as $content) {
            $pageId = $number++;
            $contentId = $number++;
            $children[] = "$pageId 0 R";
            $resources = '/Font << /F1 3 0 R >>';
            if ($imageId !== null) {
                $resources .= ' /XObject << /ImGW ' . $imageId . ' 0 R >>';
            }
            $objects[$pageId] = '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' . self::W . ' ' . self::H
                . "] /Resources << $resources >> /Contents $contentId 0 R >>";
            $objects[$contentId] = '<< /Length ' . strlen($content) . ">>\nstream\n" . $content . "endstream";
        }
        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $children) . '] /Count ' . count($children) . ' >>';
        ksort($objects);
        $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
        $offsets = [0];
        foreach ($objects as $id => $obj) {
            $offsets[$id] = strlen($pdf);
            $pdf .= "$id 0 obj\n$obj\nendobj\n";
        }
        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (max(array_keys($objects)) + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= max(array_keys($objects)); $i++) {
            $pdf .= sprintf('%010d 00000 n ', $offsets[$i]) . "\n";
        }
        $pdf .= 'trailer << /Root 1 0 R /Size ' . (max(array_keys($objects)) + 1) . ">>\n";
        $pdf .= "startxref\n$xref\n%%EOF\n";
        return $pdf;
    }
}
