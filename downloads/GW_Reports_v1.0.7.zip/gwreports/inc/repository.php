<?php
/** Query engine: GLPI database; read-only. */
final class PluginGwreportsRepository
{
    private $db;
    private const MAX_ROWS = 10000;

    public function __construct($db)
    {
        $this->db = $db;
    }

    private function rows(string $sql): array
    {
        $result = $this->db->doQuery($sql);
        if ($result === false) {
            throw new RuntimeException('Falha de consulta SQL. Confira o log do GLPI.');
        }
        $out = [];
        while ($record = $this->db->fetchAssoc($result)) {
            $out[] = $record;
        }
        return $out;
    }

    private function escaped(string $value): string
    {
        return (string) $this->db->escape($value);
    }

    /** Active entity scope (profile's selected entities only). */
    private function entityIds(): array
    {
        $entities = $_SESSION['glpiactiveentities'] ?? [];
        if (!is_array($entities) || count($entities) === 0) {
            $entity = $_SESSION['glpiactive_entity'] ?? null;
            $entities = $entity === null ? [] : [$entity];
        }
        $ids = array_values(array_unique(array_map('intval', $entities)));
        $ids = array_filter($ids, static fn ($n) => $n >= 0);
        if (!$ids) {
            throw new RuntimeException('Não foi possível identificar as entidades da sessão.');
        }
        return array_values($ids);
    }

    private function entitySql(): string
    {
        return implode(',', $this->entityIds());
    }

    public function groups(): array
    {
        $entitySql = $this->entitySql();
        return $this->rows("SELECT id, name FROM glpi_groups WHERE entities_id IN ($entitySql) ORDER BY name ASC");
    }

    /** Categories visible in the currently selected entity; service = ITIL category. */
    public function services(): array
    {
        $entitySql = $this->entitySql();
        return $this->rows("SELECT id, COALESCE(NULLIF(completename, ''), name) AS name
            FROM glpi_itilcategories WHERE entities_id IN ($entitySql) ORDER BY name ASC");
    }

    public function report(array $filters): array
    {
        $sql = "SELECT t.id, t.name, t.status, t.date, t.closedate, t.solvedate, 
                    t.takeintoaccountdate, t.time_to_own, t.time_to_resolve, t.itilcategories_id,
                    COALESCE(NULLIF(cat.completename, ''), NULLIF(cat.name, ''), '') AS category_name,
                    (SELECT GROUP_CONCAT(DISTINCT grp.name ORDER BY grp.name SEPARATOR ', ')
                     FROM glpi_groups_tickets AS gt
                     INNER JOIN glpi_groups AS grp ON grp.id=gt.groups_id
                     WHERE gt.tickets_id=t.id AND gt.type=2) AS technical_groups
                FROM glpi_tickets AS t
                LEFT JOIN glpi_itilcategories AS cat ON cat.id = t.itilcategories_id
                WHERE t.is_deleted=0
                  AND t.entities_id IN (" . $this->entitySql() . ")
                  AND t.date >= '" . $this->escaped($filters['start_sql']) . "'
                  AND t.date < '" . $this->escaped($filters['end_exclusive_sql']) . "'";
        if ($filters['status'] > 0) {
            $sql .= ' AND t.status=' . (int) $filters['status'];
        }
        if (($filters['service'] ?? 0) > 0) {
            $sql .= ' AND t.itilcategories_id=' . (int) $filters['service'];
        }
        if ($filters['group'] > 0) {
            $sql .= ' AND EXISTS (SELECT 1 FROM glpi_groups_tickets AS gf'
                . ' WHERE gf.tickets_id=t.id AND gf.type=2 AND gf.groups_id=' . (int) $filters['group'] . ')';
        }
        $sql .= ' ORDER BY t.date DESC, t.id DESC LIMIT ' . (self::MAX_ROWS + 1);
        $tickets = $this->rows($sql);
        if (count($tickets) > self::MAX_ROWS) {
            throw new RuntimeException('Mais de 10.000 chamados: reduza o intervalo para garantir exportação completa.');
        }
        $ust = $this->ustForCategories(array_unique(array_map(static fn ($r) => (int) $r['itilcategories_id'], $tickets)));
        $sum = 0.0;
        $identified = 0;
        $now = date('Y-m-d H:i:s');
        $result = [];
        foreach ($tickets as $t) {
            $unit = $ust[(int) $t['itilcategories_id']] ?? null;
            if ($unit !== null) {
                $sum += $unit;
                $identified++;
            }
            $actualClose = $t['closedate'] ?: null;
            $actualSolution = $t['solvedate'] ?: $actualClose;
            $result[] = [
                'id' => (int) $t['id'],
                'title' => html_entity_decode(strip_tags((string) $t['name']), ENT_QUOTES | ENT_HTML5, 'UTF-8'),
                'status' => PluginGwreportsFilters::STATUS[(int) $t['status']] ?? ('Status ' . $t['status']),
                'category' => (int) $t['itilcategories_id'] > 0
                    ? ((string) ($t['category_name'] ?? '') !== ''
                        ? html_entity_decode(strip_tags((string) $t['category_name']), ENT_QUOTES | ENT_HTML5, 'UTF-8')
                        : 'Categoria #' . (int) $t['itilcategories_id']) : 'Sem categoria',
                'group' => (string) ($t['technical_groups'] ?: 'Sem grupo'),
                'opened' => (string) $t['date'],
                'solved' => (string) ($t['solvedate'] ?? ''),
                'closed' => (string) ($actualClose ?? ''),
                'tto' => PluginGwreportsFilters::sla($t['time_to_own'], $t['takeintoaccountdate'], $now),
                'tto_source' => $t['takeintoaccountdate'] ? 'Data nativa do GLPI' : 'Estatística nativa sem data de atendimento',
                'ttr' => PluginGwreportsFilters::sla($t['time_to_resolve'], $actualSolution, $now),
                'ust' => $unit,
            ];
        }
        return ['rows' => $result, 'total_ust' => $sum, 'with_ust' => $identified, 'without_ust' => count($result) - $identified];
    }

    /**
     * Fields plugin dynamically creates container tables. Identify by real column
     * ustfield; never guess its table. UST is looked up by ITILCategory ID.
     */
    private function ustForCategories(array $categories): array
    {
        $ids = array_values(array_filter(array_map('intval', $categories), static fn ($v) => $v > 0));
        if (!$ids) {
            return [];
        }
        $tables = $this->rows("SHOW TABLES LIKE 'glpi_plugin_fields_%'");
        $matching = [];
        foreach ($tables as $record) {
            $table = (string) reset($record);
            if (!preg_match('/^glpi_plugin_fields_[a-z0-9_]+$/D', $table)) {
                continue;
            }
            $columns = $this->rows('SHOW COLUMNS FROM `' . $table . '`');
            $names = array_map(static fn ($c) => $c['Field'], $columns);
            if (in_array('ustfield', $names, true)
                && in_array('items_id', $names, true)
                && in_array('itemtype', $names, true)) {
                $matching[] = [$table, in_array('plugin_fields_containers_id', $names, true)];
            }
        }
        if (count($matching) > 1) {
            throw new RuntimeException('Há mais de uma tabela com campo ustfield. Revisar os contêineres do plugin Fields.');
        }
        if (!$matching) {
            return [];
        }
        [$table, $hasContainer] = $matching[0];
        $idsSql = implode(',', $ids);
        $whereContainer = $hasContainer ? ' AND plugin_fields_containers_id=1' : '';
        $ust = $this->rows('SELECT items_id, ustfield FROM `' . $table . '`'
            . " WHERE itemtype='ITILCategory'" . $whereContainer
            . " AND items_id IN ($idsSql) ORDER BY id DESC");
        $map = [];
        foreach ($ust as $record) {
            $id = (int) $record['items_id'];
            if (!array_key_exists($id, $map)) {
                $map[$id] = PluginGwreportsFilters::ust($record['ustfield']);
            }
        }
        return $map;
    }
}
