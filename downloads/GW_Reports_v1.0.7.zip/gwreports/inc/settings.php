<?php
/** Optional API configuration; secrets encrypted with the GLPI installation key. */
final class PluginGwreportsSettings
{
    private const CTX = 'plugin:gwreports';
    private const SECRET = ['api_password', 'api_client_secret', 'api_app_token'];

    public static function get(): array
    {
        $raw = Config::getConfigurationValues(self::CTX);
        if (!is_array($raw)) {
            $raw = [];
        }
        $out = array_merge([
            'api_mode' => 'oauth_password', 'api_url' => '',
            'api_username' => '', 'api_password' => '',
            'api_client_id' => '', 'api_client_secret' => '', 'api_app_token' => '',
            'ust_fallback' => '',
        ], $raw);
        foreach (self::SECRET as $field) {
            $value = (string) $out[$field];
            if (str_starts_with($value, 'encrypted:v1:')) {
                try {
                    $out[$field] = (string) (new GLPIKey())->decrypt(substr($value, 13));
                } catch (Throwable $e) {
                    $out[$field] = '';
                }
            } elseif ($value !== '') {
                // Never expose unencrypted legacy values to the interface.
                $out[$field] = '';
            }
        }
        return $out;
    }

    public static function save(array $post): void
    {
        $existing = self::get();
        $url = trim((string) ($post['api_url'] ?? ''));
        if ($url !== '' && (!filter_var($url, FILTER_VALIDATE_URL)
            || strtolower((string) parse_url($url, PHP_URL_SCHEME)) !== 'https')) {
            throw new InvalidArgumentException('Utilize URL HTTPS válida para a API.');
        }
        $mode = (string) ($post['api_mode'] ?? 'oauth_password');
        if (!in_array($mode, ['oauth_password', 'legacy_basic'], true)) {
            throw new InvalidArgumentException('Método de autenticação inválido.');
        }
        $values = [
            'api_mode' => $mode,
            'api_url' => rtrim($url, '/'),
            'api_username' => trim((string) ($post['api_username'] ?? '')),
            'api_client_id' => trim((string) ($post['api_client_id'] ?? '')),
            'ust_fallback' => self::validatedUstFallback((string) ($post['ust_fallback'] ?? '')),
        ];
        $key = new GLPIKey();
        foreach (self::SECRET as $field) {
            $new = (string) ($post[$field] ?? '');
            if ($new === '') {
                if (!empty($existing[$field])) {
                    $values[$field] = 'encrypted:v1:' . $key->encrypt((string) $existing[$field]);
                } else {
                    $values[$field] = '';
                }
            } else {
                $values[$field] = 'encrypted:v1:' . $key->encrypt($new);
            }
        }
        Config::setConfigurationValues(self::CTX, $values);
    }

    /** Optional manually confirmed UST values by remote ITIL category ID. */
    public static function validatedUstFallback(string $text): string
    {
        $map = [];
        foreach (preg_split('/\r?\n/', trim($text)) as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (!preg_match('/^([1-9][0-9]{0,9})\s*=\s*([0-9]{1,7}(?:[.,][0-9]{1,4})?)$/D', $line, $m)) {
                throw new InvalidArgumentException('Mapeamento UST inválido. Utilize uma linha por categoria, ex.: 952=1.');
            }
            if (isset($map[$m[1]])) {
                throw new InvalidArgumentException('ID de categoria duplicado no mapeamento UST.');
            }
            $map[$m[1]] = str_replace(',', '.', $m[2]);
        }
        if (count($map) > 500) {
            throw new InvalidArgumentException('Limite de 500 categorias no mapeamento UST.');
        }
        ksort($map, SORT_NUMERIC);
        return implode("\n", array_map(static fn($id) => $id . '=' . $map[$id], array_keys($map)));
    }

    public static function ustFallbackMap(?array $config = null): array
    {
        $config = $config ?? self::get();
        $text = self::validatedUstFallback((string) ($config['ust_fallback'] ?? ''));
        $map = [];
        foreach (explode("\n", $text) as $line) {
            if ($line !== '') {
                [$id, $value] = explode('=', $line, 2);
                $map[(int) $id] = (float) $value;
            }
        }
        return $map;
    }

    public static function configured(): bool
    {
        $c = self::get();
        if ($c['api_url'] === '' || $c['api_username'] === '' || $c['api_password'] === '') {
            return false;
        }
        if ($c['api_mode'] === 'legacy_basic') {
            return true;
        }
        return $c['api_client_id'] !== '' && $c['api_client_secret'] !== '';
    }
}
