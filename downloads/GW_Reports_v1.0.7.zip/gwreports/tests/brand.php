<?php
/** Offline brand regression tests: no GLPI server or network. */
$temp = sys_get_temp_dir() . '/gwreports-brand-test-' . getmypid();
define('GLPI_VAR_DIR', $temp);
require_once __DIR__ . '/../inc/brand.php';
require_once __DIR__ . '/../inc/filters.php';
require_once __DIR__ . '/../inc/pdf.php';
$logo = PluginGwreportsBrand::jpeg();
if (!$logo || $logo['custom']) { throw new RuntimeException('Fallback não disponível'); }
$original = file_get_contents(PluginGwreportsBrand::bundledPath());
PluginGwreportsBrand::saveBytes($original);
$custom = PluginGwreportsBrand::jpeg();
if (!$custom || !$custom['custom']) { throw new RuntimeException('Logomarca personalizada não selecionada'); }
$pdf = PluginGwreportsPdf::make([
    'rows' => [['id'=>1, 'title'=>'Teste', 'category'=>'Teste', 'status'=>'Novo',
        'group'=>'N1', 'opened'=>'2026-11-11 10:00:00', 'solved'=>'', 'closed'=>'',
        'tto'=>'Pendente', 'ttr'=>'Pendente', 'ust'=>1.0]],
    'total_ust'=>1.0, 'with_ust'=>1, 'without_ust'=>0
], ['start'=>'2026-11-11','end'=>'2026-11-11','source'=>'local','service'=>0]);
if (!str_contains($pdf, '/Subtype /Image') || !str_contains($pdf, '/ImGW Do')) {
    throw new RuntimeException('Logo não encontrado no PDF');
}
try {
    PluginGwreportsBrand::normalizeToJpeg('INVALIDO');
    throw new RuntimeException('Imagem inválida foi aceita');
} catch (InvalidArgumentException $e) {
    // expected
}
@unlink(PluginGwreportsBrand::customPath());
@rmdir(dirname(PluginGwreportsBrand::customPath()));
@rmdir(dirname(dirname(PluginGwreportsBrand::customPath())));
@rmdir($temp);
echo "OK: logomarca via web e PDF\n";
