<?php
require_once __DIR__ . '/../inc/filters.php';
require_once __DIR__ . '/../inc/repository.php';
class GwFakeResult { public array $data; public function __construct(array $data){$this->data=$data;} }
class GwFakeDB {
    public array $sql=[];
    public function escape($v){ return addslashes($v); }
    public function doQuery($q) {
        $this->sql[]=$q;
        if (str_starts_with($q,'SHOW TABLES')) return new GwFakeResult([['Tables'=>'glpi_plugin_fields_itilcategoryusts']]);
        if (str_starts_with($q, 'SHOW COLUMNS')) return new GwFakeResult([
          ['Field'=>'id'],['Field'=>'items_id'],['Field'=>'itemtype'],
          ['Field'=>'plugin_fields_containers_id'],['Field'=>'ustfield'],
        ]);
        if (str_contains($q,'FROM `glpi_plugin_fields_itilcategoryusts`')) return new GwFakeResult([
          ['items_id'=>952,'ustfield'=>'1'],['items_id'=>953,'ustfield'=>'2,5'],
        ]);
        if (str_contains($q,'FROM glpi_groups WHERE')) return new GwFakeResult([['id'=>12,'name'=>'POC N1']]);
        if (str_contains($q,'FROM glpi_itilcategories WHERE')) return new GwFakeResult([
            ['id'=>952,'name'=>'Acesso > Configuração de navegadores'],
            ['id'=>953,'name'=>'Acesso > Configuração de rede sem fio'],
        ]);
        if (str_contains($q,'FROM glpi_tickets AS t')) return new GwFakeResult([
          ['id'=>8,'name'=>'Teste de navegação','status'=>2,'date'=>'2026-11-11 08:00:00',
            'closedate'=>null,'solvedate'=>null,'takeintoaccountdate'=>'2026-11-11 08:10:00',
            'time_to_own'=>'2026-11-11 09:00:00','time_to_resolve'=>'2026-11-11 16:00:00',
            'itilcategories_id'=>952,'category_name'=>'Acesso > Configuração de navegadores','technical_groups'=>'POC N1'],
          ['id'=>9,'name'=>'Wi-fi','status'=>5,'date'=>'2026-11-11 08:00:00',
            'closedate'=>null,'solvedate'=>'2026-11-11 10:00:00','takeintoaccountdate'=>'2026-11-11 08:30:00',
            'time_to_own'=>'2026-11-11 09:00:00','time_to_resolve'=>'2026-11-11 16:00:00',
            'itilcategories_id'=>953,'category_name'=>'Acesso > Rede sem fio','technical_groups'=>'POC N1'],
          ['id'=>10,'name'=>'Sem UST','status'=>1,'date'=>'2026-11-11 08:00:00',
            'closedate'=>null,'solvedate'=>null,'takeintoaccountdate'=>null,
            'time_to_own'=>null,'time_to_resolve'=>null,
            'itilcategories_id'=>999,'category_name'=>'','technical_groups'=>null],
        ]);
        return new GwFakeResult([]);
    }
    public function fetchAssoc(GwFakeResult $r) { return array_shift($r->data) ?: null; }
}
function verify($bool,$msg) { if (!$bool) { fwrite(STDERR,"FALHA: $msg\n"); exit(1); } echo "OK: $msg\n"; }
$_SESSION['glpiactiveentities']=[0];
$db=new GwFakeDB();
$r=new PluginGwreportsRepository($db);
$f=PluginGwreportsFilters::parse(['period'=>'today','group'=>'12','status'=>'2']);
$result=$r->report($f);
verify(count($result['rows'])===3, 'Leitura de chamados (mock DB)');
verify($result['total_ust']===3.5 && $result['with_ust']===2 && $result['without_ust']===1, 'UST e totalização (mock DB)');
verify($result['rows'][0]['tto']==='Sim', 'TTO conforme');
verify($result['rows'][0]['category']==='Acesso > Configuração de navegadores', 'Categoria ITIL local exibida com hierarquia');
verify($result['rows'][2]['category']==='Categoria #999', 'Fallback de categoria não existente');
verify($result['rows'][1]['ttr']==='Sim', 'TTR conforme');
verify($result['rows'][2]['ust']===null && $result['rows'][2]['tto']==='N/A', 'Sem UST/sem SLA não estimados');
verify((bool) array_filter($db->sql, fn($s)=>str_contains($s,'t.status=2')&&str_contains($s,'gf.groups_id=12')), 'Filtros usados no SQL');
verify(count($r->groups())===1, 'Grupo visível no escopo');

$services = $r->services();
verify(count($services)===2 && (int) $services[0]['id'] === 952, 'Serviços locais carregados das Categorias ITIL');
$fService = PluginGwreportsFilters::parse(['period'=>'today','service'=>'953']);
$r->report($fService);
verify((bool) array_filter($db->sql, fn($s)=>str_contains($s, 't.itilcategories_id=953')), 'Filtro Serviço aplicado à consulta SQL local');
