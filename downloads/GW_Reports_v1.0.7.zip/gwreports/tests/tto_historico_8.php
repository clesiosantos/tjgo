<?php
/** Regression: TTO is proven by first N1 assignment; requester is NOT evidence. */
require_once __DIR__ . '/../inc/filters.php';
require_once __DIR__ . '/../inc/settings.php';
require_once __DIR__ . '/../inc/remote.php';
$logs = [
 ['id'=>5602,'items_id'=>8,'itemtype_link'=>'User','date_mod'=>'2026-11-11 02:19:00',
   'new_value'=>'Adicionar um relacionamento com um item: glpi (2) (Requerente)'],
 ['id'=>5616,'items_id'=>8,'itemtype_link'=>'Group','date_mod'=>'2026-11-11 02:29:00',
   'new_value'=>'Adicionar um relacionamento com um item: POC TJGO - Solucionadores N2 (13) (Grupo técnico)'],
 ['id'=>5617,'items_id'=>8,'itemtype_link'=>'Group','date_mod'=>'2026-11-11 02:29:00',
   'new_value'=>'Excluir um link com um item: POC TJGO - Solucionadores N1 (12) (Grupo técnico)'],
 ['id'=>5603,'items_id'=>8,'itemtype_link'=>'Group','date_mod'=>'2026-11-11 02:19:00',
   'new_value'=>'Adicionar um relacionamento com um item: POC TJGO - Solucionadores N1 (12) (Grupo técnico)'],
];
function ck($ok,string $message): void {
 if (!$ok) throw new RuntimeException('FALHOU: '.$message);
 echo 'OK: '.$message.PHP_EOL;
}
ck(PluginGwreportsRemote::firstAssignmentFromLogs($logs,8)==='2026-11-11 02:19:00',
 'Primeira atribuicao N1 detectada sem confundir com requerente/remocao');
ck(PluginGwreportsRemote::firstAssignmentFromLogs([$logs[0]],8)===null,
 'Requerente sozinho nao pode confirmar TTO');
ck(PluginGwreportsFilters::sla('2026-11-11 09:00:00','2026-11-11 02:19:00')==='Sim',
 'Atribuicao antes do prazo valida TTO');
ck(PluginGwreportsFilters::displayDate('2026-11-11T02:19:00+00:00')==='11/11/2026 02:19',
 'Data formatada sem alteracao silenciosa de fuso');
$config=[
 'api_url'=>'https://teste.invalid/api.php/v2.3', 'api_mode'=>'oauth_password',
 'api_username'=>'teste', 'api_password'=>'ficticia', 'api_client_id'=>'ficticio',
 'api_client_secret'=>'ficticia', 'api_app_token'=>'ficticio', 'ust_fallback'=>'952=1',
];
$requests=[];
$mock=static function(string $path,array $headers,string $method,?string $body) use (&$requests,$logs): array {
 $requests[]=[$path,$method];
 if($path==='/token') return [200,['access_token'=>'mock']];
 if(str_starts_with($path,'/v2.3/Assistance/Ticket?')) return [206,[[
  'id'=>8,'name'=>'teste 3','date'=>'2026-11-11T02:19:00+00:00',
  'status'=>['id'=>2,'name'=>'Em atendimento (atribuído)'],
  'category'=>['id'=>952,'name'=>'Configuração de navegadores'],
  'team'=>[['id'=>13,'name'=>'N2','role'=>'assigned','type'=>'Group']],
  'take_into_account_date'=>null,'date_solve'=>null, 'resolution_date'=>'2100-11-11T15:00:00+00:00',
  'sla_tto'=>['id'=>1,'name'=>'TTO'], 'sla_ttr'=>['id'=>2,'name'=>'TTR'],
 ]]];
 if($path==='/v1/initSession') return [200,['session_token'=>'mock']];
 if($path==='/v1/listSearchOptions/ITILCategory') return [200,[]];
 if($path==='/v1/Ticket/8?get_hateoas=false&with_logs=true') return [200,[
  'time_to_own'=>'2026-11-11 09:00:00', 'takeintoaccountdate'=>null,
  'time_to_resolve'=>'2100-11-11 15:00:00', 'solvedate'=>null,
  'logs'=>$logs,
 ]];
 if($path==='/v1/killSession') return [200,[]];
 throw new RuntimeException('Endpoint nao esperado: '.$path);
};
$f=PluginGwreportsFilters::parse([
 'source'=>'remote','period'=>'custom','start'=>'2026-11-11','end'=>'2026-11-11'
 ],new DateTimeImmutable('2026-11-11 15:00:00',new DateTimeZone('UTC')));
$report=(new PluginGwreportsRemote($config,$mock))->report($f);
ck(count($report['rows'])===1,'Um chamado remoto retornado');
ck($report['rows'][0]['tto']==='Sim','TTO = Sim por historico apesar de take_into_account_date nulo');
ck(str_contains($report['rows'][0]['tto_source'],'Histórico'),'Fonte da inferencia explicitada');
ck($report['rows'][0]['ttr']==='Pendente','TTR continua pendente sem solucao (prazo futuro)');
ck($report['rows'][0]['solved']==='','Data de solucao nao confundida com prazo previsto');
ck($report['total_ust']===1.0,'UST contingencia explicita preservada');
foreach($requests as [$path,$method]) ck($method==='GET'||$path==='/token'&&$method==='POST','Nenhuma escrita na API remota');
echo "REGRESSAO CHAMADO 8 OK\n";
