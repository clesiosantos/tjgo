# Changelog

## 1.0.0 — 2026-11-16

- Criação do plugin GLPI 11 com rota pública `/Recovery` e cadastro autenticado `/Enrollment`.
- Configuração do AD local pelo navegador, LDAPS certificado, simulação por padrão.
- Redefinição/desbloqueio do AD restritos a OU autorizada e conta de serviço delegada.
- TOTP offline via QR Code, proteção de segredo GLPIKey, auditoria, controles de CSRF e tentativas.
- Revogação de segundo fator pelo painel administrativo e confirmação de e-mail opcional.
