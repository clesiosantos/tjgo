# GW Self-Service v1.0.0 — POC TJ-GO

Plugin de autosserviço de **recuperação de senhas e desbloqueio de contas do Active Directory local** para **GLPI 11**. Funciona em rede isolada, sem Entra ID e sem servidor de códigos OTP externo. Autoria do pacote POC: GlobalWEB.

> **Estado:** versão de homologação. O código passou pela análise de sintaxe PHP e testes locais do TOTP, mas **não houve teste integrado no servidor GLPI/AD do TJ-GO**. Por segurança o plugin vem **desabilitado** e em **modo simulação**. Não usar em produção sem homologação e avaliação de segurança.

## Funcionalidades

- Página **pública**, independente da senha GLPI/LDAP: `/plugins/gwselfservice/Recovery`.
- Cadastro antecipado de **TOTP** por QR Code offline, mediante **login GLPI e confirmação da senha AD atual**: `/plugins/gwselfservice/Enrollment`.
- Validação de código TOTP de 6 dígitos; janela de ±30 s; não reutilização da mesma janela após operação.
- Redefinição de senha por `unicodePwd`/LDAPS e desbloqueio via `lockoutTime=0` (somente modo real).
- **Modo simulação**: consulta AD e validação do autenticador reais, mas **não modifica o Active Directory**.
- Configuração web de host AD, porta, domínio, DN base, **OU permitida**, conta de vínculo, senha criptografada via `GLPIKey` e certificado CA.
- Ligação do TOTP ao `objectGUID` do usuário AD (não apenas ao nome de login).
- Registro de auditoria no banco do próprio plugin, sem armazenar novas senhas, senha atual, códigos usados ou QR Code em logs.
- Bloqueio de repetição de TOTP, limitação de tentativas no banco e bloqueio de contas desativadas no AD.
- Revogação administrativa de autenticadores e consulta das últimas 100 operações.
- E-mail **opcional**, via `mail()` do PHP/relay do servidor, para o endereço `mail` do AD. **Não é o SMTP configurado no GLPI**; requer MTA disponível. Não encaminha senhas.
- Tentativa de adicionar o link ao formulário de login pela carga do JavaScript do plugin; link direto funciona independentemente do tema.

## Limitações declaradas

1. **O GLPI não redefine nativamente senhas LDAP**. Este plugin implementa a extensão específica.
2. O TOTP de recuperação é **independente do 2FA de login nativo do GLPI**. O fator deve ser cadastrado no plugin **antes** de perder acesso ao AD. Sem esse cadastro, recuperação assistida pelo Service Desk.
3. Não há integração com Entra ID, telefone/SMS, WhatsApp, Power Automate, chatbot nem API terceirizada.
4. O plugin registra auditoria em tabelas próprias; **não abre automaticamente chamados ITIL 954/POP 086**. Vinculação posterior com chamadas e SLA é uma evolução separada.
5. A notificação eletrônica só ocorre se houver `mail()`/relay disponível e a configuração estiver habilitada; sua entrega deve ser comprovada no ambiente.
6. Comportamento do login personalizado e roteamento de plugins deve ser homologado no GLPI 11 instalado. O link direto para a rota pública é o método garantido pelo design do plugin.
7. Não há função de reset para contas sem segundo fator pré-cadastrado. Isso é deliberado por segurança.
8. A validação de um único TOTP pré-cadastrado demonstra posse do fator; em produção podem ser exigidos fatores adicionais ou identificação assistida, especialmente para contas privilegiadas.

## Requisitos técnicos

- GLPI >= 11.0 e < 12.0; PHP >= 8.2; extensões **ldap**, **openssl**, **mbstring**, **iconv** (mbstring e iconv são requisitos do GLPI).
- Extensões e bibliotecas TOTP/QR `RobThree\\Auth\\TwoFactorAuth` e `BaconQrCodeProvider` presentes no GLPI 11.
- Servidor GLPI com saída TCP para o AD no **LDAPS 636**, e um certificado de CA confiável. **Sem fallback LDAP não cifrado**.
- Conta de serviço AD com privilégio **Read** na OU autorizada; para modo real, delegar **Reset Password**, gravação `lockoutTime` e, opcionalmente, `pwdLastSet`, restritos à **OU de teste**.
- Uma OU dedicada a contas de demonstração, ex.: `OU=POC-Usuarios,DC=poc,DC=local`. **Não** conceder privilégios sobre toda a raiz `DC=poc,DC=local`.
- Acesso web GLPI por **HTTPS**, inclusive com proxy reverso corretamente declarado como confiável quando aplicável.
- Contas LDAP existentes no GLPI, com campo login `name` igual ao `sAMAccountName` no AD. A pessoa precisa conseguir autenticar-se inicialmente no AD para inscrever seu TOTP.

## URLs após a instalação (endereço da POC)

| Tela | URL |
| --- | --- |
| Configuração do AD | `https://poc-glpi.cco.globalweb.com.br/plugins/gwselfservice/Settings` |
| Cadastro do autenticador | `https://poc-glpi.cco.globalweb.com.br/plugins/gwselfservice/Enrollment` |
| Esqueci minha senha (sem login) | `https://poc-glpi.cco.globalweb.com.br/plugins/gwselfservice/Recovery` |
| Auditoria e revogação | `https://poc-glpi.cco.globalweb.com.br/plugins/gwselfservice/Audits` |

## Instalação no GLPI

O ZIP contém o diretório raiz `gwselfservice`. Para ser reconhecido pelo GLPI, ele deve ser colocado em `glpi/plugins/gwselfservice` e **não** em `glpi/plugins/GW_SelfService_v1.0.0`.

**ATENÇÃO:** o GLPI 11 **não oferece upload genérico de ZIP de plugins pelo menu de configuração**, portanto, sem SSH, GitOps ou gerenciador de arquivos no servidor, você precisa do time de infraestrutura para **colocar uma única vez a pasta** no diretório de plugins. **Depois disso todo cadastro, configuração, teste LDAPS, habilitação, auditoria e execução são feitos pela interface web.**

1. Solicite à equipe responsável pelo servidor GLPI que faça backup do banco e instale o diretório `gwselfservice/` em `plugins/`. O ZIP não inclui `.env` nem `.venv` e não modifica o plugin `gwreports`.
2. No GLPI, vá a **Configurar → Plugins**, instale e ative **GW Self-Service — Credenciais AD**.
3. Abra a engrenagem do plugin ou o link `/plugins/gwselfservice/Settings`.
4. Confirme host (padrão `172.19.35.22`), porta 636, domínio `poc.local`, DN `DC=poc,DC=local`, **OU de teste**, conta de serviço e senha. Preferir FQDN correspondente ao certificado, p.ex. `dc01.poc.local`, se esse nome existir.
5. Salve e use **Testar conexão salva**. Em caso de falha, verifique certificado, rota, DNS, PHP-LDAP, conta de serviço e bind DN. Configuração do certificado é feita no servidor; não desative validação TLS.
6. Deixe **Modo: Simulação** e habilite o autosserviço.
7. Use um usuário de teste importado do AD; entre no GLPI e abra a página **Enrollment**. Confirme a senha AD atual, escaneie o QR Code com aplicativo TOTP e confirme um código.
8. Abra `/Recovery` em janela anônima, selecione reset ou desbloqueio, informe login e TOTP, e confira a mensagem **Simulação registrada; nenhuma alteração no AD**. Consulte **Audits**.
9. **Somente com autorização:** delegue as permissões ao usuário de serviço na OU de testes, ajuste o campo **Modo** para `Real` e digite `ATIVAR RESET REAL`. Faça o teste com uma conta de demonstração não privilegiada. Confirme o resultado no AD e no histórico do plugin.
10. Para disponibilizar ao usuário, publique o link público na tela de login, intranet ou comunicado de atendimento. Se o GLPI não carregar JavaScript de plugin na tela de login, o link deve ser incluído pelo mecanismo de personalização já adotado na POC.

## Operações

- **Esqueci minha senha:** o usuário informa `sAMAccountName`, nova senha (>=12 caracteres com complexidade) e o código TOTP. Em modo real, o plugin grava `unicodePwd` por LDAPS. Há opção adicional para exigir troca no próximo login (`pwdLastSet=0`), que deve ser usada somente se fizer sentido para o processo de credenciais.
- **Desbloquear conta:** o usuário informa `sAMAccountName` e o código TOTP. Em modo real, o plugin executa `lockoutTime=0` no AD.
- **Administradores:** em `Audits`, um administrador com direito `config UPDATE` pode **revogar** fatores. Revogação não executa reset nem permite cadastrar fator sem senha AD atual.

## Segurança e restauração

- A senha de serviço e o segredo TOTP são cifrados via chave nativa GLPI; preservar também `glpicrypt.key` quando copiar/restaurar a instância.
- Não entregar à conta de serviço privilégios de Domain Admin; proibir contas privilegiadas na OU de testes.
- As rotas públicas exigem HTTPS e dão respostas genéricas para identidades não reconhecidas.
- Códigos e senhas não são armazenados na tabela de auditoria. O QR Code é exibido apenas durante a inscrição e não usa serviço remoto.
- Limitação de tentativas: cinco por login / dez minutos e trinta por IP / dez minutos. O contador TOTP utilizado é consumido antes de executar a operação no AD.
- Retenção de logs: a POC mantém os registros até exclusão administrativa/desinstalação; definir política de retenção e LGPD antes da produção.
- A **desinstalação apaga as quatro tabelas do plugin**, incluindo configurações, fatores e auditoria. Faça backup antes.

## Referência do procedimento TJ-GO

O POP 086 (v002, 01/08/2023) prevê validação de identidade, senha complexa e orientação de troca posterior. Este plugin troca a validação telefônica assistida por cadastro prévio e confirmação de TOTP para o **cenário de autosserviço da POC**. Não altera o procedimento de atendimento oficial do TJ-GO.

## Testes executados neste pacote

`php -l` em todos os arquivos PHP e `php tests/test_totp.php` (vetor RFC 6238, time drift, complexidade de senha, validação de DN). **Não foram realizados testes de autenticação LDAP/alteração real do AD nem instalação em um GLPI 11 executando**, pois a máquina da POC não está disponível neste ambiente de construção.
