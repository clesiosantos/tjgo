# Segurança — GW Self-Service 1.0.0

- **Modo seguro inicial:** módulo desabilitado e executando somente simulação.
- **Não expor publicamente fora da rede isolada da POC** antes de uma revisão de segurança e testes de penetração.
- **O segundo fator precisa existir ANTES da perda de acesso.** CPF, matrícula, login e dados pessoais não são prova suficiente para reset automático.
- **TLS/LDAPS obrigatório**; falhar fechado em problemas de certificado, segredo, autorização LDAP ou banco de dados.
- **Credenciais administrativas do AD não podem ser usadas como conta de serviço.** Delegar permissões mínimas somente a OU de teste.
- **O código TOTP do plugin não é o 2FA nativo do login GLPI**, e o acesso ao painel de cadastro exige senha AD atual adicional.
- **Sem suporte a contas privilegiadas, recuperação sem fator e PINs enviados a e-mail corporativo dependente da senha perdida**.
- **A rotina opcional de e-mail não transmite senha nem fator TOTP**. A entrega não é garantida sem um MTA local configurado.
- **Cuidado com proxy reverso:** os cabeçalhos HTTPS precisam estar corretamente definidos na configuração do GLPI, senão o plugin bloqueia as páginas sensíveis.
- **Teste obrigatório:** verificar que o usuário não consegue redefinir senha de outro usuário, entrar com código TOTP já consumido, usar fator revogado, sair da OU de testes ou afetar contas desativadas.
- Retenção de auditoria e configuração da conta de serviço devem seguir a política institucional de segurança e privacidade.
