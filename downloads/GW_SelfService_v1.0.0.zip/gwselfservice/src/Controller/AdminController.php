<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\Directory;
use GlpiPlugin\Gwselfservice\Store;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class AdminController extends AbstractController
{
    #[Route('/Settings', name: 'gwselfservice_settings', methods: ['GET', 'POST'])]
    public function settings(Request $request): Response
    {
        if (!$request->isSecure()) {
            return Ui::page('Conexão insegura', Ui::alert('Configuração e auditoria exigem HTTPS.'), false, 403);
        }
        $guard = self::guard();
        if ($guard) {
            return $guard;
        }
        $c = Store::config();
        $message = '';
        $ok = false;
        if ($request->isMethod('POST')) {
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada. Atualize a página.';
            } else {
                $action = (string)$request->request->get('action', 'save');
                if ($action === 'test') {
                    try {
                        $conn = Directory::connect($c);
                        $base = (string)($c['allowed_ou'] ?: $c['base_dn']);
                        $search = @ldap_read($conn, $base, '(objectClass=*)', ['dn'], 0, 1, 8);
                        if ($search === false) {
                            throw new \RuntimeException('Busca LDAP falhou.');
                        }
                        $ok = true;
                        $message = 'Conexão LDAPS, autenticação da conta de serviço e leitura do DN confirmadas.';
                        Store::audit('', (int)\Session::getLoginUserID(), 'config_test', 'success');
                    } catch (\Throwable $e) {
                        $message = 'Teste LDAPS falhou: valide hostname/certificado CA, conta de serviço, permissões, porta 636 e conectividade.';
                        Store::audit('', (int)\Session::getLoginUserID(), 'config_test', 'error');
                    }
                } elseif ($action === 'save') {
                    try {
                        $mode = (string)$request->request->get('mode', 'simulation');
                        $ou = trim((string)$request->request->get('allowed_ou', ''));
                        $base = trim((string)$request->request->get('base_dn', ''));
                        $confirmLive = (string)$request->request->get('confirm_live', '');
                        if (!in_array($mode, ['simulation', 'live'], true)) {
                            throw new \RuntimeException('Modo inválido.');
                        }
                        if (!Directory::withinDn($ou, $base) || $base === '') {
                            throw new \RuntimeException('A OU autorizada deve estar dentro do DN base do domínio.');
                        }
                        if ($mode === 'live' && ($ou === '' || strcasecmp($ou, $base) === 0 || $confirmLive !== 'ATIVAR RESET REAL')) {
                            throw new \RuntimeException('Para modo real, informe uma OU restrita e digite ATIVAR RESET REAL no campo de confirmação.');
                        }
                        $host = trim((string)$request->request->get('host', ''));
                        $domain = trim((string)$request->request->get('domain', ''));
                        $port = (int)$request->request->get('port', 636);
                        if (!preg_match('/^[A-Za-z0-9_.-]{1,253}$/D', $host) || !preg_match('/^[A-Za-z0-9.-]{1,253}$/D', $domain) || $port < 1 || $port > 65535) {
                            throw new \RuntimeException('Host, domínio ou porta inválido.');
                        }
                        $data = [
                            'host' => $host,
                            'port' => $port,
                            'domain' => $domain,
                            'base_dn' => $base,
                            'allowed_ou' => $ou,
                            'bind_dn' => trim((string)$request->request->get('bind_dn', '')),
                            'ca_file' => trim((string)$request->request->get('ca_file', '')),
                            'mode' => $mode,
                            'enabled' => $request->request->has('enabled') ? 1 : 0,
                            'reset_enabled' => $request->request->has('reset_enabled') ? 1 : 0,
                            'unlock_enabled' => $request->request->has('unlock_enabled') ? 1 : 0,
                            'pwd_change_next' => $request->request->has('pwd_change_next') ? 1 : 0,
                            'notify_enabled' => $request->request->has('notify_enabled') ? 1 : 0,
                            'mail_from' => trim((string)$request->request->get('mail_from', '')),
                        ];
                        $secret = (string)$request->request->get('bind_secret', '');
                        if ($secret !== '') {
                            $data['bind_secret'] = Store::encrypt($secret);
                        }
                        Store::saveConfig($data);
                        $c = Store::config();
                        $ok = true;
                        $message = 'Configurações salvas. Utilize Testar conexão antes da homologação.';
                        Store::audit('', (int)\Session::getLoginUserID(), 'config', 'saved', 'Modo ' . $mode);
                    } catch (\Throwable $e) {
                        $message = $e->getMessage();
                        Store::audit('', (int)\Session::getLoginUserID(), 'config', 'denied');
                    }
                }
            }
        }
        $body = '<div class="info"><strong>Segurança:</strong> modo simulação por padrão, sem escrita no AD. A execução real exige OU de testes, conta de serviço com delegação mínima e LDAPS validado. Não use contas privilegiadas como alvo.</div>';
        if ($message) {
            $body .= Ui::alert($message, $ok);
        }
        $body .= '<section class="panel"><h2>Servidor do Active Directory</h2><form method="post">' . Ui::formToken() . '<input type="hidden" name="action" value="save">'
            . '<div class="two">'
            . Ui::input('host', 'Host do controlador AD (FQDN recomendado)', (string)($c['host'] ?? '172.19.35.22'), 'text', 'O nome precisa coincidir com o certificado LDAPS.', true)
            . Ui::input('port', 'Porta LDAPS', (string)($c['port'] ?? 636), 'number', 'TLS obrigatório; não suporta LDAP sem TLS.', true)
            . Ui::input('domain', 'Domínio', (string)($c['domain'] ?? 'poc.local'), 'text', '', true)
            . Ui::input('base_dn', 'DN base', (string)($c['base_dn'] ?? 'DC=poc,DC=local'), 'text', '', true)
            . '</div>'
            . Ui::input('allowed_ou', 'OU autorizada (obrigatória, especialmente no modo real)', (string)($c['allowed_ou'] ?? ''), 'text', 'Ex.: OU=POC-Usuarios,DC=poc,DC=local', true)
            . Ui::input('bind_dn', 'Conta de serviço do AD (UPN ou DN)', (string)($c['bind_dn'] ?? ''), 'text', 'Conta sem permissões de administrador do domínio.', true)
            . Ui::input('bind_secret', 'Senha da conta de serviço', '', 'password', 'Deixe em branco para preservar a senha criptografada anteriormente.')
            . Ui::input('ca_file', 'Caminho do certificado CA (opcional)', (string)($c['ca_file'] ?? ''), 'text', 'Arquivo PEM acessível pelo PHP; caso vazio, usar CAs confiáveis do sistema.')
            . '<div class="two">'
            . '<label class="field"><span>Modo</span><select name="mode"><option value="simulation"' . (($c['mode'] ?? 'simulation') === 'simulation' ? ' selected' : '') . '>Simulação (sem alteração no AD)</option><option value="live"' . (($c['mode'] ?? '') === 'live' ? ' selected' : '') . '>Real (altera o AD da OU configurada)</option></select></label>'
            . Ui::input('confirm_live', 'Confirmação para ativar modo real', '', 'text', 'Digite ATIVAR RESET REAL somente para mudar para o modo real.')
            . '</div>'
            . self::checkbox('enabled', 'Habilitar autosserviço', (int)($c['enabled'] ?? 0))
            . self::checkbox('reset_enabled', 'Permitir redefinir senha', (int)($c['reset_enabled'] ?? 1))
            . self::checkbox('unlock_enabled', 'Permitir desbloquear conta', (int)($c['unlock_enabled'] ?? 1))
            . self::checkbox('pwd_change_next', 'Exigir troca após reset (pwdLastSet=0)', (int)($c['pwd_change_next'] ?? 0))
            . self::checkbox('notify_enabled', 'Enviar e-mail de confirmação via mail() do servidor, se configurado', (int)($c['notify_enabled'] ?? 0))
            . Ui::input('mail_from', 'Remetente da notificação por e-mail', (string)($c['mail_from'] ?? ''), 'email', 'Requer MTA/relay local disponível no PHP. Não utiliza automaticamente o SMTP do GLPI.')
            . '<div class="actions"><button type="submit">Salvar configurações</button></div></form>'
            . '<form method="post">' . Ui::formToken() . '<input type="hidden" name="action" value="test"><button type="submit" class="secondary">Testar conexão salva</button></form></section>'
            . '<section class="note"><strong>Links para o TJ-GO:</strong><p>Cadastro TOTP: <a href="' . Ui::h(Ui::url('Enrollment')) . '">' . Ui::h(Ui::url('Enrollment')) . '</a></p><p>Esqueci minha senha (público): <a href="' . Ui::h(Ui::url('Recovery')) . '">' . Ui::h(Ui::url('Recovery')) . '</a></p></section>';
        return Ui::page('Configuração do Active Directory', $body);
    }

    #[Route('/Audits', name: 'gwselfservice_audits', methods: ['GET', 'POST'])]
    public function audits(Request $request): Response
    {
        if (!$request->isSecure()) {
            return Ui::page('Conexão insegura', Ui::alert('Configuração e auditoria exigem HTTPS.'), false, 403);
        }
        $guard = self::guard();
        if ($guard) {
            return $guard;
        }
        $message = '';
        if ($request->isMethod('POST')) {
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada.';
            } else {
                $id = (int)$request->request->get('factor_id', 0);
                $confirm = (string)$request->request->get('confirm', '');
                $factor = $id > 0 ? Store::first('glpi_plugin_gwselfservice_factors', ['id' => $id]) : null;
                if (!$factor || $confirm !== 'REVOGAR') {
                    $message = 'Fator não encontrado ou confirmação inválida.';
                } else {
                    Store::resetFactor($id);
                    Store::audit((string)$factor['login'], (int)$factor['users_id'], 'factor_revoke', 'success', 'Revogado por administrador ID ' . \Session::getLoginUserID());
                    $message = 'Autenticador revogado. O usuário deverá cadastrar novamente com a senha atual do AD.';
                }
            }
        }
        global $DB;
        $rows = '';
        foreach ($DB->request(['FROM' => 'glpi_plugin_gwselfservice_audits', 'ORDER' => ['id DESC'], 'LIMIT' => 100]) as $r) {
            $rows .= '<tr><td>' . Ui::h((string)$r['created_at']) . '</td><td>' . Ui::h((string)$r['login']) . '</td><td>' . Ui::h((string)$r['operation']) . '</td><td>' . Ui::h((string)$r['result']) . '</td><td>' . Ui::h((string)$r['ip']) . '</td></tr>';
        }
        $factors = '';
        foreach ($DB->request(['FROM' => 'glpi_plugin_gwselfservice_factors', 'ORDER' => ['id DESC'], 'LIMIT' => 200]) as $r) {
            $factors .= '<tr><td>' . (int)$r['id'] . '</td><td>' . Ui::h((string)$r['login']) . '</td><td>' . ((int)$r['enabled'] ? 'Ativo' : 'Revogado') . '</td><td>' . Ui::h((string)$r['updated_at']) . '</td></tr>';
        }
        $body = ($message !== '' ? Ui::alert($message) : '')
            . '<section class="panel"><h2>Últimas 100 operações</h2><div class="table"><table><thead><tr><th>Data</th><th>Login</th><th>Ação</th><th>Resultado</th><th>IP</th></tr></thead><tbody>' . $rows . '</tbody></table></div></section>'
            . '<section class="panel"><h2>Fatores cadastrados</h2><div class="table"><table><thead><tr><th>ID</th><th>Login</th><th>Situação</th><th>Atualização</th></tr></thead><tbody>' . $factors . '</tbody></table></div>'
            . '<form method="post">' . Ui::formToken()
            . Ui::input('factor_id', 'ID do fator a revogar', '', 'number', '', true)
            . Ui::input('confirm', 'Confirme com REVOGAR', '', 'text', 'Não fornece reset de senha nem permite assumir a identidade do usuário.', true)
            . '<button class="danger" type="submit">Revogar fator</button></form></section>';
        return Ui::page('Auditoria e cadastro de autenticadores', $body);
    }

    private static function guard(): ?Response
    {
        return \Session::haveRight('config', UPDATE)
            ? null
            : Ui::page('Acesso restrito', Ui::alert('Apenas administradores com permissão de configuração podem acessar esta página.'), false, 403);
    }

    private static function checkbox(string $name, string $label, int $enabled): string
    {
        return '<label class="checkbox"><input type="checkbox" name="' . Ui::h($name) . '" value="1" ' . ($enabled ? 'checked' : '') . '> ' . Ui::h($label) . '</label>';
    }
}
