<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\Directory;
use GlpiPlugin\Gwselfservice\Store;
use GlpiPlugin\Gwselfservice\Totp;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class EnrollmentController extends AbstractController
{
    #[Route('/Enrollment', name: 'gwselfservice_enrollment', methods: ['GET', 'POST'])]
    public function __invoke(Request $request): Response
    {
        if (!$request->isSecure()) {
            return Ui::page('Conexão insegura', Ui::alert('Este recurso exige HTTPS e configuração correta do proxy reverso, se existir.'), false, 403);
        }
        $userId = (int)\Session::getLoginUserID();
        if ($userId < 1) {
            return Ui::page('Cadastrar autenticador', Ui::alert('Autentique-se no GLPI para cadastrar o fator de recuperação.'), false, 403);
        }
        $user = Store::first('glpi_users', ['id' => $userId]);
        $login = (string)($user['name'] ?? '');
        $config = Store::config();
        if (empty($config['enabled'])) {
            return Ui::page('Cadastrar autenticador', Ui::alert('O módulo não está habilitado. Solicite a configuração ao administrador.'), false, 503);
        }
        $existing = Store::factorByUser($userId);
        if ($existing && (int)$existing['enabled'] === 1) {
            return Ui::page('Cadastrar autenticador', '<section class="panel"><h2>Método cadastrado</h2><p>Existe um autenticador ativo para sua conta. Para substituí-lo, solicite ao administrador a revogação do cadastro antigo. A revogação não redefine sua senha.</p></section>');
        }
        $message = '';
        $success = false;
        if ($request->isMethod('POST')) {
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada. Atualize a página.';
            } else {
                $action = (string)$request->request->get('action', '');
                if ($action === 'begin') {
                    $password = (string)$request->request->get('ad_password', '');
                    try {
                        if (!Directory::authenticateUser($config, $login, $password)) {
                            throw new \RuntimeException('Senha atual do Active Directory inválida.');
                        }
                        $conn = Directory::connect($config);
                        $account = Directory::findAccount($conn, $config, $login);
                        if (!$account || strcasecmp($account['login'], $login) !== 0) {
                            throw new \RuntimeException('A conta autenticada não foi encontrada na OU autorizada.');
                        }
                        $_SESSION['gwss_enroll'] = [
                            'uid' => $userId,
                            'login' => $login,
                            'guid' => $account['guid'],
                            'secret' => Totp::createSecret(),
                            'expiry' => time() + 600,
                        ];
                        Store::audit($login, $userId, 'enroll', 'started');
                        $message = 'Senha do AD validada. Cadastre o aplicativo e confirme um código.';
                        $success = true;
                    } catch (\Throwable $e) {
                        Store::audit($login, $userId, 'enroll', 'denied');
                        $message = 'Não foi possível validar sua senha atual do AD ou localizar sua conta na OU autorizada.';
                    }
                } elseif ($action === 'confirm') {
                    $pending = $_SESSION['gwss_enroll'] ?? [];
                    $code = (string)$request->request->get('totp', '');
                    $ip = (string)($request->getClientIp() ?? '');
                    if (!Store::allowAttempt('enroll:' . $login, $ip)) {
                        $message = 'Excesso de tentativas. Tente novamente mais tarde.';
                    } elseif (($pending['uid'] ?? 0) !== $userId || ($pending['login'] ?? '') !== $login
                        || ($pending['expiry'] ?? 0) < time()) {
                        $message = 'Cadastro expirado. Inicie novamente.';
                        unset($_SESSION['gwss_enroll']);
                    } elseif (Totp::verify((string)$pending['secret'], $code) === null) {
                        Store::audit($login, $userId, 'enroll', 'totp_denied');
                        $message = 'Código inválido. Confira o relógio do telefone e tente novamente.';
                    } else {
                        try {
                            Store::upsertFactor($userId, $login, (string)$pending['guid'], (string)$pending['secret']);
                            Store::audit($login, $userId, 'enroll', 'success');
                            unset($_SESSION['gwss_enroll']);
                            $message = 'Autenticador cadastrado com sucesso. Agora você poderá recuperar sua conta pelo portal público.';
                            $success = true;
                        } catch (\Throwable $e) {
                            $message = 'Erro ao proteger o segredo no GLPI. Nenhum autenticador foi cadastrado.';
                        }
                    }
                }
            }
        }
        $pending = $_SESSION['gwss_enroll'] ?? [];
        $body = '<div class="info">O cadastro exige login no GLPI e validação adicional da senha atual do AD. Nenhuma senha será armazenada.</div>';
        if ($message !== '') {
            $body .= Ui::alert($message, $success);
        }
        if (!empty($pending) && ($pending['uid'] ?? 0) === $userId && ($pending['expiry'] ?? 0) >= time()) {
            $secret = (string)$pending['secret'];
            $qr = Totp::qrDataUri($login, $secret);
            $body .= '<section class="panel"><h2>2. Escaneie o QR Code</h2><p>Use um aplicativo TOTP instalado no seu telefone. O código será gerado sem internet.</p>'
                . ($qr !== '' ? '<img class="qrcode" src="' . Ui::h($qr) . '" alt="QR Code do autenticador">' : '<div class="info">QR Code indisponível; insira o segredo manualmente.</div>')
                . '<p>Chave manual: <code>' . Ui::h($secret) . '</code></p><form method="post">' . Ui::formToken()
                . '<input type="hidden" name="action" value="confirm">'
                . Ui::input('totp', 'Código de confirmação (6 dígitos)', '', 'text', '', true)
                . '<button type="submit">Ativar autenticador</button></form></section>';
        } else {
            $body .= '<section class="panel"><h2>1. Confirme sua senha atual do AD</h2><p>Usuário autenticado: <strong>' . Ui::h($login) . '</strong></p><form method="post">' . Ui::formToken()
                . '<input type="hidden" name="action" value="begin">'
                . Ui::input('ad_password', 'Senha atual do AD', '', 'password', '', true)
                . '<button type="submit">Validar senha e gerar QR Code</button></form></section>';
        }
        return Ui::page('Cadastrar autenticador', $body);
    }
}
