<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use GlpiPlugin\Gwselfservice\Directory;
use GlpiPlugin\Gwselfservice\Notifier;
use GlpiPlugin\Gwselfservice\Store;
use GlpiPlugin\Gwselfservice\Totp;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class RecoveryController extends AbstractController
{
    #[Route('/Recovery', name: 'gwselfservice_recovery', methods: ['GET', 'POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function __invoke(Request $request): Response
    {
        if (!$request->isSecure()) {
            return Ui::page('Conexão insegura', Ui::alert('Este recurso exige HTTPS. Peça à infraestrutura que configure TLS e, se houver proxy, os cabeçalhos de proxy confiável.'), true, 403);
        }
        $config = Store::config();
        $message = '';
        $success = false;
        if ($request->isMethod('POST')) {
            $login = trim((string)$request->request->get('login', ''));
            $operation = (string)$request->request->get('operation', '');
            $code = (string)$request->request->get('totp', '');
            $password = (string)$request->request->get('new_password', '');
            $confirmation = (string)$request->request->get('confirm_password', '');
            $ip = (string)($request->getClientIp() ?? '');
            $message = 'Não foi possível concluir a solicitação. Verifique seus dados ou procure o Service Desk.';
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada. Atualize a página e tente novamente.';
            } elseif (!Store::allowAttempt($login, $ip)) {
                Store::audit($login, 0, 'rate_limit', 'blocked');
                $message = 'Número de tentativas excedido. Tente novamente mais tarde ou procure o Service Desk.';
            } elseif (empty($config['enabled']) || !in_array($operation, ['reset', 'unlock'], true)
                || ($operation === 'reset' && empty($config['reset_enabled']))
                || ($operation === 'unlock' && empty($config['unlock_enabled']))) {
                Store::audit($login, 0, $operation, 'unavailable');
            } elseif ($operation === 'reset' && ($password !== $confirmation || !Totp::passwordStrong($password))) {
                $message = 'Informe uma senha com 12 a 120 caracteres, maiúscula, minúscula, número e símbolo, e confirme-a corretamente.';
            } else {
                try {
                    $ldap = Directory::connect($config);
                    $account = Directory::findAccount($ldap, $config, $login);
                    $factor = $account ? Store::factorByGuid($account['guid']) : null;
                    if (!$account || !$factor) {
                        Store::audit($login, 0, $operation, 'identity_denied');
                    } else {
                        $secret = Store::decrypt((string)$factor['secret_cipher']);
                        $counter = Totp::verify($secret, $code);
                        $uid = (int)$factor['users_id'];
                        if ($counter === null || !Store::consumeCounter((int)$factor['id'], $counter)) {
                            Store::audit($login, $uid, $operation, 'totp_denied');
                        } elseif (($config['mode'] ?? 'simulation') !== 'live') {
                            Store::audit($login, $uid, $operation, 'simulated', 'Operação apenas demonstrativa; sem escrita no AD');
                            Notifier::sendIfEnabled($config, $account, $operation, true, $uid);
                            $message = 'Identidade validada. Simulação registrada com sucesso: nenhuma alteração foi feita no Active Directory.';
                            $success = true;
                        } else {
                            // Admin must have opted into live mode with a test OU.
                            $allow = trim((string)($config['allowed_ou'] ?? ''));
                            if ($allow === '' || strcasecmp($allow, (string)($config['base_dn'] ?? '')) === 0) {
                                throw new \RuntimeException('O modo real requer uma OU restrita distinta da base do domínio.');
                            }
                            if ($operation === 'reset') {
                                Directory::resetPassword($ldap, $account['dn'], $password, !empty($config['pwd_change_next']));
                            } else {
                                Directory::unlock($ldap, $account['dn']);
                            }
                            Store::audit($login, $uid, $operation, 'success', 'Operação LDAP concluída');
                            Notifier::sendIfEnabled($config, $account, $operation, false, $uid);
                            $message = $operation === 'reset'
                                ? 'Identidade confirmada. A senha foi redefinida no Active Directory.'
                                : 'Identidade confirmada. O desbloqueio foi enviado ao Active Directory.';
                            $success = true;
                        }
                    }
                } catch (\Throwable $e) {
                    error_log('GW Self-Service: operação LDAP falhou (detalhes omitidos no portal).');
                    Store::audit($login, 0, $operation, 'technical_error');
                }
            }
        }
        $mode = ($config['mode'] ?? 'simulation') === 'live' ? 'execução real' : 'simulação segura';
        $notice = '<div class="info">O login no GLPI não é necessário. A identidade é verificada pelo aplicativo autenticador cadastrado antecipadamente. Ambiente em <strong>' . Ui::h($mode) . '</strong>.</div>';
        $form = '<section class="panel"><h2>Minha conta está bloqueada ou esqueci minha senha</h2><p>Informe o login do domínio e o código temporário do aplicativo autenticador.</p><form method="post" autocomplete="off">' . Ui::formToken()
            . Ui::input('login', 'Login do AD (sem @poc.local)', '', 'text', 'Ex.: joao.silva', true)
            . '<fieldset class="choice"><legend>O que deseja fazer?</legend><label><input type="radio" name="operation" value="reset" checked> Redefinir minha senha</label><label><input type="radio" name="operation" value="unlock"> Desbloquear minha conta</label></fieldset>'
            . Ui::input('totp', 'Código de 6 dígitos do autenticador', '', 'text', 'O aplicativo funciona mesmo sem acesso ao AD ou à internet.', true)
            . Ui::input('new_password', 'Nova senha (somente para redefinição)', '', 'password', 'Mínimo 12 caracteres, maiúscula, minúscula, número e símbolo.')
            . Ui::input('confirm_password', 'Confirme a nova senha (somente para redefinição)', '', 'password')
            . '<button type="submit">Validar identidade e executar</button></form></section>';
        $body = $notice . ($message !== '' ? Ui::alert($message, $success) : '') . $form
            . '<section class="note"><strong>Ainda não cadastrou seu autenticador?</strong> Para sua segurança, o cadastro exige uma autenticação inicial com sua senha atual. <a href="' . Ui::h(Ui::url('Enrollment')) . '">Cadastrar antes de perder o acesso</a>. Caso já esteja sem acesso, procure o Service Desk.</section>';
        return Ui::page('Recuperação de credenciais', $body, true);
    }
}
