<?php
namespace GlpiPlugin\Gwselfservice;

final class Directory
{
    /** Bind always uses certificate-validated LDAPS. */
    public static function connect(array $config, ?string $overrideDn = null, ?string $overridePassword = null): \LDAP\Connection
    {
        if (!extension_loaded('ldap')) {
            throw new \RuntimeException('A extensão LDAP do PHP não está habilitada.');
        }
        $host = trim((string)($config['host'] ?? ''));
        $port = (int)($config['port'] ?? 636);
        if (!preg_match('/^[a-zA-Z0-9_.-]{1,253}$/D', $host) || $port < 1 || $port > 65535) {
            throw new \RuntimeException('Host ou porta LDAPS inválidos.');
        }
        $caFile = trim((string)($config['ca_file'] ?? ''));
        if ($caFile !== '') {
            if (!is_file($caFile) || !is_readable($caFile)) {
                throw new \RuntimeException('Arquivo CA informado não está acessível pelo PHP.');
            }
            if (!@ldap_set_option(null, LDAP_OPT_X_TLS_CACERTFILE, $caFile)) {
                throw new \RuntimeException('Não foi possível configurar o certificado CA LDAP.');
            }
        }
        if (defined('LDAP_OPT_X_TLS_REQUIRE_CERT') && defined('LDAP_OPT_X_TLS_DEMAND')) {
            if (!@ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, LDAP_OPT_X_TLS_DEMAND)) {
                throw new \RuntimeException('Não foi possível impor a validação do certificado LDAPS.');
            }
        }
        $ldap = ldap_connect('ldaps://' . $host . ':' . $port);
        if (!$ldap) {
            throw new \RuntimeException('Não foi possível inicializar a conexão LDAPS.');
        }
        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
        ldap_set_option($ldap, LDAP_OPT_NETWORK_TIMEOUT, 8);
        ldap_set_option($ldap, LDAP_OPT_TIMELIMIT, 8);
        $user = $overrideDn ?? trim((string)($config['bind_dn'] ?? ''));
        $password = $overridePassword ?? Store::decrypt((string)($config['bind_secret'] ?? ''));
        if ($user === '' || $password === '') {
            throw new \RuntimeException('É necessário configurar a conta e a senha de vínculo ao AD.');
        }
        if (!@ldap_bind($ldap, $user, $password)) {
            throw new \RuntimeException('Falha na conexão segura ou na autenticação LDAP.');
        }
        return $ldap;
    }

    /** Return a single AD user restricted to the configured OU. */
    public static function findAccount(\LDAP\Connection $ldap, array $config, string $login): ?array
    {
        if (!preg_match('/^[\pL\pN._-]{1,120}$/uD', $login)) {
            return null;
        }
        $baseDn = trim((string)($config['base_dn'] ?? ''));
        $allowedOu = trim((string)($config['allowed_ou'] ?? ''));
        $searchDn = $allowedOu !== '' ? $allowedOu : $baseDn;
        if ($searchDn === '') {
            throw new \RuntimeException('Base DN ausente.');
        }
        $escaped = ldap_escape($login, '', LDAP_ESCAPE_FILTER);
        $filter = '(&(objectCategory=person)(objectClass=user)(sAMAccountName=' . $escaped . '))';
        $result = @ldap_search($ldap, $searchDn, $filter, ['dn','objectGUID','sAMAccountName','userAccountControl','mail'], 0, 2, 8);
        if ($result === false) {
            throw new \RuntimeException('Erro ao consultar o diretório LDAP.');
        }
        $entries = ldap_get_entries($ldap, $result);
        if ((int)($entries['count'] ?? 0) !== 1) {
            return null;
        }
        $entry = $entries[0];
        $dn = (string)$entry['dn'];
        if ($allowedOu !== '' && !self::withinDn($dn, $allowedOu)) {
            return null;
        }
        $guid = $entry['objectguid'][0] ?? '';
        if (!is_string($guid) || strlen($guid) !== 16) {
            throw new \RuntimeException('ObjectGUID não disponível no diretório.');
        }
        $uac = (int)($entry['useraccountcontrol'][0] ?? 0);
        if (($uac & 2) !== 0) {
            return null; // Reject disabled AD accounts.
        }
        return ['dn' => $dn, 'guid' => bin2hex($guid), 'login' => (string)$entry['samaccountname'][0], 'email' => (string)($entry['mail'][0] ?? '')];
    }

    public static function withinDn(string $dn, string $base): bool
    {
        $dn = function_exists('mb_strtolower') ? mb_strtolower(trim($dn)) : strtolower(trim($dn));
        $base = function_exists('mb_strtolower') ? mb_strtolower(trim($base)) : strtolower(trim($base));
        return $dn === $base || str_ends_with($dn, ',' . $base);
    }

    public static function authenticateUser(array $config, string $login, string $password): bool
    {
        if ($password === '' || !preg_match('/^[\pL\pN._-]{1,120}$/uD', $login)) {
            return false;
        }
        $domain = (string)($config['domain'] ?? '');
        if (!preg_match('/^[a-zA-Z0-9.-]+$/D', $domain)) {
            return false;
        }
        try {
            self::connect($config, $login . '@' . $domain, $password);
            return true;
        } catch (\Throwable $e) {
            return false;
        }
    }

    public static function resetPassword(\LDAP\Connection $ldap, string $dn, string $password, bool $forceChange): void
    {
        if (!Totp::passwordStrong($password)) {
            throw new \RuntimeException('A senha não atende aos requisitos de complexidade.');
        }
        // Active Directory reset: replace unicodePwd with quoted UTF-16LE bytes.
        $utf16 = iconv('UTF-8', 'UTF-16LE', '"' . $password . '"');
        if ($utf16 === false || !@ldap_mod_replace($ldap, $dn, ['unicodePwd' => $utf16])) {
            throw new \RuntimeException('O AD recusou a redefinição de senha (permissões, política ou TLS).');
        }
        if ($forceChange && !@ldap_mod_replace($ldap, $dn, ['pwdLastSet' => '0'])) {
            throw new \RuntimeException('Senha alterada, mas falhou ao exigir troca no próximo logon.');
        }
    }

    public static function unlock(\LDAP\Connection $ldap, string $dn): void
    {
        if (!@ldap_mod_replace($ldap, $dn, ['lockoutTime' => '0'])) {
            throw new \RuntimeException('O AD recusou o desbloqueio (permissões delegadas).');
        }
    }
}
