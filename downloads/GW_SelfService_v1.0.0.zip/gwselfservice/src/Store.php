<?php
namespace GlpiPlugin\Gwselfservice;

final class Store
{
    private const CONFIG = 'glpi_plugin_gwselfservice_configs';
    private const FACTORS = 'glpi_plugin_gwselfservice_factors';
    private const ATTEMPTS = 'glpi_plugin_gwselfservice_attempts';
    private const AUDITS = 'glpi_plugin_gwselfservice_audits';

    public static function first(string $table, array $where): ?array
    {
        global $DB;
        foreach ($DB->request(['FROM' => $table, 'WHERE' => $where, 'LIMIT' => 1]) as $row) {
            return $row;
        }
        return null;
    }

    public static function config(): array
    {
        return self::first(self::CONFIG, ['id' => 1]) ?? [];
    }

    public static function encrypt(string $value): string
    {
        $cipher = (new \GLPIKey())->encrypt($value);
        if (!is_string($cipher) || $cipher === '' || $cipher === $value) {
            throw new \RuntimeException('A criptografia GLPI não está disponível; gravação cancelada.');
        }
        return $cipher;
    }

    public static function decrypt(?string $cipher): string
    {
        if (!$cipher) {
            return '';
        }
        try {
            $plain = (new \GLPIKey())->decrypt($cipher);
        } catch (\Throwable $e) {
            throw new \RuntimeException('O segredo protegido não pôde ser decifrado.');
        }
        if (!is_string($plain) || $plain === '' || $plain === $cipher) {
            throw new \RuntimeException('O segredo protegido não pôde ser decifrado.');
        }
        return $plain;
    }

    public static function saveConfig(array $values): void
    {
        global $DB;
        $DB->update(self::CONFIG, $values, ['id' => 1]);
    }

    public static function factorByGuid(string $guid): ?array
    {
        return self::first(self::FACTORS, ['ad_guid' => $guid, 'enabled' => 1]);
    }

    public static function factorByUser(int $uid): ?array
    {
        return self::first(self::FACTORS, ['users_id' => $uid]);
    }

    public static function upsertFactor(int $uid, string $login, string $guid, string $secret): void
    {
        global $DB;
        $existing = self::factorByUser($uid);
        $now = date('Y-m-d H:i:s');
        $data = [
            'login' => $login,
            'ad_guid' => $guid,
            'secret_cipher' => self::encrypt($secret),
            'last_counter' => -1,
            'enabled' => 1,
            'updated_at' => $now,
        ];
        if ($existing) {
            $DB->update(self::FACTORS, $data, ['id' => (int)$existing['id']]);
        } else {
            $DB->insert(self::FACTORS, ['users_id' => $uid, 'created_at' => $now] + $data);
        }
    }

    public static function resetFactor(int $id): void
    {
        global $DB;
        $DB->update(self::FACTORS, ['enabled' => 0, 'updated_at' => date('Y-m-d H:i:s')], ['id' => $id]);
    }

    /** Atomic consumption of a TOTP time step to prevent replay. */
    public static function consumeCounter(int $factorId, int $counter): bool
    {
        global $DB;
        $query = 'UPDATE `' . self::FACTORS . '` SET `last_counter` = ' . $counter
            . ' WHERE `id` = ' . $factorId . ' AND `enabled` = 1 AND `last_counter` < ' . $counter;
        $result = $DB->doQuery($query);
        return $result !== false && $DB->affected_rows($result) === 1;
    }

    /** Atomic fixed-window rate limits shared across all PHP workers. */
    public static function allowAttempt(string $login, string $ip): bool
    {
        global $DB;
        $checks = [
            ['login:' . mb_strtolower($login), 5],
            ['ip:' . $ip, 30],
        ];
        $allowed = true;
        foreach ($checks as [$key, $limit]) {
            $hash = hash('sha256', $key); // fixed-length hex, not raw user input
            $query = "INSERT INTO `" . self::ATTEMPTS . "` (`key_hash`,`hits`,`window_start`) "
                . "VALUES ('" . $hash . "', 1, NOW()) ON DUPLICATE KEY UPDATE "
                . "`hits` = IF(TIMESTAMPDIFF(SECOND, `window_start`, NOW()) >= 600, 1, `hits` + 1), "
                . "`window_start` = IF(TIMESTAMPDIFF(SECOND, `window_start`, NOW()) >= 600, NOW(), `window_start`)";
            if (!$DB->doQuery($query)) {
                return false; // Never allow unlimited attempts on DB failure.
            }
            $row = self::first(self::ATTEMPTS, ['key_hash' => $hash]);
            if (!$row || (int)$row['hits'] > $limit) {
                $allowed = false;
            }
        }
        return $allowed;
    }

    public static function audit(string $login, int $uid, string $operation, string $result, string $details = ''): void
    {
        global $DB;
        $DB->insert(self::AUDITS, [
            'login' => mb_substr($login, 0, 255),
            'users_id' => $uid,
            'operation' => substr($operation, 0, 40),
            'result' => substr($result, 0, 40),
            'ip' => substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
            'details' => mb_substr($details, 0, 255),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
