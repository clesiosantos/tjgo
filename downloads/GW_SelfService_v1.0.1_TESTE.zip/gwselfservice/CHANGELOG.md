# Changelog

## 1.0.1 — 2026-11-17 — TESTE

- Corrigida experiência de acesso quando GLPI informa conexão insegura: rota pública HTTP abre apenas **fluxo fictício**, sem dados AD, senha real ou TOTP.
- Tela de administração HTTP informativa, sem campos de credencial; cadastro TOTP e auditoria reais mantidos sob HTTPS.
- Trava de homologação no código impede qualquer alteração real de senha ou desbloqueio do AD mesmo se a configuração antiga estiver em modo `live`.
- Marca visual permanente “TESTE” e documentação de limitações.

# Changelog

## 1.0.0 — 2026-11-16

- Criação do plugin GLPI 11 com rota pública `/Recovery` e cadastro autenticado `/Enrollment`.
- Configuração do AD local pelo navegador, LDAPS certificado, simulação por padrão.
- Redefinição/desbloqueio do AD restritos a OU autorizada e conta de serviço delegada.
- TOTP offline via QR Code, proteção de segredo GLPIKey, auditoria, controles de CSRF e tentativas.
- Revogação de segundo fator pelo painel administrativo e confirmação de e-mail opcional.
