# GW Self-Service v1.0.1 — AMBIENTE DE TESTE

Plugin de demonstração para **GLPI 11** e POC TJ-GO. Esta é uma edição de **homologação isolada**; não deve ser instalada como solução operacional.

## O que foi ajustado

A versão 1.0.0 mostrava **Conexão insegura** sempre que o framework do GLPI não reconhecia HTTPS. Esta versão permite abrir um **portal de demonstração por HTTP**, mas **não remove a proteção de dados sensíveis**:

- O formulário de recuperação em HTTP aceita **somente dados fictícios**, sem acessar AD nem tratar senha ou segredo TOTP real.
- A tela **Settings** em HTTP é informativa. Campos de configuração do AD e senha da conta de serviço não são apresentados nem aceitos por HTTP.
- A tela **Enrollment** em HTTP é informativa. Não solicita senha atual do AD nem exibe QR Code/segredo TOTP real.
- **Audits** segue exigindo HTTPS.
- Em HTTPS, permanecem as telas de configuração de AD e cadastro de TOTP (válidas para usuários e OU de teste), mas o reset e desbloqueio são **sempre simulados**.
- A execução real de reset/desbloqueio está bloqueada em **duas camadas**: política `TestPolicy::mayWriteToAd() = false` e guardas dentro dos próprios métodos de escrita do `Directory`.
- O envio de e-mail real também está desativado nesta edição.

## Instalação / atualização

1. Faça backup da instalação e do banco GLPI antes de atualizar o plugin.
2. Extraia **somente** a pasta `gwselfservice/` deste ZIP sobre `plugins/gwselfservice/` do GLPI de testes. A pasta não deve receber nome de versão.
3. No GLPI, entre em **Configurar → Plugins**, instale/atualize se solicitado e ative **GW Self-Service — POC TESTE**.
4. O pacote não sobrescreve nem contém `.env`, `.venv`, dados de outras extensões ou variáveis de ambiente.
5. Caso a versão anterior já estivesse instalada, **não desinstale** antes: o hook de desinstalação da v1.0.0 apaga as tabelas do plugin. Apenas substitua os arquivos com backup e use a rotina de atualização da interface.
6. Confira os roteiros abaixo. Se o GLPI mantiver um cache de classes/rotas, solicite à Infra a limpeza do cache e reinício do serviço PHP conforme o procedimento do ambiente.

> A instalação de arquivos em `plugins/` não é feita pela interface web do GLPI; depende de acesso de administração do servidor, painel de arquivos ou pipeline de implantação.

## Teste HTTP sem Active Directory

Abra a URL do seu novo GLPI, por exemplo:

`http://SERVIDOR-DE-TESTE/plugins/gwselfservice/Recovery`

Dados disponíveis exclusivamente para demonstração:

| Campo | Valor |
|---|---|
| Login fictício | `usuario.poc` |
| Código fictício público | `123456` |
| Ações | `Esqueci minha senha` e `Desbloquear minha conta` |
| Resposta esperada | Demonstração concluída, nenhuma modificação no AD |

A tela mostra uma faixa **AMBIENTE DE TESTE**. Os eventos HTTP são gravados na tabela de auditoria com resultados `simulated` e operações `demo_reset` / `demo_unlock` (e `demo_denied` para erros). O valor `123456` **não é um OTP real** e não é prova de identidade.

**Não utilize login, CPF, senha nem TOTP de nenhuma pessoa real no teste HTTP.** O controle de tentativas é compartilhado no banco e pode limitar repetições excessivas.

## Teste HTTPS com AD local (sem alteração)

As telas existentes na versão anterior foram preservadas:

| Rota | Função sob HTTPS |
|---|---|
| `/plugins/gwselfservice/Settings` | Configuração do controlador, conta de serviço, base DN, OU e teste LDAPS |
| `/plugins/gwselfservice/Enrollment` | Cadastro de fator TOTP com senha atual do AD em canal TLS |
| `/plugins/gwselfservice/Recovery` | Validação de usuário/TOTP em LDAP e **simulação** de reset/desbloqueio |
| `/plugins/gwselfservice/Audits` | Auditoria e revogação de autenticadores |

Configuração inicial **de demonstração** (ajustável no formulário, não é segredo):

- Domínio: `poc.local`.
- Controlador: `172.19.35.22` (preferir FQDN correspondente ao certificado LDAPS).
- Porta: `636` LDAPS, com CA confiável.
- DN: `DC=poc,DC=local`.
- A **OU de testes** e a **conta de serviço de leitura** devem ser fornecidas pela equipe do ambiente; senhas não vêm no pacote.

O admin só poderá selecionar **Simulação**. Campos antigos com `mode=live` na base não desativam a trava da edição.

### HTTPS atrás de proxy reverso

Se a URL no navegador começa com `https://`, mas o plugin ainda informa HTTP, o problema é **detecção de esquema pelo GLPI/Symfony**, não falta de um bypass. A infraestrutura deve configurar lista explícita de proxies confiáveis e os cabeçalhos permitidos (ou HTTPS no backend). **Não** aceitar `X-Forwarded-Proto` de qualquer cliente indiscriminadamente.

## Limitações da edição

- HTTP não testa integração com AD, não testa comprovação de identidade e não redefine senha.
- A validação de identidade por TOTP só ocorre **após cadastro prévio e por HTTPS**.
- HTTPS pode consultar AD/testar a senha atual do usuário e TOTP; não altera `unicodePwd`, `pwdLastSet` ou `lockoutTime`.
- Não cria chamado ITIL automaticamente para POP 086/categoria 954; a auditoria é própria do plugin.
- Nenhum e-mail real é enviado nessa edição.
- Não foi realizado teste integrado em GLPI 11/AD do usuário durante a montagem do pacote. É necessária homologação após instalar.
- O plugin **não altera** o sistema de autenticação LDAP geral do GLPI; a configuração AD é exclusiva do módulo de recuperação.

## Testes locais executados

- `php -l` em todos os arquivos PHP.
- `php tests/test_totp.php` — vetores e validação do algoritmo TOTP.
- `php tests/test_sandbox.php` — trava AD e dados demonstrativos.
- `php tests/test_http_ui.php` — renderização das telas HTTP e ausência de formulários de senha AD no modo demonstrativo.

Veja `SECURITY.md` e `CHANGELOG.md`.
