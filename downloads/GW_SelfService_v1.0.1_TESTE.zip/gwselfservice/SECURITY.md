# Segurança — GW Self-Service v1.0.1 (edição teste)

- **TRAVA PERMANENTE:** `TestPolicy::mayWriteToAd()` retorna `false`. Mesmo com configuração antiga `mode=live`, esta edição impede a execução de `Directory::resetPassword` e `Directory::unlock` pelo controlador.
- **HTTP permitido só para simulação fictícia:** login `usuario.poc`, código de exemplo `123456`, sem LDAP, sem novo segredo TOTP, sem senha real e sem envio de e-mail.
- O código demonstrativo público **não comprova identidade**; não utilizar como autenticação real.
- Cadastro do autenticador TOTP com senha AD, configuração da conta de serviço, teste LDAPS e auditoria sensível exigem HTTPS corretamente detectado.
- Não usar conta privilegiada ou dados reais no sandbox HTTP.
- Não desativar a checagem de certificado do LDAPS.
- Se o browser usa HTTPS mas o servidor detecta HTTP, configurar lista de proxies confiáveis no servidor. Não confiar automaticamente em `X-Forwarded-Proto` vindo de qualquer origem.
- O sandbox HTTP registra apenas eventos de demonstração. Restringir acesso do ambiente de teste à rede isolada ou VPN.
- Para qualquer uso operacional, criar uma release separada, revisar e homologar controles de identidade, credenciais, HTTPS, autorização AD e auditoria.
