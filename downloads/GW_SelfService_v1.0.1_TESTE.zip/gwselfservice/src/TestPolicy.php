<?php
namespace GlpiPlugin\Gwselfservice;

/**
 * Edição dedicada de homologação. Desabilita permanentemente alterações no AD.
 * Não depende da configuração no banco; mesmo valores antigos mode=live
 * não concedem privilégios para escrita no diretório.
 */
final class TestPolicy
{
    public const EDITION = 'POC_TEST_ONLY';
    public const ALLOW_AD_WRITES = false;

    public static function mayWriteToAd(): bool
    {
        return false;
    }
}
