<?php
namespace GlpiPlugin\Gwselfservice;

use Symfony\Component\HttpFoundation\Response;

final class Ui
{
    public static function url(string $page): string
    {
        global $CFG_GLPI;
        return rtrim((string)($CFG_GLPI['root_doc'] ?? ''), '/') . '/plugins/gwselfservice/' . $page;
    }

    public static function h(?string $s): string
    {
        return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function csrf(): string
    {
        if (empty($_SESSION['gwss_csrf']) || !is_string($_SESSION['gwss_csrf'])) {
            $_SESSION['gwss_csrf'] = bin2hex(random_bytes(24));
        }
        return $_SESSION['gwss_csrf'];
    }

    public static function checkCsrf(string $given): bool
    {
        return hash_equals(self::csrf(), $given);
    }

    public static function formToken(): string
    {
        // GLPI 11 checks its own CSRF token before a plugin controller runs.
        // Keep our separate token for anonymous recovery form binding as well.
        return '<input type="hidden" name="_glpi_csrf_token" value="' . self::h(\Session::getNewCSRFToken()) . '">'
            . '<input type="hidden" name="gwss_csrf" value="' . self::h(self::csrf()) . '">';
    }

    public static function page(string $title, string $content, bool $public = false, int $status = 200): Response
    {
        $css = self::url('css/main.css');
        $links = $public
            ? '<a href="' . self::h(self::url('Recovery')) . '">Recuperação</a><a href="' . self::h(self::url('Enrollment')) . '">Cadastrar autenticador</a>'
            : '<a href="' . self::h(self::url('Settings')) . '">Configuração</a><a href="' . self::h(self::url('Audits')) . '">Auditoria</a><a href="' . self::h(self::url('Enrollment')) . '">Cadastro TOTP</a><a href="' . self::h(self::url('Recovery')) . '">Portal público</a>';
        $html = '<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer"><title>' . self::h($title) . ' · GW Self-Service</title><link rel="stylesheet" href="' . self::h($css) . '"></head><body><header class="mast"><div class="brand"><span class="brandmark">GW</span><div><strong>GW Self-Service <span class="environment-tag">TESTE</span></strong><small>POC TJ-GO · Credenciais Active Directory · Homologação</small></div></div><nav>' . $links . '</nav></header><main class="wrap"><div class="heading"><div class="eyebrow">GLOBALWEB · AUTOSSERVIÇO</div><h1>' . self::h($title) . '</h1></div>' . $content . '</main><footer>POC TJ-GO · Não informe sua senha nem códigos a terceiros.</footer></body></html>';
        return new Response($html, $status, [
            'Content-Type' => 'text/html; charset=UTF-8',
            'Cache-Control' => 'no-store, no-cache, must-revalidate, private',
            'Pragma' => 'no-cache',
            'X-Content-Type-Options' => 'nosniff',
            'X-Frame-Options' => 'DENY',
            'Referrer-Policy' => 'no-referrer',
            'Content-Security-Policy' => "default-src 'none'; style-src 'self'; img-src 'self' data:; form-action 'self'; base-uri 'none'; frame-ancestors 'none'",
        ]);
    }

    public static function alert(string $message, bool $success = false): string
    {
        return '<div role="status" class="alert ' . ($success ? 'ok' : 'warn') . '">' . self::h($message) . '</div>';
    }

    public static function input(string $id, string $label, string $value = '', string $type = 'text', string $help = '', bool $required = false): string
    {
        return '<label class="field"><span>' . self::h($label) . '</span><input id="' . self::h($id) . '" name="' . self::h($id) . '" type="' . self::h($type) . '" value="' . self::h($value) . '" ' . ($required ? 'required ' : '') . 'autocomplete="off"><small>' . self::h($help) . '</small></label>';
    }
}
