# GW Self-Service — Registro de versões

## 1.1.0-TESTE — 17/11/2026

- Integração ao POP 086 / categoria ITIL 954 e fila N1 (ID configurável; padrão 12).
- Identificação obrigatória do usuário LDAP importado, vínculo DN e MFA nativo ativo, com verificação de código.
- Registro completo no GLPI: chamado, requerente, grupo N1, link de artigo KB, acompanhamento, tarefa, solução e encerramento.
- Novo campo de configuração ID do artigo KB: categoria KB não é um artigo KB.
- Senha temporária exibida apenas uma vez na resposta HTTPS; não armazenada nos registros.
- Modo padrão de simulação com trilha ITSM no HTTPS; novo modo `test_ad` com escrita real limitada a OU de laboratório e LDAPS, habilitado explicitamente.
- Troca obrigatória no próximo login (`pwdLastSet=0`) após reset real.
- Registro de ID de ticket em auditorias e controle antirrepetição por passo MFA nativo.
- Cadastro usa MFA nativo GLPI 11; cadastro TOTP próprio das versões anteriores torna-se legado, sem apagá-lo na atualização.
- Proteção HTTP mantida: apenas telas demonstrativas e auditoria fictícia, sem conta real, ticket real ou escrita no AD.

## 1.0.1-TESTE — 17/11/2026

- Modo HTTP demonstrativo sem tráfego de credenciais.
- Bloqueio de escrita real em AD em qualquer modo.

## 1.0.0 — 16/11/2026

- Estrutura inicial de configuração AD/LDAPS, cadastro independente de TOTP, recuperação e auditoria.
