# GW Self-Service v1.1.0 TESTE — TJ-GO / GLPI 11

## O que mudou

Esta atualização mantém o plugin `gwselfservice` e as configurações LDAP já armazenadas. Integra o autosserviço ao fluxo completo do **POP 086 / Categoria ITIL 954** no GLPI 11, sem exigir instalação de novos plugins ou Microsoft Entra ID:

1. Página pública de recuperação (`/plugins/gwselfservice/Recovery`), sem autenticação GLPI prévia, mas **somente para dados reais em HTTPS**.
2. Pesquisa do login pelo AD via **LDAPS com verificação de certificado** e restrição à OU de teste.
3. Encontra um único usuário **LDAP previamente importado no GLPI**, ativo e com `user_dn` idêntico ao DN retornado pelo AD; usuários locais ou não associados ao AD são rejeitados.
4. Verifica `Glpi\Security\TOTPManager::is2FAEnabled(users_id)` e o código de MFA via `verifyCodeForUser()`, aproveitando o **MFA NATIVO DO GLPI 11**. Não reutiliza segredos TOTP dos cadastros legados do GWSS.
5. Limite por IP/login e antirrepetição de passo TOTP no banco do plugin.
6. Antes de qualquer escrita no AD: cria chamado requisição no GLPI (`ITILCategory=954`, POP 086, solicitante = próprio usuário LDAP, grupo técnico N1), vincula artigo da KB, acompanhamento inicial e tarefa.
7. Em `simulation`, finaliza a trilha ITSM sem alterar o AD. Em `test_ad`, redefinição real de senha ou desbloqueio **apenas da OU de laboratório**.
8. Na redefinição real, altera `unicodePwd` com LDAPS e configura `pwdLastSet=0` para **obrigar troca no próximo logon**.
9. Finaliza tarefa, insere acompanhamento, registra `ITILSolution` e encerra o chamado GLPI. Se houver falha, **não fecha** e mantém a demanda com N1.
10. Mostra a nova senha apenas na resposta HTTPS ao solicitante que comprovou o MFA. **NUNCA salva senha/código em ticket, acompanhamento, tarefa, solução, log, banco ou e-mail**.
11. Na auditoria do plugin, registra o ID do chamado GLPI vinculado.

### Política para execução real no laboratório

- **Simulação é o padrão**. Para modificar o AD, administrador deve selecionar **AD TESTE REAL** e marcar a autorização explícita na tela de configuração HTTPS.
- O ambiente precisa permitir HTTPS real reconhecido pelo GLPI/Symfony, e `ldaps://HOST:636` com certificado validado.
- A **OU deve ser específica** dentro do `base_dn` (jamais a raiz do domínio); o plugin bloqueia DNs fora dela.
- Utilizar **conta de serviço com permissões delegadas somente na OU de testes**, capaz de resetar senha, definir `pwdLastSet=0` e desbloquear contas. Não utilizar Domain Admin.
- O plugin não realiza alteração de contas desabilitadas (`userAccountControl` desabilitado).
- A troca no próximo logon (`pwdLastSet=0`) é obrigatória e não pode ser desativada.
- Se a senha mudar, mas `pwdLastSet=0` falhar, o chamado permanece aberto para correção pelo N1 e a senha ainda é apresentada **uma vez** à pessoa que passou pelo MFA.
- Se a atualização no AD ocorrer e a etapa de encerramento falhar, o chamado permanece em atendimento e o usuário vê um aviso. Reconciliar na auditoria.

### IMPORTANTE: modo HTTP

A página HTTP com `usuario.poc` e `123456` é **DEMONSTRAÇÃO DE INTERFACE**, NÃO valida identidade real, NÃO cria chamado e NÃO modifica o AD. Esses dados são públicos. Todo o fluxo completo de MFA nativo e os registros GLPI depende de HTTPS.

## Configuração via navegador

1. Faça backup de `plugins/gwselfservice/` e do banco GLPI. **Não desinstale** a versão 1.0.x.
2. Substitua a pasta do plugin pelos arquivos do ZIP. Mantenha o nome `gwselfservice` sem subpasta duplicada; ative **Atualizar** no GLPI em **Configurar > Plugins**, para criar colunas novas e tabela de antirrepetição do MFA.
3. Acesse `/plugins/gwselfservice/Settings` por HTTPS e confira configuração do AD já existente: host, porta, domínio `poc.local`, base DN, **OU exclusiva**, bind e certificado.
4. Em **Integração GLPI**, confirme: entidade TJ-GO ID **0**, grupo N1 ID **12** (verifique no seu servidor), categoria ITIL fixa ID **954**.
5. Preencha **ID de artigo da base de conhecimento** (`kb_article_id`). **A captura mostra apenas a categoria da base de conhecimento vinculada à categoria ITIL**, e NÃO informa o ID de um artigo. Se não existir, crie um artigo com o procedimento do POP 086 e insira seu ID. O plugin **recusa a execução** se esse vínculo não puder ser feito.
6. A conta do usuário já precisa existir no GLPI, **importada do LDAP**, com DN correto e **2FA nativo ativo** em Minhas configurações > 2FA. Não é necessário cadastrar outro autenticador no plugin. A página `/Enrollment` apenas exibe a condição do MFA nativo.
7. Selecione **Simulação** para primeiro validar criação e fechamento do chamado; depois, e só depois, selecione **AD TESTE REAL** na OU controlada.
8. O usuário abre `/plugins/gwselfservice/Recovery` por HTTPS, informa `login` sem domínio, escolhe operação e informa seu código do **MFA nativo do GLPI**. Não é preciso autenticar com a senha esquecida.
9. Confirme o ID retornado e abra o ticket no GLPI para inspecionar Requerente, Categoria, Grupo N1, artigo KB, acompanhamentos, tarefa concluída, solução e status fechado.

### Configuração inicial da POC

| Configuração | Padrão |
|---|---|
| AD | `poc.local` (host `172.19.35.22`, substituir por FQDN do certificado se necessário) |
| Porta | 636 / LDAPS |
| Base DN | `DC=poc,DC=local` |
| OU autorizada | **obrigatória — definir para laboratório** |
| Categoria ITIL | **954 / Reset de senha de acesso** |
| POP | **086** |
| Grupo encarregado N1 | **12** (confirmar no GLPI) |
| Entidade GLPI | **0 / TJ-GO** |
| Artigo KB | **informar ID do artigo, não da categoria** |
| MFA | **nativo GLPI 11** |
| Execução | `simulation` por padrão |
| UST | **1** (campo da própria categoria 954, não alterado pelo plugin) |

## Instalação e limitações

O upload de plugin ZIP não é uma função genérica do GLPI: o administrador do servidor deverá colocar a pasta `gwselfservice` em `plugins/`. O restante da configuração será pelo navegador. Os arquivos `.env` e `.venv` existentes não são tocados.

**Não foi possível executar testes integrados em um GLPI 11 e controlador de domínio AD reais** neste ambiente de geração. Foram realizados testes de sintaxe PHP, fluxo ITSM em classes simuladas, política de OU/HTTPS, gerador de senhas, fluxo HTTP e integridade do ZIP. A instalação é **candidata à homologação**, não substitui teste funcional do ticket completo e do LDAPS no laboratório.

Caso o GLPI recuse escrita de objetos ITSM em requisições anônimas por permissões de sessão, o plugin interromperá o fluxo **antes** de redefinir a senha, mantendo segurança. Essa particularidade precisa ser validada no GLPI 11 exato da POC; em produção deve-se usar uma execução autorizada de serviço (ação automática ou conta técnica com escopo).

## Segurança, auditoria e privacidade

- O método nativo `verifyCodeForUser` valida o código; não existe senha AD persistida no portal.
- MFA nativo ativo **não** basta isoladamente: o código atual deve ser validado a cada operação.
- A prova fornecida é controle de um autenticador previamente cadastrado, sem fator de conhecimento adicional. Para produção considerar recuperação de contas com política de dois métodos independentes, antifraude e aprovação em casos sensíveis.
- O código pode aparecer em logs de proxy ou aplicativos se implementados de modo inadequado: manter TLS, `no-store`, higiene dos logs, sessões curtas e rate limiting.
- Contas sem MFA nativo cadastrado, contas desabilitadas, contas fora da OU ou não importadas do LDAP recebem erro genérico e devem procurar o Service Desk.
- **Não inserir senha temporária em e-mail, acompanhamento, tarefas, solução ou log.**

## Testes locais incluídos

```sh
find gwselfservice -name '*.php' -print0 | xargs -0 -n1 php -l
php -d zend.assertions=1 -d assert.exception=1 gwselfservice/tests/test_policy_password.php
php -d zend.assertions=1 -d assert.exception=1 gwselfservice/tests/test_workflow_stubs.php
```

Consulte também `SECURITY.md` e `CHANGELOG.md`.
