# Segurança — GW Self-Service POC TJ-GO

**Ambiente de laboratório somente.** O plugin realiza operação sensível de redefinição de senha no AD. Teste todos os controles no ambiente isolado antes de habilitar `test_ad`.

- **HTTP**: demonstração sem identidade real, chamados reais ou ações AD. **HTTPS**: requerido para o MFA nativo e toda operação ITSM.
- **Certificado LDAPS**: validação obrigatória, não desativada. Usar FQDN do certificado CA confiável.
- **Conta serviço AD**: somente permissão delegada de reset, desbloqueio e `pwdLastSet` na **OU exclusiva de testes**. Proibir Domain Admin.
- **Identidade**: conta do AD deve corresponder a UM usuário ativo e importado do LDAP no GLPI, com mesmo DN, MFA nativo GLPI ativo e código TOTP atual válido; não aceitar usuário local homônimo.
- **TOTP**: o plugin não tem acesso ao segredo do 2FA; utiliza validação do GLPI. Antirrepetição por período é gravada no banco e rate limiting por IP/login.
- **Segredos**: nova senha exibida somente uma vez na página HTTPS. Nunca inserir em chamado, KB, tarefa, solução, auditoria ou e-mail. Senha de bind existente cifrada por GLPIKey.
- **Fluxo**: primeiro abrir ticket, requerente, grupo, artigo KB, acompanhamento e tarefa. Em falha de qualquer passo inicial, o plugin não realiza escrita no AD. Em falha posterior, o ticket é mantido aberto e auditado.
- **Passwords**: geração CSPRNG `random_int`, 18 caracteres, pelo menos uma letra maiúscula, uma minúscula, um dígito e um símbolo; respeitar políticas específicas do AD.
- **Falhas parciais**: se `unicodePwd` funcionar e `pwdLastSet` falhar, solicitar intervenção N1 e não fechar chamado. O usuário deve receber uma única vez a senha já alterada.
- **Aprovação**: limitar a conta de serviço a OU de teste, jamais permitir contas de domínio administrativas.
- **Testes pendentes**: GLPI 11 real, dependências, permissões da sessão anônima para criação nativa de ticket, categorias e regras de SLA, LDAPS e escopo de OU. Sem testes reais, não considerar homologado.
- **MFA**: um código TOTP é um fator de posse, não substitui um processo de recuperação multifatorial robusto em produção.
