<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\TestSandbox;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class EnrollmentController extends AbstractController
{
    #[Route('/Enrollment', name: 'gwselfservice_enrollment', methods: ['GET'])]
    public function __invoke(Request $request): Response
    {
        if (!$request->isSecure()) {
            return TestSandbox::enrollment();
        }
        $uid = (int)\Session::getLoginUserID();
        if ($uid < 1) {
            return Ui::page('MFA nativo do GLPI', Ui::alert('Autentique-se no GLPI para configurar seu MFA.'), false, 403);
        }
        $mfa = new \Glpi\Security\TOTPManager();
        $enabled = $mfa->is2FAEnabled($uid);
        $root = rtrim((string)($GLOBALS['CFG_GLPI']['root_doc'] ?? ''), '/');
        $url = $root . '/front/preference.php';
        $html = '<div class="test-banner"><strong>POC TJ-GO — MFA NATIVO</strong><p>GW Self-Service reutiliza o autenticador do próprio GLPI 11. Não é necessário cadastrar um TOTP separado neste plugin.</p></div>'
            . '<section class="panel"><h2>Cadastro de MFA do GLPI 11</h2><p>Status: <strong>' . ($enabled ? 'MFA nativo habilitado' : 'MFA nativo não habilitado') . '</strong></p>'
            . '<p>Entre em Minhas configurações / Preferências &gt; Autenticação de dois fatores (2FA), registre o aplicativo e confirme o código.</p>'
            . '<p><a href="' . Ui::h($url) . '">Abrir minhas preferências no GLPI</a></p>'
            . '<p>Antes do reset, a conta precisa ter sido importada via LDAP com DN coincidente com o AD. MFA será verificado na tela de recuperação, mesmo sem uma sessão GLPI.</p></section>';
        return Ui::page('MFA nativo do GLPI 11', $html);
    }
}
