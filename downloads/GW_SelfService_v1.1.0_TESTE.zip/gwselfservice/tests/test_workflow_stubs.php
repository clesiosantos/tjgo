<?php
/** Unit test with tiny GLPI stubs. Does not replace actual GLPI integration tests. */
if (!function_exists('mb_substr')) { function mb_substr(string $s, int $start, ?int $len = null): string { return substr($s, $start, $len); } }
$GLOBALS['written'] = [];
$GLOBALS['ticket_state'] = 1;
class BaseThing {
    public array $fields = [];
    public function getFromDB($id) { $this->fields = ['id'=>$id, 'is_request'=>1]; return $id > 0; }
    public function add($data) { $id = count($GLOBALS['written']) + 100; $GLOBALS['written'][] = ['class'=>static::class, 'id'=>$id, 'input'=>$data]; return $id; }
    public function update($data) { $GLOBALS['written'][] = ['class'=>static::class, 'update'=>$data]; return true; }
}
class ITILCategory extends BaseThing {} class Group extends BaseThing {} class KnowbaseItem extends BaseThing {}
class Ticket extends BaseThing {} class Ticket_User extends BaseThing {} class Group_Ticket extends BaseThing {}
class KnowbaseItem_Item extends BaseThing {} class ITILFollowup extends BaseThing {} class TicketTask extends BaseThing {}
class ITILSolution extends BaseThing {} class Planning { const DONE = 2; }
class FakeRequest {
    public function __construct(private array $rows) {}
    public function getIterator() { return new ArrayIterator($this->rows); }
}
class FakeDB {
    public function request($data) {return [];}
    public function insert($table,$values) { $GLOBALS['written'][] = ['class'=>'DBaudit', 'table'=>$table, 'input'=>$values]; return true; }
}
$DB = new FakeDB();
require_once __DIR__ . '/../src/Store.php';
require_once __DIR__ . '/../src/TicketWorkflow.php';
$conf = ['group_id' => 12, 'kb_article_id' => 42, 'entity_id' => 0];
$ids = GlpiPlugin\Gwselfservice\TicketWorkflow::open($conf, 91, 'pessoa.poc', 'reset');
assert(($ids['ticket_id'] ?? 0) > 0 && ($ids['task_id'] ?? 0) > 0);
GlpiPlugin\Gwselfservice\TicketWorkflow::finish($ids, 91, 'reset', true);
$names = array_column($GLOBALS['written'],'class');
foreach (['Ticket','Ticket_User','Group_Ticket','KnowbaseItem_Item','ITILFollowup','TicketTask','ITILSolution'] as $class) {
    assert(in_array($class, $names, true));
}
$ticket = array_values(array_filter($GLOBALS['written'],fn($w)=>$w['class']==='Ticket' && isset($w['input'])))[0]['input'];
assert($ticket['itilcategories_id'] === 954 && $ticket['_users_id_requester'] === 91 && $ticket['_groups_id_assign'] === 12);
assert(in_array(['id'=>$ids['ticket_id'],'status'=>6], array_column(array_values(array_filter($GLOBALS['written'], fn($w)=>$w['class']==='Ticket' && isset($w['update']))),'update'),true));
foreach ($GLOBALS['written'] as $entry) {
    $blob = json_encode($entry);
    assert(!str_contains($blob, 'TestSecret@123'));
}
echo "OK: ticket/requester/group/KB/followup/task/solution/close (mock)\n";
