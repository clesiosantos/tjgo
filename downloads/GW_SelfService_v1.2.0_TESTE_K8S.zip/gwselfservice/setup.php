<?php
/** GW Self-Service, GLPI 11 / POC TJ-GO. */

define('PLUGIN_GWSELFSERVICE_VERSION', '1.2.0');

function plugin_init_gwselfservice(): void
{
    global $PLUGIN_HOOKS;
    $PLUGIN_HOOKS['csrf_compliant']['gwselfservice'] = true;
    $PLUGIN_HOOKS['config_page']['gwselfservice'] = 'front/config.php';
    $PLUGIN_HOOKS['secured_fields']['gwselfservice'] = [
        'glpi_plugin_gwselfservice_configs.bind_secret',
        'glpi_plugin_gwselfservice_factors.secret_cipher',
    ];
    if (\Plugin::isPluginActive('gwselfservice')) {
        $PLUGIN_HOOKS['add_javascript']['gwselfservice'][] = 'js/login-link.js';
    }
}

function plugin_version_gwselfservice(): array
{
    return [
        'name' => 'GW Self-Service — POC TESTE (Kubernetes/Proxy + MFA + ITSM)',
        'version' => PLUGIN_GWSELFSERVICE_VERSION,
        'author' => 'GlobalWEB · POC TJ-GO',
        'license' => 'GPLv3+',
        'requirements' => [
            'glpi' => ['min' => '11.0.0', 'max' => '12.0.0'],
            'php' => ['min' => '8.2.0'],
        ],
    ];
}

function plugin_gwselfservice_check_prerequisites(): bool
{
    if (!extension_loaded('ldap') || !extension_loaded('openssl')) {
        echo 'GW Self-Service requer as extensões PHP ldap e openssl.';
        return false;
    }
    return true;
}

function plugin_gwselfservice_check_config($verbose = false): bool
{
    return true; // Configuração AD é feita posteriormente pela interface.
}
