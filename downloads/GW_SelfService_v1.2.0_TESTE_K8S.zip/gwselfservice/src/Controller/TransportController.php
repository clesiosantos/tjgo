<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\Transport;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/** Read-only diagnostics for administrators; no AD secrets or password operations. */
final class TransportController extends AbstractController
{
    #[Route('/Transport', name: 'gwselfservice_transport', methods: ['GET'])]
    public function __invoke(Request $request): Response
    {
        if (!\Session::haveRight('config', UPDATE)) {
            return Ui::page('Acesso restrito', Ui::alert('Apenas administradores podem consultar o diagnóstico.'), false, 403);
        }
        $info = Transport::diagnostic($request);
        $status = (bool)$info['effective_https'];
        $rows = [
            'GLPI / Symfony reconhece HTTPS' => $info['symfony_https'] ? 'Sim' : 'Não',
            'Lista de proxies de confiança definida' => $info['proxy_configured'] ? 'Sim' : 'Não',
            'Peer imediato autorizado' => $info['proxy_authorized'] ? 'Sim' : 'Não',
            'Protocolo externo informado' => (string)$info['forwarded_scheme'],
            'HTTPS efetivo para o plugin' => $status ? 'SIM — TLS externo validado' : 'NÃO — fluxo real bloqueado',
            'IP de conexão ao pod' => (string)$info['direct_peer'],
            'IP do solicitante para auditoria' => (string)$info['client_ip'],
        ];
        $table = '';
        foreach ($rows as $key => $value) {
            $table .= '<tr><th>' . Ui::h($key) . '</th><td>' . Ui::h($value) . '</td></tr>';
        }
        $body = '<div class="test-banner"><strong>POC TJ-GO · Diagnóstico de Kubernetes / proxy reverso</strong><p>Somente leitura. Não expõe credenciais do AD, TOTP ou certificados.</p></div>'
            . Ui::alert($status ? 'Transporte HTTPS reconhecido. O fluxo nativo de MFA poderá ser homologado.' : 'Transporte HTTPS não reconhecido. Corrija o Ingress ou a lista de proxies antes de permitir operações reais.', $status)
            . '<section class="panel"><h2>Conexão atual</h2><div class="table"><table><tbody>' . $table . '</tbody></table></div></section>'
            . '<section class="note"><h3>Como corrigir no Kubernetes</h3>'
            . '<p>Prefira configurar o GLPI/Symfony para confiar no Ingress. Se ele continuar vendo HTTP no pod, defina no Deployment a variável <code>GWSS_TRUSTED_PROXY_CIDRS</code> com APENAS IPs/CIDRs dos proxies que alcançam o GLPI. O plugin então reconhece <code>X-Forwarded-Proto: https</code> ou <code>Forwarded: proto=https</code> enviado exclusivamente por esses proxies.</p>'
            . '<p>Não adicione <code>0.0.0.0/0</code>, não confie em cabeçalhos enviados diretamente pelo navegador e restrinja o acesso aos pods por NetworkPolicy/Service ClusterIP. Replique a configuração em todos os pods.</p>'
            . '<p>Se esta página foi aberta via HTTP direto, o diagnóstico não habilita nenhum recurso sensível.</p></section>';
        return Ui::page('Diagnóstico HTTPS / Proxy', $body);
    }
}
