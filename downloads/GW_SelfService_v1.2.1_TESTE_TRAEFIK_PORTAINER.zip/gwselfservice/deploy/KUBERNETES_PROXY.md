# GW Self-Service 1.2.0 TESTE — GLPI 11 atrás de Kubernetes / Ingress / proxy reverso

## Objetivo e limite de segurança

O plugin segue a segurança percebida pelo GLPI/Symfony e suporta TLS terminado fora do pod:

```
Navegador HTTPS:443
        -> Proxy externo (opcional) -> Ingress (NGINX/Traefik/HAProxy)
        -> Service ClusterIP (HTTP interno) -> Pod GLPI 11 + GW Self-Service
                                         -> Banco GLPI (compartilhado)
                                         -> Active Directory LDAPS:636
```

- HTTPS direto reconhecido por `Request::isSecure()` funciona sem configuração adicional no plugin.
- Quando o GLPI/Symfony vê HTTP porque o TLS foi encerrado no Ingress, o plugin **SÓ** reconhece HTTPS externo se o IP **do peer imediato** (`REMOTE_ADDR`) estiver na variável **`GWSS_TRUSTED_PROXY_CIDRS`** e o cabeçalho `X-Forwarded-Proto: https` ou `Forwarded: proto=https` for consistente.
- Não usar `0.0.0.0/0`, `::/0`, `*`, ou simplesmente confiar em todos os IPs privados. Identifique IP/CIDR do ingresso autorizado e restrinja tráfego com NetworkPolicy/Firewall. A lista é deliberadamente vazia por padrão.
- Um acesso HTTP real continua sendo somente demonstração fictícia. O código MFA, conta AD, dados de configuração e qualquer mutação AD são negados nessa situação.
- O recurso de **AD TESTE REAL** continua exigindo habilitação explícita, conta de serviço delegada, conexão LDAPS validada e OU exclusiva da POC. Configurar proxy **não ativa** alterações no AD.

## 1. Verificar a configuração atual (não exige SSH ao usuário GLPI)

Abra por **HTTPS externo**, logado como administrador GLPI:

`https://DOMINIO_PUBLICO/plugins/gwselfservice/Transport`

A tela identifica se o GLPI/Symfony já reconhece TLS, se o peer imediato é confiável, o protocolo informado e o estado final. Também está no menu **HTTPS / Proxy** do próprio plugin.

Se aparecer **HTTPS efetivo: SIM**, nenhuma configuração adicional é necessária para essa etapa.

Se aparecer **NÃO** mesmo com cadeado HTTPS no navegador, ajuste o Ingress ou aplique a variável de ambiente abaixo nos pods. Não faça bypass desativando a verificação.

## 2. Configurar o Kubernetes (time de infraestrutura)

Na configuração de `env:` do container GLPI (exemplo **ilustrativo**):

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: glpi
spec:
  template:
    spec:
      containers:
        - name: glpi
          env:
            - name: GWSS_TRUSTED_PROXY_CIDRS
              value: "10.42.12.0/24" # EXEMPLO: substituir pelo CIDR/IP real do proxy visto pelo pod
```

**Atenção:** o trecho não é um manifesto completo para aplicar com `kubectl apply`. Insira somente `env` no Deployment existente, sem remover os demais contêineres, volumes ou segredos. Se o container usar PHP-FPM com `clear_env=yes`, encaminhe a variável ao processo PHP-FPM (`env[GWSS_TRUSTED_PROXY_CIDRS] = $GWSS_TRUSTED_PROXY_CIDRS`), conforme a imagem adotada.

Use a rede exata do componente que conecta ao pod, observando NAT de Service/Ingress. Nem todo pod CIDR é um escopo de confiança aceitável: se a rede incluir outros serviços não confiáveis, configure NetworkPolicy impedindo que alcancem o GLPI e, preferencialmente, use os IPs do gateway apropriado.

## 3. Encaminhar o protocolo original

O proxy que entrega a requisição ao GLPI deve enviar o **protocolo do navegador**, sobrescrevendo valores não confiáveis dos clientes. Para NGINX que recebe o TLS no próprio bloco `server`:

```nginx
proxy_set_header Host $host;
proxy_set_header X-Forwarded-Proto $scheme;
proxy_set_header X-Forwarded-Port $server_port;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
```

Se houver TLS terminado antes do Ingress, `$scheme` nesse hop pode ser `http`; ajuste a cadeia de confiança do Ingress para propagar com segurança o protocolo original. Nunca habilite `use-forwarded-headers` se qualquer cliente direto puder forjar os cabeçalhos. Não repasse `Forwarded: proto=http` junto de `X-Forwarded-Proto: https`: o plugin bloqueia cabeçalhos contraditórios.

Para Kubernetes Ingress Controller, confirme os parâmetros de `X-Forwarded-Proto`, trusted proxy e a política de sobrescrita de cabeçalhos conforme o controlador instalado. O YAML em `ingress-exemplo.yaml` é apenas um modelo, **não substitui** a configuração da controladora de ingresso.

## 4. Múltiplas réplicas — requisitos do GLPI

A configuração de proxy deve valer para **todos** os pods do Deployment. Não altere arquivos individuais em pods efêmeros. O código do plugin deverá ser incluído na imagem ou volume compartilhado (sem versionar ou sobrescrever `.env` / `.venv`).

- **Mesma instância de banco do GLPI**: as tabelas de auditoria, limites de tentativa e antirrepetição do MFA são compartilhadas pelo banco, portanto não usam cache local do pod.
- **Sessões PHP/GLPI**: configure mecanismo de sessão compartilhado entre pods ou afinidade de sessão no Ingress; sem isso, CSRF e autenticação podem falhar ao mudar de pod. Verifique os mecanismos oficialmente suportados pela sua imagem/GLPI.
- **Chave de criptografia GLPI**: todos os pods devem compartilhar a mesma chave do GLPI para descriptografar o segredo de bind já gravado; persistir também arquivos de configuração e dados necessários.
- **DNS / rede**: permitir dos pods para o DC `172.19.35.22` em **TCP 636** e DNS do FQDN do certificado (TCP/UDP 53, conforme arquitetura). NUNCA desabilitar verificação TLS do LDAPS.
- **Certificados**: montar CA do domínio como ConfigMap/Secret ou trust store da imagem, acessível para PHP; o nome LDAPS deve coincidir com o certificado.
- **Ingress/NetworkPolicy**: TLS público, redirects HTTP→HTTPS e negar acesso direto dos clientes ao pod/Service; nunca permitir cabeçalhos `X-Forwarded-*` arbitrários de fora da cadeia confiável.
- **Logs**: não registrar corpos POST, token MFA nem senha temporária; logs de auditoria guardam operação e chamado, não segredo.

## 5. Teste de aceite da infraestrutura (HTTPS externo)

1. Acessar GLPI pelo endereço oficial HTTPS do Ingress e comprovar login normal.
2. Em `/plugins/gwselfservice/Transport`, observar `HTTPS efetivo = SIM`. Se `Symfony HTTPS = NÃO`, deve indicar `Proxy configurado = SIM`, `Peer autorizado = SIM` e `Protocolo externo = https`.
3. Abrir `/plugins/gwselfservice/Recovery` sem sessão GLPI. A tela real (MFA nativo) deve aparecer **somente** via HTTPS confiável. Nenhuma senha ou código é exigido no HTTP direto.
4. Enviar `X-Forwarded-Proto: https` diretamente por HTTP a um endpoint fora do Ingress autorizado (ambiente de laboratório), e confirmar que continua em **simulação HTTP**. Essa verificação é importante contra spoofing.
5. Se há várias réplicas, repetir acessos alternando pods e confirmar que sessões e CSRF não se perdem e que rate limit e auditoria usam o mesmo banco.
6. Em `simulation`, com MFA nativo de um usuário AD previamente importado, conferir chamado categoria 954, grupo N1, requerente, artigo KB, acompanhamento, tarefa e solução. Nenhuma alteração deve ocorrer no AD.
7. Apenas após isso, testar o modo `test_ad` em OU de laboratório, com autorização e evidências de `pwdLastSet=0` e encerramento do chamado.

## Observações sobre proxies externos

Há duas configurações de proxy distintas:
- **Proxy reverso de entrada** (Ingress/LoadBalancer): é a situação resolvida pelo plugin neste pacote.
- **Proxy HTTP de saída** (para Internet): não é necessário para LDAPS. O reset de senha usa conexão TCP/TLS diretamente ao controlador AD; um proxy HTTP tradicional não encaminha LDAP automaticamente.

O plugin não modifica as configurações TLS, cookies, `trusted_proxies`, ingress ou roteamento do próprio GLPI. Ele avalia o contexto da requisição entregue pelo GLPI e, como alternativa explícita, valida o peer imediato contra a lista definida pelo operador.
