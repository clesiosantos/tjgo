# GW Self-Service 1.2.1 TESTE — Traefik, Portainer e Docker Compose

A configuração é **pela interface web**, sem editar YAML nem reiniciar contêineres:

1. Entre no GLPI via HTTPS externo e perfil com permissão de configuração.
2. Abra `/plugins/gwselfservice/Transport`.
3. Confira `Protocolo informado pelo Traefik = https` e o IP imediato.
4. Marque a confirmação e clique em **Confiar no Traefik [IP] agora**.
5. Atualize a página: **HTTPS reconhecido pelo plugin = SIM**.
6. Acesse `/plugins/gwselfservice/Settings` e `/plugins/gwselfservice/Recovery`.

A lista da interface é persistida na tabela `glpi_plugin_gwselfservice_configs`
(`trusted_proxy_cidrs`). O modo simulação é preservado; nunca ativa escrita AD
ou altera o certificado LDAPS.

Quando o IP do container Traefik muda, é possível confiar no CIDR da rede
interna DOCKER, mas somente se for uma rede privada exclusiva do proxy.
O formulário limita a IPv4 /24 ou mais restrito, IPv6 /64 ou mais restrito,
e o IP atual deve estar dentro da faixa.

## Alternativa sem atualização do plugin

Na Stack do Portainer, acrescentar ao serviço do GLPI:

```yaml
environment:
  GWSS_TRUSTED_PROXY_CIDRS: "10.0.2.147/32"
```

O IP acima é um exemplo observado no diagnóstico; pode variar depois de
reiniciar o Docker. Para descobrir a faixa real, consulte a rede no Portainer.

## Segurança

- Não confie em `0.0.0.0/0`.
- Não exponha diretamente a porta HTTP do contêiner GLPI aos usuários.
- Cabeçalhos X-Forwarded-Proto só são aceitos do peer confiável.
- A interface apenas habilita reconhecimento do HTTPS externo; não habilita
  ações reais no Active Directory. Isso continua exigindo modo AD de laboratório,
  OU específica, conta delegada, MFA e certificado LDAPS.
- Em HTTP direto, somente a demonstração fictícia fica disponível.
- A senha de serviço nunca é mostrada na tela de diagnóstico.

## Atualização

Substitua a pasta `plugins/gwselfservice` e utilize **Atualizar** no GLPI.
NÃO DESINSTALE: isso removeria as tabelas do plugin e suas configurações.
A atualização adiciona `trusted_proxy_cidrs` sem alterar segredos antigos.
