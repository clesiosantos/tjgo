<?php
/** Entry point for GLPI plugin configuration cog. */
use GlpiPlugin\Gwselfservice\Ui;

if (!\Session::haveRight('config', UPDATE)) {
    \Session::checkRight('config', UPDATE);
}
\Html::redirect(Ui::url('Settings'));
