<?php
function plugin_gwselfservice_install(): bool
{
    global $DB;
    $tables = [
        'glpi_plugin_gwselfservice_configs' => <<<'SQL'
CREATE TABLE `glpi_plugin_gwselfservice_configs` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `host` VARCHAR(255) NOT NULL DEFAULT '172.19.35.22',
  `port` INT UNSIGNED NOT NULL DEFAULT 636,
  `domain` VARCHAR(255) NOT NULL DEFAULT 'poc.local',
  `base_dn` VARCHAR(512) NOT NULL DEFAULT 'DC=poc,DC=local',
  `allowed_ou` VARCHAR(512) NOT NULL DEFAULT '',
  `bind_dn` VARCHAR(512) NOT NULL DEFAULT '',
  `bind_secret` TEXT NULL,
  `ca_file` VARCHAR(1024) NOT NULL DEFAULT '',
  `enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `mode` VARCHAR(16) NOT NULL DEFAULT 'simulation',
  `reset_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `unlock_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `pwd_change_next` TINYINT(1) NOT NULL DEFAULT 0,
  `notify_enabled` TINYINT(1) NOT NULL DEFAULT 0,
  `mail_from` VARCHAR(255) NOT NULL DEFAULT '',
  `entity_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `group_id` INT UNSIGNED NOT NULL DEFAULT 12,
  `kb_article_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `trusted_proxy_cidrs` VARCHAR(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
        'glpi_plugin_gwselfservice_factors' => <<<'SQL'
CREATE TABLE `glpi_plugin_gwselfservice_factors` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `users_id` INT UNSIGNED NOT NULL,
  `login` VARCHAR(255) NOT NULL,
  `ad_guid` CHAR(32) NOT NULL,
  `secret_cipher` TEXT NOT NULL,
  `last_counter` BIGINT NOT NULL DEFAULT -1,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_id` (`users_id`),
  UNIQUE KEY `ad_guid` (`ad_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
        'glpi_plugin_gwselfservice_attempts' => <<<'SQL'
CREATE TABLE `glpi_plugin_gwselfservice_attempts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `key_hash` CHAR(64) NOT NULL,
  `hits` INT UNSIGNED NOT NULL DEFAULT 0,
  `window_start` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_hash` (`key_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
        'glpi_plugin_gwselfservice_audits' => <<<'SQL'
CREATE TABLE `glpi_plugin_gwselfservice_audits` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `login` VARCHAR(255) NOT NULL DEFAULT '',
  `users_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `operation` VARCHAR(40) NOT NULL,
  `result` VARCHAR(40) NOT NULL,
  `ip` VARCHAR(45) NOT NULL DEFAULT '',
  `details` VARCHAR(255) NOT NULL DEFAULT '',
  `tickets_id` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `created_at` (`created_at`),
  KEY `login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
        'glpi_plugin_gwselfservice_mfa_steps' => <<<'SQL'
CREATE TABLE `glpi_plugin_gwselfservice_mfa_steps` (
  `users_id` INT UNSIGNED NOT NULL,
  `last_step` BIGINT NOT NULL DEFAULT -1,
  `updated_at` DATETIME NOT NULL,
  PRIMARY KEY (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
SQL,
    ];
    foreach ($tables as $name => $sql) {
        if (!$DB->tableExists($name) && !$DB->doQuery($sql)) {
            throw new \RuntimeException('Falha ao criar tabela do GW Self-Service: ' . $name);
        }
    }
    // Upgrade 1.0.x -> 1.2.1 without discarding LDAP configuration or TOTP entries.
    $columns = [
        'glpi_plugin_gwselfservice_configs' => [
            'entity_id' => 'INT UNSIGNED NOT NULL DEFAULT 0',
            'group_id' => 'INT UNSIGNED NOT NULL DEFAULT 12',
            'kb_article_id' => 'INT UNSIGNED NOT NULL DEFAULT 0',
            'trusted_proxy_cidrs' => "VARCHAR(1024) NOT NULL DEFAULT ''",
        ],
        'glpi_plugin_gwselfservice_audits' => [
            'tickets_id' => 'INT UNSIGNED NOT NULL DEFAULT 0',
        ],
    ];
    foreach ($columns as $table => $fields) {
        foreach ($fields as $field => $definition) {
            if (!$DB->fieldExists($table, $field)) {
                if (!$DB->doQuery("ALTER TABLE `{$table}` ADD COLUMN `{$field}` {$definition}")) {
                    throw new \RuntimeException('Falha na migração do campo: ' . $field);
                }
            }
        }
    }
    $config = $DB->request([
        'FROM' => 'glpi_plugin_gwselfservice_configs',
        'WHERE' => ['id' => 1],
    ])->current();
    if (!$config) {
        $DB->insert('glpi_plugin_gwselfservice_configs', ['id' => 1]);
    }
    (new \Migration(100))->executeMigration();
    return true;
}

function plugin_gwselfservice_uninstall(): bool
{
    global $DB;
    foreach (['mfa_steps', 'audits', 'attempts', 'factors', 'configs'] as $name) {
        $table = 'glpi_plugin_gwselfservice_' . $name;
        if ($DB->tableExists($table)) {
            $DB->doQuery('DROP TABLE `' . $table . '`');
        }
    }
    return true;
}
