/* GW Self-Service: add a non-intrusive link when GLPI loads plugin assets on its login page.
 * If the login template does not load plugin hooks, use the direct public URL.
 */
(function () {
  'use strict';
  const src = document.currentScript && document.currentScript.src;
  if (!src) return;
  const marker = '/plugins/gwselfservice/';
  const pos = new URL(src).pathname.indexOf(marker);
  if (pos < 0) return;
  const base = new URL(src).pathname.slice(0, pos);
  function addLink() {
    if (!/\/front\/login\.php|\/login|\/index\.php|\/$/.test(location.pathname)) return;
    if (document.getElementById('gwss-recovery-link')) return;
    const panel = document.querySelector('form[action*="login"], form[name="login"], .login-box form, form');
    if (!panel) return;
    const link = document.createElement('a');
    link.id = 'gwss-recovery-link';
    link.href = base + marker + 'Recovery';
    link.textContent = 'Esqueci minha senha / Desbloquear conta (AD)';
    link.style.cssText = 'display:block;margin:12px 0;text-align:center;font-size:13px;color:#1267b4';
    panel.appendChild(link);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', addLink);
  else addLink();
})();
