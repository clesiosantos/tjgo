<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use Glpi\Http\Firewall;
use Glpi\Security\Attribute\SecurityStrategy;
use GlpiPlugin\Gwselfservice\Directory;
use GlpiPlugin\Gwselfservice\NativeMfa;
use GlpiPlugin\Gwselfservice\PasswordGenerator;
use GlpiPlugin\Gwselfservice\Store;
use GlpiPlugin\Gwselfservice\TestSandbox;
use GlpiPlugin\Gwselfservice\TicketWorkflow;
use GlpiPlugin\Gwselfservice\TestPolicy;
use GlpiPlugin\Gwselfservice\Ui;
use GlpiPlugin\Gwselfservice\Transport;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/** Public route; identity verified using GLPI 11 native TOTP before any ITSM/AD action. */
final class RecoveryController extends AbstractController
{
    #[Route('/Recovery', name: 'gwselfservice_recovery', methods: ['GET', 'POST'])]
    #[SecurityStrategy(Firewall::STRATEGY_NO_CHECK)]
    public function __invoke(Request $request): Response
    {
        // NEVER accept an actual GLPI password, GLPI MFA code, or AD password over HTTP.
        if (!Transport::isSecure($request)) {
            return TestSandbox::recovery($request);
        }
        $c = Store::config();
        $message = '';
        $success = false;
        $ticketId = 0;
        $passwordToShowOnce = null;
        $passwordWasReallyChanged = false;
        $operation = '';
        $simulated = (string)($c['mode'] ?? 'simulation') !== 'test_ad';

        if ($request->isMethod('POST')) {
            $login = trim((string)$request->request->get('login', ''));
            $operation = (string)$request->request->get('operation', '');
            $code = (string)$request->request->get('totp', '');
            $ip = Transport::clientIp($request);
            $message = 'Não foi possível concluir. Confirme o método MFA ou procure o Service Desk.';
            $ids = null;
            $uid = 0;
            try {
                if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                    throw new \RuntimeException('Sessão expirada. Atualize a página e tente novamente.');
                }
                if (!Store::allowAttempt($login, $ip)) {
                    Store::audit($login, 0, 'rate_limit', 'blocked');
                    throw new \RuntimeException('Limite temporário de tentativas excedido.');
                }
                if (!in_array($operation, ['reset', 'unlock'], true)
                    || empty($c['enabled'])
                    || ($operation === 'reset' && empty($c['reset_enabled']))
                    || ($operation === 'unlock' && empty($c['unlock_enabled']))) {
                    throw new \RuntimeException('Serviço indisponível.');
                }
                if (!preg_match('/^[a-zA-Z0-9._-]{1,120}$/D', $login)) {
                    throw new \RuntimeException('Identificação não autorizada.');
                }
                // LDAP lookup is restricted to allowed OU; disabled AD accounts are rejected.
                $ldap = Directory::connect($c);
                $ad = Directory::findAccount($ldap, $c, $login);
                if (!$ad) {
                    throw new \RuntimeException('Identidade não localizada ou não permitida.');
                }
                $glpiUser = NativeMfa::userForAccount($ad);
                if (!$glpiUser) {
                    throw new \RuntimeException('Conta não corresponde a um usuário LDAP importado no GLPI.');
                }
                $uid = (int)$glpiUser['id'];
                if (!NativeMfa::isEnrolled($uid)) {
                    Store::audit($login, $uid, $operation, 'mfa_not_enabled');
                    throw new \RuntimeException('MFA nativo não está cadastrado para este usuário.');
                }
                if (!NativeMfa::verify($uid, $code)) {
                    Store::audit($login, $uid, $operation, 'mfa_denied');
                    throw new \RuntimeException('Código MFA inválido, expirado ou já utilizado.');
                }
                Store::audit($login, $uid, $operation, 'mfa_verified');
                // Fail closed: ticket, correct requester/group, KB, followup and task must exist before AD writes.
                $ids = TicketWorkflow::open($c, $uid, $login, $operation);
                $ticketId = (int)$ids['ticket_id'];
                $password = null;
                if ($operation === 'reset') {
                    $password = PasswordGenerator::generate();
                }
                if (!$simulated) {
                    if (!TestPolicy::mayWriteToAd($c, (string)$ad['dn'], Transport::isSecure($request))) {
                        throw new \RuntimeException('Escrita no AD bloqueada: OU, HTTPS, modo ou configuração incorreta.');
                    }
                    if ($operation === 'reset') {
                        // Force password change at next login regardless of stale settings.
                        $forceChangeSucceeded = Directory::resetPassword($ldap, (string)$ad['dn'], (string)$password, true, Transport::isSecure($request));
                        $passwordWasReallyChanged = true;
                        $passwordToShowOnce = $password;
                        if (!$forceChangeSucceeded) {
                            TicketWorkflow::bestEffortFailure($ticketId,
                                'Senha redefinida no AD, mas a marcação pwdLastSet=0 falhou. Necessária intervenção do N1.');
                            Store::audit($login, $uid, $operation, 'password_changed_flag_failed', 'Verificar pwdLastSet', $ticketId);
                            $message = 'A senha foi alterada, mas não foi possível exigir a troca no próximo logon. Chamado #' . $ticketId . ' encaminhado ao N1.';
                            return self::resultPage($c, $message, false, $ticketId, $passwordToShowOnce, true);
                        }
                    } else {
                        Directory::unlock($ldap, (string)$ad['dn'], Transport::isSecure($request));
                    }
                } else {
                    // No actual LDAP mutation; generated password is purely illustrative and NEVER stored.
                    if ($operation === 'reset') {
                        $passwordToShowOnce = $password;
                    }
                }
                try {
                    TicketWorkflow::finish($ids, $uid, $operation, $simulated);
                } catch (\Throwable $finalizeError) {
                    TicketWorkflow::bestEffortFailure($ticketId, 'Falha na finalização ITSM: ' . $finalizeError->getMessage());
                    Store::audit($login, $uid, $operation, 'itsm_partial', 'Verificar registros do chamado', $ticketId);
                    $message = 'Operação ' . ($simulated ? 'simulada' : 'real') . ' executada, mas não foi possível encerrar corretamente o chamado #' . $ticketId . '. N1 deve verificar.';
                    return self::resultPage($c, $message, false, $ticketId, $passwordToShowOnce, $passwordWasReallyChanged);
                }
                Store::audit($login, $uid, $operation, $simulated ? 'simulated_closed' : 'ad_success_closed',
                    'POP 086; MFA nativo; chamado e solução concluídos', $ticketId);
                $success = true;
                $message = ($simulated ? 'Simulação concluída' : 'Operação efetuada no AD de testes')
                    . '. Chamado #' . $ticketId . ' encerrado com acompanhamento, tarefa, base e solução.';
            } catch (\Throwable $e) {
                $reason = $e->getMessage();
                // Keep verbose diagnostic messages out of public pages (account enumeration resistance).
                if ($ticketId > 0) {
                    TicketWorkflow::bestEffortFailure($ticketId, 'Falha na operação: ' . $reason);
                    Store::audit($login, $uid, $operation, 'operation_failed', 'Ticket aberto para N1', $ticketId);
                    $message = 'Não foi possível concluir automaticamente. Chamado #' . $ticketId . ' permanece em atendimento pelo N1.';
                } else {
                    Store::audit($login, $uid, $operation, 'rejected');
                    $message = 'Não foi possível validar a solicitação ou o MFA. Verifique o cadastro e tente novamente.';
                }
                error_log('GW Self-Service: recuperação não concluída (sem dados sensíveis).');
            }
        }
        return self::resultPage($c, $message, $success, $ticketId, $passwordToShowOnce, $passwordWasReallyChanged);
    }

    private static function resultPage(array $c, string $message, bool $success, int $ticketId,
        ?string $passwordToShowOnce, bool $reallyChanged): Response
    {
        $mode = (string)($c['mode'] ?? 'simulation');
        $simulated = $mode !== 'test_ad';
        $notice = '<div class="test-banner"><strong>POC TJ-GO — AMBIENTE DE TESTE</strong><p>'
            . ($simulated ? 'Simulação; não altera o Active Directory.' : 'AD real apenas na OU de laboratório. LDAPS e HTTPS obrigatórios.')
            . '</p></div>';
        $content = $notice;
        if ($message !== '') {
            $content .= Ui::alert($message, $success);
        }
        if ($ticketId > 0) {
            $content .= '<section class="panel"><h2>Registro do atendimento</h2><p>Chamado GLPI: <strong>#' . $ticketId . '</strong> · Categoria ITIL 954 · POP 086 · Equipe N1.</p>'
                . '<p><a href="' . Ui::h(self::ticketUrl($ticketId)) . '">Consultar chamado no GLPI (exige autenticação)</a></p></section>';
        }
        if ($passwordToShowOnce !== null) {
            $content .= '<section class="panel">'
                . '<h2>' . ($reallyChanged ? 'Nova senha temporária do AD' : 'Senha fictícia de demonstração') . '</h2>'
                . '<p><strong>' . ($reallyChanged ? 'Apresentada uma única vez, em conexão HTTPS.' : 'Não aplicada ao Active Directory.') . '</strong></p>'
                . '<p class="temporary-password"><code>' . Ui::h($passwordToShowOnce) . '</code></p>'
                . '<p>' . ($reallyChanged ? 'Copie agora e entre com a nova senha. O AD exigirá a troca no próximo logon se a operação foi concluída integralmente.' : 'Esta senha serve apenas para demonstrar a interface de recuperação.') . '</p>'
                . '<p>Ela não foi registrada no chamado, acompanhamento, tarefa, solução ou auditoria.</p></section>';
        }
        $content .= '<section class="panel"><h2>Recuperação de acesso — MFA nativo</h2>'
            . '<p>O login deve pertencer ao AD e estar importado no GLPI com o 2FA nativo ativo. Use o código do mesmo aplicativo configurado em Minhas preferências do GLPI 11.</p>'
            . '<form method="post" autocomplete="off">' . Ui::formToken()
            . Ui::input('login', 'Login do AD (sem @poc.local)', '', 'text', 'Ex.: joao.silva', true)
            . '<fieldset class="choice"><legend>Serviço (POP 086)</legend><label><input type="radio" name="operation" value="reset" checked> Esqueci minha senha</label><label><input type="radio" name="operation" value="unlock"> Desbloquear minha conta</label></fieldset>'
            . Ui::input('totp', 'Código do MFA NATIVO do GLPI (6 dígitos)', '', 'text', 'Método previamente cadastrado no GLPI. Não requer a senha do AD.', true)
            . '<button type="submit">Validar identidade e executar autosserviço</button></form></section>'
            . '<section class="note">Sem MFA nativo cadastrado ou sem vínculo de identidade LDAP válido, o processo é negado e o usuário deve procurar o Service Desk. Nenhuma senha ou código é persistido.</section>';
        return Ui::page('Autosserviço de credenciais', $content, true);
    }

    private static function ticketUrl(int $ticketId): string
    {
        global $CFG_GLPI;
        return rtrim((string)($CFG_GLPI['root_doc'] ?? ''), '/') . '/front/ticket.form.php?id=' . $ticketId;
    }
}
