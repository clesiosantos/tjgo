<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\Store;
use GlpiPlugin\Gwselfservice\Transport;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/** Dashboard and GUI-only onboarding for Traefik reverse proxy in Docker Compose. */
final class TransportController extends AbstractController
{
    #[Route('/Transport', name: 'gwselfservice_transport', methods: ['GET', 'POST'])]
    public function __invoke(Request $request): Response
    {
        if (!\Session::haveRight('config', UPDATE)) {
            return Ui::page('Acesso restrito', Ui::alert('Apenas administradores podem configurar o proxy.'), false, 403);
        }
        $message = '';
        $ok = false;
        $peer = Transport::currentProxy($request);
        if ($request->isMethod('POST')) {
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada. Atualize a página.';
            } elseif ((string)$request->request->get('confirm', '') !== '1') {
                $message = 'Confirme que o navegador abriu o endereço público por HTTPS e que o acesso ao contêiner é restrito ao Traefik.';
            } else {
                try {
                    $action = (string)$request->request->get('action', '');
                    if ($action === 'reset') {
                        Store::saveConfig(['trusted_proxy_cidrs' => '']);
                        $message = 'Confiança cadastrada pela interface removida. A configuração de ambiente do Portainer, se houver, continua ativa.';
                        $ok = true;
                    } else {
                        if (!Transport::canTrustCurrentProxy($request)) {
                            throw new \RuntimeException('Sem X-Forwarded-Proto: https ou sem endereço privado de proxy. Não é possível autorizar automaticamente.');
                        }
                        $candidate = $action === 'trust_current'
                            ? $peer
                            : trim((string)$request->request->get('cidr', ''));
                        if (!Transport::isSafeGuiProxyCidr($candidate)) {
                            throw new \RuntimeException('Informe IP privado ou CIDR privado /24 a /32 (IPv6 /64 a /128). Nunca 0.0.0.0/0.');
                        }
                        if (!Transport::inCidrs($peer, [$candidate])) {
                            throw new \RuntimeException('O IP/CIDR informado não contém o endereço do proxy que acessa o GLPI agora.');
                        }
                        $existing = Transport::parseCidrList((string)(Store::config()['trusted_proxy_cidrs'] ?? ''));
                        $existing[] = $candidate;
                        $existing = array_values(array_unique($existing));
                        if (count($existing) > 16) {
                            throw new \RuntimeException('Limite de 16 redes confiáveis cadastradas pela interface.');
                        }
                        Store::saveConfig(['trusted_proxy_cidrs' => implode(',', $existing)]);
                        $message = 'Traefik autorizado na configuração do plugin: ' . $candidate . '. Configuração aplicada imediatamente, sem reiniciar a Stack.';
                        $ok = true;
                    }
                    Store::audit('', (int)\Session::getLoginUserID(), 'proxy_trust', 'saved');
                } catch (\Throwable $e) {
                    $message = $e->getMessage();
                }
            }
        }

        $info = Transport::diagnostic($request);
        $secure = (bool)$info['effective_https'];
        $rows = [
            'GLPI / Symfony reconhece HTTPS' => $info['symfony_https'] ? 'Sim' : 'Não',
            'Proxy configurado (interface ou Portainer)' => $info['proxy_configured'] ? 'Sim' : 'Não',
            'Peer imediato confiável' => $info['proxy_authorized'] ? 'Sim' : 'Não',
            'Protocolo informado pelo Traefik' => (string)$info['forwarded_scheme'],
            'HTTPS reconhecido pelo plugin' => $secure ? 'SIM — MFA e formulários disponíveis' : 'NÃO — só demonstração fictícia',
            'IP do Traefik visto pelo GLPI' => (string)$info['direct_peer'],
            'IP para auditoria' => (string)$info['client_ip'],
        ];
        $table = '';
        foreach ($rows as $key => $value) {
            $table .= '<tr><th>' . Ui::h($key) . '</th><td>' . Ui::h($value) . '</td></tr>';
        }
        $current = (string)(Store::config()['trusted_proxy_cidrs'] ?? '');
        $body = '<div class="test-banner"><strong>POC TJ-GO · Docker Compose / Portainer / Traefik</strong><p>Diagnóstico e configuração de proxy pela interface. O modo simulação continua como padrão; nenhuma mudança real no AD é habilitada automaticamente.</p></div>';
        if ($message !== '') {
            $body .= Ui::alert($message, $ok);
        }
        $body .= Ui::alert($secure ? 'HTTPS externo reconhecido. Utilize a configuração do AD e o portal público normalmente.' : 'HTTPS externo ainda não reconhecido. Se você acessou o GLPI por HTTPS, autorize o Traefik no formulário abaixo.', $secure);
        $body .= '<section class="panel"><h2>Diagnóstico da conexão</h2><div class="table"><table><tbody>' . $table . '</tbody></table></div></section>';
        $body .= '<section class="panel"><h2>Autorizar Traefik neste ambiente de teste</h2>'
            . '<p><strong>IP visto agora:</strong> <code>' . Ui::h($peer) . '</code>. O endereço deve ser o proxy Traefik, e não o navegador.</p>'
            . '<p><strong>Lista gravada no banco GLPI:</strong> <code>' . Ui::h($current === '' ? 'nenhum' : $current) . '</code>. Essa configuração é compartilhada entre contêineres e não depende de .env ou reinício.</p>';
        if (Transport::canTrustCurrentProxy($request)) {
            $body .= '<form method="post">' . Ui::formToken()
                . '<input type="hidden" name="action" value="trust_current">'
                . '<label class="checkbox"><input type="checkbox" name="confirm" value="1" required> Confirmo que acessei pelo HTTPS externo do Traefik e que o contêiner GLPI não está acessível diretamente por usuários.</label>'
                . '<button type="submit">Confiar no Traefik ' . Ui::h($peer) . ' agora</button></form>'
                . '<hr><p>Se o IP do Traefik mudar ao atualizar o Docker Compose, informe a subnet real da rede Docker do proxy (ex.: <code>10.0.2.0/24</code> somente se essa for a rede correta):</p>'
                . '<form method="post">' . Ui::formToken() . '<input type="hidden" name="action" value="trust_cidr">'
                . Ui::input('cidr', 'Rede privada exata do Traefik (IP/CIDR)', '', 'text', 'A rede informada deve conter o IP ' . $peer . '; limite mínimo /24 em IPv4.', true)
                . '<label class="checkbox"><input type="checkbox" name="confirm" value="1" required> Confirmo HTTPS público e rede interna exclusiva do proxy.</label>'
                . '<button type="submit" class="secondary">Salvar rede de confiança</button></form>';
        } else {
            $body .= '<p class="info">A aprovação pelo navegador só é apresentada quando o endereço de origem é privado e o Traefik informa <code>X-Forwarded-Proto: https</code>. Não é permitido confiar automaticamente em HTTP direto.</p>';
        }
        $body .= '<hr><form method="post">' . Ui::formToken() . '<input type="hidden" name="action" value="reset">'
            . '<label class="checkbox"><input type="checkbox" name="confirm" value="1" required> Confirmo remover os proxies cadastrados nesta interface.</label>'
            . '<button class="secondary" type="submit">Remover confiança cadastrada</button></form></section>'
            . '<section class="note"><h3>Alternativa pelo Portainer (sem atualizar o plugin)</h3>'
            . '<p>Na Stack do GLPI: <code>GWSS_TRUSTED_PROXY_CIDRS=10.0.2.147/32</code>, substituindo pelo IP real exibido na tabela. Atualize a Stack. Essa variável é uma alternativa, não é obrigatória quando o proxy for autorizado aqui.</p>'
            . '<p>O Traefik deve terminar o HTTPS público e sobrescrever corretamente os cabeçalhos encaminhados. Não publique a porta HTTP do GLPI diretamente na internet nem confie em <code>0.0.0.0/0</code>. A comunicação LDAPS com o AD continua independente.</p></section>';
        return Ui::page('Diagnóstico e configuração Traefik', $body);
    }
}
