<?php
namespace GlpiPlugin\Gwselfservice;

use Glpi\Security\TOTPManager;

/** Identity must match an already-imported active LDAP user of this GLPI. */
final class NativeMfa
{
    public static function userForAccount(array $account): ?array
    {
        global $DB;
        $login = (string)($account['login'] ?? '');
        if ($login === '' || !preg_match('/^[\pL\pN._-]{1,120}$/uD', $login)) {
            return null;
        }
        // GLPI imports LDAP users with their DN, auth source, and active status.
        $matches = [];
        foreach ($DB->request(['FROM' => 'glpi_users', 'WHERE' => [
            'name' => $login, 'is_active' => 1, 'is_deleted' => 0,
        ]]) as $user) {
            $dn = trim((string)($user['user_dn'] ?? ''));
            $adDn = trim((string)($account['dn'] ?? ''));
            if ($dn === '' || $adDn === '' || strcasecmp($dn, $adDn) !== 0) {
                continue;
            }
            // Do not accept local GLPI users even if their names collide.
            if ((int)($user['auths_id'] ?? 0) < 1) {
                continue;
            }
            $matches[] = $user;
        }
        return count($matches) === 1 ? $matches[0] : null;
    }

    public static function isEnrolled(int $usersId): bool
    {
        return $usersId > 0 && (new TOTPManager())->is2FAEnabled($usersId);
    }

    public static function verify(int $usersId, string $code): bool
    {
        if ($usersId < 1 || !preg_match('/^[0-9]{6}$/D', $code)) {
            return false;
        }
        $mfa = new TOTPManager();
        if (!$mfa->is2FAEnabled($usersId)) {
            return false;
        }
        // GLPI core validates the native TOTP secret; no secret is exported.
        if (!$mfa->verifyCodeForUser($code, $usersId)) {
            return false;
        }
        // A step may authorize only one self-service operation, across sessions.
        return Store::consumeNativeMfaStep($usersId, intdiv(time(), 30));
    }
}
