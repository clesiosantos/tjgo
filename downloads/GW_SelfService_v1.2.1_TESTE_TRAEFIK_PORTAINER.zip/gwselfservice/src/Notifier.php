<?php
namespace GlpiPlugin\Gwselfservice;

final class Notifier
{
    /** Optional offline email channel. No secrets, QR codes, or passwords are sent. */
    public static function sendIfEnabled(array $config, array $account, string $operation, bool $simulation, int $uid): void
    {
        // A edição de teste não envia comunicação a endereços reais.
        if (!TestPolicy::mayWriteToAd()) {
            return;
        }
        if (empty($config['notify_enabled'])) {
            return;
        }
        $to = (string)($account['email'] ?? '');
        $from = (string)($config['mail_from'] ?? '');
        if (!filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
            Store::audit((string)$account['login'], $uid, 'email', 'not_configured');
            return;
        }
        $text = ($simulation ? 'SIMULACAO' : 'EXECUCAO REAL') . "\n"
            . 'Operacao: ' . ($operation === 'unlock' ? 'Desbloqueio de conta' : 'Redefinicao de senha') . "\n"
            . 'Uma operacao de autosservico foi solicitada para seu login.' . "\n"
            . 'Se voce nao reconhece essa operacao, contate o Service Desk TJ-GO imediatamente.' . "\n";
        $headers = [
            'From: ' . $from,
            'Content-Type: text/plain; charset=UTF-8',
            'X-Auto-Response-Suppress: All',
        ];
        $sent = @mail($to, 'TJ-GO - Confirmacao de autosservico', $text, implode("\r\n", $headers));
        Store::audit((string)$account['login'], $uid, 'email', $sent ? 'sent' : 'failed');
    }
}
