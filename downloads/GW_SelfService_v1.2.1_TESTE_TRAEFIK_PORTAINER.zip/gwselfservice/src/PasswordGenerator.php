<?php
namespace GlpiPlugin\Gwselfservice;

final class PasswordGenerator
{
    public static function generate(int $length = 18): string
    {
        $uppercase = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $lowercase = 'abcdefghijkmnopqrstuvwxyz';
        $digits = '23456789';
        $special = '!@#$%*+-_';
        $all = $uppercase . $lowercase . $digits . $special;
        $pwd = [
            $uppercase[random_int(0, strlen($uppercase) - 1)],
            $lowercase[random_int(0, strlen($lowercase) - 1)],
            $digits[random_int(0, strlen($digits) - 1)],
            $special[random_int(0, strlen($special) - 1)],
        ];
        for ($i = 4; $i < $length; $i++) {
            $pwd[] = $all[random_int(0, strlen($all) - 1)];
        }
        for ($i = count($pwd) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$pwd[$i], $pwd[$j]] = [$pwd[$j], $pwd[$i]];
        }
        return implode('', $pwd);
    }
}
