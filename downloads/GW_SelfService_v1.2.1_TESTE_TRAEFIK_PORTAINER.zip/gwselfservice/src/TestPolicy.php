<?php
namespace GlpiPlugin\Gwselfservice;

/** Safe by default: REAL writes require HTTPS plus explicit test-AD mode and scoped OU. */
final class TestPolicy
{
    public static function mayWriteToAd(?array $config = null, string $dn = '', bool $https = false): bool
    {
        if (!$https) {
            return false;
        }
        $c = $config ?? Store::config();
        $allowed = trim((string)($c['allowed_ou'] ?? ''));
        $base = trim((string)($c['base_dn'] ?? ''));
        return $https && (string)($c['mode'] ?? '') === 'test_ad'
            && (int)($c['enabled'] ?? 0) === 1
            && (int)($c['port'] ?? 0) === 636
            && $allowed !== '' && $base !== ''
            && strcasecmp($allowed, $base) !== 0
            && Directory::withinDn($allowed, $base)
            && $dn !== '' && Directory::withinDn($dn, $allowed);
    }
}
