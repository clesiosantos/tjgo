<?php
namespace GlpiPlugin\Gwselfservice;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use GlpiPlugin\Gwselfservice\Transport;

/**
 * Demonstração HTTP isolada, sem autenticação real, segredos, senhas ou acesso LDAP.
 * NÃO demonstra comprovação de identidade. A finalidade é apenas testar telas,
 * formulários, fluxo e trilha de auditoria antes de configurar HTTPS.
 */
final class TestSandbox
{
    public const DEMO_LOGIN = 'usuario.poc';
    public const DEMO_CODE = '123456';

    public static function matchesDemo(string $login, string $code): bool
    {
        return hash_equals(self::DEMO_LOGIN, strtolower(trim($login)))
            && hash_equals(self::DEMO_CODE, trim($code));
    }

    public static function recovery(Request $request): Response
    {
        $message = '';
        $ok = false;
        if ($request->isMethod('POST')) {
            $login = trim((string)$request->request->get('login', ''));
            $code = (string)$request->request->get('demo_code', '');
            $operation = (string)$request->request->get('operation', '');
            $ip = Transport::clientIp($request);
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada. Atualize a página e tente novamente.';
            } elseif (!in_array($operation, ['reset', 'unlock'], true)) {
                $message = 'Selecione uma operação de demonstração válida.';
            } elseif (!Store::allowAttempt('demo:' . $login, $ip)) {
                $message = 'Muitas tentativas de demonstração. Aguarde antes de tentar novamente.';
                Store::audit(self::DEMO_LOGIN, 0, 'demo_rate_limit', 'blocked');
            } elseif (!self::matchesDemo($login, $code)) {
                $message = 'Dados demonstrativos inválidos. Utilize exclusivamente a conta e o código exibidos nesta página.';
                Store::audit(self::DEMO_LOGIN, 0, 'demo_' . $operation, 'demo_denied');
            } else {
                $action = $operation === 'reset' ? 'redefinição de senha' : 'desbloqueio de conta';
                Store::audit(self::DEMO_LOGIN, 0, 'demo_' . $operation, 'simulated', 'HTTP sem acesso LDAP e sem fator real');
                $message = 'Demonstração concluída: ' . $action . ' SIMULADO(A). Nenhuma conta, senha ou bloqueio foi alterado no Active Directory. A validação não constitui prova de identidade.';
                $ok = true;
            }
        }
        $content = '<div class="test-banner"><strong>AMBIENTE DE TESTE — SIMULAÇÃO HTTP</strong><p>Esta página usa dados fictícios e não consulta o AD. O código abaixo é público e NÃO comprova a identidade de um usuário real. Nenhuma alteração de senha ou desbloqueio será executada.</p></div>'
            . ($message !== '' ? Ui::alert($message, $ok) : '')
            . '<section class="panel"><h2>Simular autosserviço de credenciais</h2><p>Utilize os dados de exemplo para demonstrar a solicitação, confirmação fictícia e registro de auditoria.</p>'
            . '<div class="demo-credentials"><strong>Identidade fictícia:</strong> <code>usuario.poc</code> &nbsp; <strong>Código de demonstração:</strong> <code>123456</code></div>'
            . '<form method="post" autocomplete="off">' . Ui::formToken()
            . Ui::input('login', 'Usuário fictício da POC', '', 'text', 'Use apenas usuario.poc; não informe contas reais do domínio.', true)
            . '<fieldset class="choice"><legend>Operação simulada</legend><label><input type="radio" name="operation" value="reset" checked> Esqueci minha senha</label><label><input type="radio" name="operation" value="unlock"> Desbloquear minha conta</label></fieldset>'
            . Ui::input('demo_code', 'Código fictício (não é OTP real)', '', 'text', 'Exemplo: 123456', true)
            . '<button type="submit">Executar simulação</button></form></section>'
            . '<section class="note"><strong>Para homologar com AD e TOTP reais:</strong> configure HTTPS válido ou corrija a confiança do proxy reverso. Em HTTPS, o modo simulação pode registrar chamados reais no GLPI; o modo AD TESTE exige autorização explícita, MFA nativo e OU isolada.</section>';
        return Ui::page('Recuperação — demonstração', $content, true);
    }

    public static function settings(): Response
    {
        $body = '<div class="test-banner"><strong>PAINEL DE TESTE — HTTP</strong><p>O GLPI considera esta conexão insegura. Para não expor a senha da conta de serviço nem a configuração sensível do AD, os campos de conexão não podem ser exibidos ou enviados por HTTP.</p></div>'
            . '<section class="panel"><h2>Homologação sem alterar o Active Directory</h2>'
            . '<p>O fluxo fictício está disponível em <a href="' . Ui::h(Ui::url('Recovery')) . '">Recuperação — demonstração</a>. Use <code>usuario.poc</code> e <code>123456</code>.</p>'
            . '<p>Para configurar host, DN, OU e usuário de vínculo, abra esta tela via HTTPS externo reconhecido pelo GLPI ou por proxy confiável. Consulte o <a href="' . Ui::h(Ui::url('Transport')) . '">diagnóstico de HTTPS/Proxy</a> como administrador.</p>'
            . '<p><strong>Diagnóstico:</strong> o Symfony não identificou a requisição como segura. Se o navegador já mostra HTTPS e a conexão chega pelo Traefik, abra o diagnóstico do plugin e autorize o IP privado do proxy. Não aceite diretamente cabeçalhos de clientes não confiáveis.</p></section>'
            . '<section class="note">O acesso HTTP é sempre uma simulação sem chamados reais nem acesso LDAP. Escritas em AD de testes exigem HTTPS, configuração explícita e OU de laboratório.</section>';
        return Ui::page('Configuração — ambiente de teste', $body);
    }

    public static function enrollment(): Response
    {
        $body = '<div class="test-banner"><strong>AMBIENTE DE TESTE — CADASTRO INDISPONÍVEL EM HTTP</strong><p>O 2FA nativo do GLPI e a confirmação da identidade devem utilizar HTTPS. Nunca solicite senha ou códigos em HTTP.</p></div>'
            . '<section class="panel"><h2>Fluxo de cadastro</h2><p>Em HTTPS, o usuário autentica no GLPI e configura a autenticação de dois fatores nativa em Minhas preferências. O plugin valida esse mesmo fator na recuperação pública.</p><p>Para demonstrar o autosserviço sem segredos reais neste ambiente HTTP, acesse o <a href="' . Ui::h(Ui::url('Recovery')) . '">portal de recuperação de teste</a>.</p></section>';
        return Ui::page('Cadastro TOTP — ambiente de teste', $body);
    }
}
