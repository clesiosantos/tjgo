<?php
namespace GlpiPlugin\Gwselfservice;

/** Uses GLPI native ticket/followup/task/knowledge/solution classes. */
final class TicketWorkflow
{
    private const CATEGORY_ID = 954;

    public static function validateConfiguration(array $config): void
    {
        $category = new \ITILCategory();
        if (!$category->getFromDB(self::CATEGORY_ID) || (int)($category->fields['is_request'] ?? 0) !== 1) {
            throw new \RuntimeException('A categoria ITIL 954 de requisição não está disponível.');
        }
        $group = new \Group();
        $groupId = (int)($config['group_id'] ?? 12);
        if ($groupId < 1 || !$group->getFromDB($groupId)) {
            throw new \RuntimeException('O grupo solucionador N1 configurado não foi encontrado.');
        }
        $kb = new \KnowbaseItem();
        $kbId = (int)($config['kb_article_id'] ?? 0);
        if ($kbId < 1 || !$kb->getFromDB($kbId)) {
            throw new \RuntimeException('Informe um artigo existente da Base de Conhecimento (ID), não apenas a categoria da base.');
        }
    }

    private static function createRecord(string $class, array $data, string $label): int
    {
        $item = new $class();
        $id = $item->add($data);
        if (!$id) {
            throw new \RuntimeException('Falha ao criar ' . $label . ' no GLPI.');
        }
        return (int)$id;
    }

    private static function assigned(int $id, int $uid, int $group): void
    {
        global $DB;
        $hasReq = Store::first('glpi_tickets_users', [
            'tickets_id' => $id, 'users_id' => $uid, 'type' => 1,
        ]);
        if (!$hasReq) {
            self::createRecord(\Ticket_User::class, [
                'tickets_id' => $id, 'users_id' => $uid, 'type' => 1,
            ], 'vínculo do requerente');
        }
        $hasGroup = Store::first('glpi_groups_tickets', [
            'tickets_id' => $id, 'groups_id' => $group, 'type' => 2,
        ]);
        if (!$hasGroup) {
            self::createRecord(\Group_Ticket::class, [
                'tickets_id' => $id, 'groups_id' => $group, 'type' => 2,
            ], 'vínculo do grupo N1');
        }
    }

    public static function open(array $config, int $uid, string $login, string $operation): array
    {
        self::validateConfiguration($config);
        $group = (int)$config['group_id'];
        $kb = (int)$config['kb_article_id'];
        $label = $operation === 'reset' ? 'Redefinição de senha' : 'Desbloqueio de conta';
        $title = 'POP 086 - ' . $label . ' - ' . $login . ' - GW Self-Service';
        $content = "Origem: GW Self-Service (POC TJ-GO).\n"
            . "Serviço: POP 086 - Reset de senha de acesso (categoria ITIL 954).\n"
            . "Solicitante: {$login} (usuário GLPI ID {$uid}).\n"
            . "Identidade: conta LDAP importada com DN correspondente ao AD; MFA nativo GLPI 11 ativo e código validado.\n"
            . "Operação solicitada: {$label}.\n"
            . "Segurança: nenhuma senha ou código MFA será registrado neste chamado.";
        $ticketId = self::createRecord(\Ticket::class, [
            'name' => $title,
            'content' => $content,
            'entities_id' => (int)($config['entity_id'] ?? 0),
            'type' => 2,
            'status' => 1,
            'itilcategories_id' => self::CATEGORY_ID,
            'users_id_recipient' => $uid,
            '_users_id_requester' => $uid,
            '_groups_id_assign' => $group,
        ], 'chamado');
        Store::audit($login, $uid, $operation, 'ticket_open', 'Chamado #' . $ticketId, $ticketId);
        try {
            self::assigned($ticketId, $uid, $group);
            self::createRecord(\KnowbaseItem_Item::class, [
                'knowbaseitems_id' => $kb, 'itemtype' => \Ticket::class, 'items_id' => $ticketId,
            ], 'vínculo do artigo da base');
            self::createRecord(\ITILFollowup::class, [
                'itemtype' => \Ticket::class, 'items_id' => $ticketId,
                'content' => 'Solicitação recebida pelo portal. MFA nativo habilitado e código TOTP validado. Encaminhamento automático para N1. Nenhuma credencial foi registrada.',
                'is_private' => 0, 'users_id' => $uid,
            ], 'acompanhamento inicial');
            $taskId = self::createRecord(\TicketTask::class, [
                'tickets_id' => $ticketId,
                'content' => $label . ' no AD de homologação. Verificar execução via LDAPS, exigir troca da senha no próximo login quando aplicável e registrar resultado sem gravar credenciais.',
                'state' => 1, 'is_private' => 1,
            ], 'tarefa técnica');
            return ['ticket_id' => $ticketId, 'task_id' => $taskId];
        } catch (\Throwable $e) {
            self::bestEffortFailure($ticketId, 'Preparação incompleta: ' . $e->getMessage());
            throw new \RuntimeException('Chamado #' . $ticketId . ' aberto, porém a preparação ITSM falhou: ' . $e->getMessage(), 0, $e);
        }
    }

    public static function finish(array $ids, int $uid, string $operation, bool $simulated): void
    {
        $tid = (int)$ids['ticket_id'];
        $taskId = (int)$ids['task_id'];
        $action = $operation === 'reset' ? 'Redefinição de senha' : 'Desbloqueio de conta';
        $prefix = $simulated ? 'SIMULAÇÃO (sem alteração no AD).' : 'EXECUÇÃO REAL DE HOMOLOGAÇÃO NO AD.';
        $details = $action . ' concluída. ' . $prefix
            . ($operation === 'reset' ? ' Troca obrigatória no próximo logon: ' . ($simulated ? 'simulada.' : 'confirmada (pwdLastSet=0).') : ' Conta desbloqueada ou operação simulada.');
        $task = new \TicketTask();
        if (!$task->update(['id' => $taskId, 'state' => defined('Planning::DONE') ? \Planning::DONE : 2,
            'content' => $details . ' Nenhuma senha foi registrada.'])) {
            throw new \RuntimeException('Falha ao concluir a tarefa técnica do chamado #' . $tid);
        }
        self::createRecord(\ITILFollowup::class, [
            'itemtype' => \Ticket::class, 'items_id' => $tid,
            'content' => 'Acompanhamento automático: ' . $details,
            'is_private' => 0, 'users_id' => $uid,
        ], 'acompanhamento de conclusão');
        self::createRecord(\ITILSolution::class, [
            'itemtype' => \Ticket::class, 'items_id' => $tid,
            'content' => 'Solução: ' . $details . ' Identidade previamente validada por MFA nativo do GLPI 11. POP 086; UST 1. Nova senha apresentada exclusivamente na resposta segura ao solicitante, não armazenada.',
        ], 'solução do chamado');
        $ticket = new \Ticket();
        if (!$ticket->update(['id' => $tid, 'status' => 6])) {
            throw new \RuntimeException('Solução registrada, mas não foi possível encerrar o chamado #' . $tid);
        }
    }

    public static function bestEffortFailure(int $tid, string $message): void
    {
        try {
            self::createRecord(\ITILFollowup::class, [
                'itemtype' => \Ticket::class, 'items_id' => $tid,
                'content' => 'GW Self-Service: atendimento automático incompleto. ' . mb_substr($message, 0, 600),
                'is_private' => 1,
            ], 'acompanhamento de falha');
        } catch (\Throwable $ignore) {
            error_log('GW Self-Service: falha ao registrar acompanhamento de erro no chamado #' . $tid);
        }
    }
}
