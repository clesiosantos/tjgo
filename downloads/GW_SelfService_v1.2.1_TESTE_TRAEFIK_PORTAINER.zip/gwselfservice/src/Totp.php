<?php
namespace GlpiPlugin\Gwselfservice;

final class Totp
{
    private const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

    public static function createSecret(): string
    {
        $raw = random_bytes(20);
        $buffer = 0;
        $bits = 0;
        $secret = '';
        foreach (str_split($raw) as $byte) {
            $buffer = ($buffer << 8) | ord($byte);
            $bits += 8;
            while ($bits >= 5) {
                $bits -= 5;
                $secret .= self::ALPHABET[($buffer >> $bits) & 31];
            }
        }
        return $secret;
    }

    private static function decode(string $secret): string
    {
        $buffer = 0;
        $bits = 0;
        $out = '';
        foreach (str_split(strtoupper(str_replace(' ', '', $secret))) as $char) {
            $n = strpos(self::ALPHABET, $char);
            if ($n === false) {
                throw new \InvalidArgumentException('Segredo TOTP inválido.');
            }
            $buffer = ($buffer << 5) | $n;
            $bits += 5;
            if ($bits >= 8) {
                $bits -= 8;
                $out .= chr(($buffer >> $bits) & 255);
            }
        }
        return $out;
    }

    public static function codeAt(string $secret, int $counter): string
    {
        $key = self::decode($secret);
        $binary = pack('N2', intdiv($counter, 0x100000000), $counter & 0xFFFFFFFF);
        $digest = hash_hmac('sha1', $binary, $key, true);
        $offset = ord($digest[19]) & 15;
        $value = (unpack('N', substr($digest, $offset, 4))[1] & 0x7FFFFFFF) % 1000000;
        return str_pad((string)$value, 6, '0', STR_PAD_LEFT);
    }

    /** Returns matched time counter or null, valid ±1 period. */
    public static function verify(string $secret, string $code, ?int $at = null): ?int
    {
        if (!preg_match('/^[0-9]{6}$/D', $code)) {
            return null;
        }
        $current = intdiv($at ?? time(), 30);
        $match = null;
        foreach ([-1, 0, 1] as $offset) {
            $counter = $current + $offset;
            if (hash_equals(self::codeAt($secret, $counter), $code)) {
                $match = $counter;
            }
        }
        return $match;
    }

    public static function qrDataUri(string $login, string $secret): string
    {
        // Library already bundled with GLPI 11; no cloud calls.
        if (!class_exists('RobThree\\Auth\\TwoFactorAuth') || !class_exists('RobThree\\Auth\\Providers\\Qr\\BaconQrCodeProvider')) {
            return '';
        }
        try {
            $provider = new \RobThree\Auth\Providers\Qr\BaconQrCodeProvider(4, '#ffffff', '#111827', 'svg');
            $tfa = new \RobThree\Auth\TwoFactorAuth($provider, 'TJ-GO GW Self-Service', 6, 30);
            return $tfa->getQRCodeImageAsDataUri($login, $secret, 220);
        } catch (\Throwable $e) {
            return '';
        }
    }

    public static function passwordStrong(string $password): bool
    {
        return strlen($password) >= 12
            && preg_match('/[A-Z]/', $password) === 1
            && preg_match('/[a-z]/', $password) === 1
            && preg_match('/[0-9]/', $password) === 1
            && preg_match('/[^a-zA-Z0-9]/', $password) === 1
            && strlen($password) <= 120;
    }
}
