<?php
namespace GlpiPlugin\Gwselfservice;

use Symfony\Component\HttpFoundation\Request;

/**
 * External TLS detection for GLPI 11 behind Kubernetes Ingress / reverse proxy.
 *
 * 1. Accept the scheme already resolved by GLPI/Symfony.
 * 2. If GLPI does not resolve upstream TLS, accept a forwarded HTTPS scheme ONLY
 *    when the immediate peer is inside an explicitly configured CIDR allowlist.
 * Do NOT trust client-controlled X-Forwarded-* or host headers by default.
 */
final class Transport
{
    /**
     * Two supported configuration methods:
     * - GWSS_TRUSTED_PROXY_CIDRS in the container (existing installations)
     * - trusted_proxy_cidrs in the plugin settings, persisted in the GLPI database
     *   and shared by all Docker/Portainer replicas.
     * The GUI accepts only private/loopback proxy addresses: never the public internet.
     * @return list<string>
     */
    public static function trustedProxies(): array
    {
        $environment = getenv('GWSS_TRUSTED_PROXY_CIDRS');
        $configured = '';
        if (isset($GLOBALS['DB']) && class_exists(Store::class)) {
            try {
                $configured = (string)(Store::config()['trusted_proxy_cidrs'] ?? '');
            } catch (\Throwable $e) {
                // Missing plugin table before installation: use environment only.
            }
        }
        $result = [];
        foreach ([$environment === false ? '' : (string)$environment, $configured] as $source) {
            foreach (self::parseCidrList($source) as $cidr) {
                if (!in_array($cidr, $result, true) && count($result) < 32) {
                    $result[] = $cidr;
                }
            }
        }
        return $result;
    }

    /** @return list<string> */
    public static function parseCidrList(string $value): array
    {
        $result = [];
        foreach (preg_split('/[,\r\n]+/', $value) ?: [] as $item) {
            $item = trim($item);
            if ($item !== '' && self::validCidr($item) && count($result) < 32) {
                $result[] = $item;
            }
        }
        return array_values(array_unique($result));
    }

    /** The GUI never trusts public IPs or broad/blanket networks. */
    public static function isSafeGuiProxyCidr(string $cidr): bool
    {
        if (!self::validCidr($cidr)) {
            return false;
        }
        [$ip, $prefix] = array_pad(explode('/', $cidr, 2), 2, null);
        if (!self::inCidrs($ip, ['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8', 'fc00::/7', '::1/128'])) {
            return false;
        }
        $bits = str_contains($ip, ':') ? 128 : 32;
        $mask = $prefix === null ? $bits : (int)$prefix;
        // GUI: at most one Docker IPv4 /24 network or a single IPv6 /64.
        if ($mask < ($bits === 32 ? 24 : 64)) {
            return false;
        }
        // Exclude CIDRs reaching out of RFC1918/loopback despite a private base IP.
        $privateRanges = ['10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16', '127.0.0.0/8', 'fc00::/7', '::1/128'];
        return self::inCidrs($ip, $privateRanges);
    }

    public static function canTrustCurrentProxy(Request $request): bool
    {
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        if (filter_var($peer, FILTER_VALIDATE_IP) === false || !self::isSafeGuiProxyCidr($peer)) {
            return false;
        }
        // The user must explicitly confirm TLS in the BROWSER; a header alone
        // is never sufficient to accept a new proxy.
        return self::forwardedScheme($request) === 'https';
    }

    public static function currentProxy(Request $request): string
    {
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        return filter_var($peer, FILTER_VALIDATE_IP) === false ? '' : $peer;
    }

    public static function isSecure(Request $request): bool
    {
        // GLPI's preconfigured Symfony Request (or direct TLS) takes priority.
        if ($request->isSecure()) {
            return true;
        }
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        $trusted = self::trustedProxies();
        if (!self::inCidrs($peer, $trusted)) {
            return false;
        }
        return self::forwardedScheme($request) === 'https';
    }

    /** @return array<string, string|bool> */
    public static function diagnostic(Request $request): array
    {
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        $cidrs = self::trustedProxies();
        $scheme = self::forwardedScheme($request);
        return [
            'symfony_https' => $request->isSecure(),
            'proxy_configured' => count($cidrs) > 0,
            'proxy_authorized' => self::inCidrs($peer, $cidrs),
            'forwarded_scheme' => $scheme ?? 'ausente/inválido',
            'effective_https' => self::isSecure($request),
            'direct_peer' => filter_var($peer, FILTER_VALIDATE_IP) !== false ? $peer : 'desconhecido',
            'client_ip' => self::clientIp($request),
        ];
    }

    public static function clientIpFromGlobals(): string
    {
        if (class_exists(Request::class)) {
            return self::clientIp(Request::createFromGlobals());
        }
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        return filter_var($ip, FILTER_VALIDATE_IP) !== false ? $ip : '';
    }

    public static function clientIp(Request $request): string
    {
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        if (filter_var($peer, FILTER_VALIDATE_IP) === false) {
            return '';
        }
        // Symfony may already have its own configured trusted proxy chain.
        $symfonyIp = (string)($request->getClientIp() ?? '');
        if ($symfonyIp !== '' && $symfonyIp !== $peer && filter_var($symfonyIp, FILTER_VALIDATE_IP)) {
            return $symfonyIp;
        }
        $trusted = self::trustedProxies();
        if (!self::inCidrs($peer, $trusted)) {
            return $peer;
        }
        // Traverse right to left; only peel hops listed as trusted.
        // This resists arbitrary fake leftmost XFF values when the edge proxy
        // appends its observed peer; Kubernetes ingress must also sanitize headers.
        $xff = trim((string)$request->headers->get('X-Forwarded-For', ''));
        if ($xff === '' || strlen($xff) > 1024) {
            return $peer;
        }
        $ips = array_map('trim', explode(',', $xff));
        if (count($ips) > 16) {
            return $peer;
        }
        $chain = array_merge($ips, [$peer]);
        for ($i = count($chain) - 1; $i >= 0; $i--) {
            $ip = $chain[$i];
            if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
                return $peer;
            }
            if (!self::inCidrs($ip, $trusted)) {
                return $ip;
            }
        }
        return $peer;
    }

    public static function inCidrs(string $ip, array $cidrs): bool
    {
        if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
            return false;
        }
        foreach ($cidrs as $cidr) {
            if (!self::validCidr($cidr)) {
                continue;
            }
            [$network, $prefix] = array_pad(explode('/', $cidr, 2), 2, null);
            $ipBinary = inet_pton($ip);
            $netBinary = inet_pton($network);
            if ($ipBinary === false || $netBinary === false || strlen($ipBinary) !== strlen($netBinary)) {
                continue;
            }
            $bits = $prefix === null ? strlen($ipBinary) * 8 : (int)$prefix;
            $whole = intdiv($bits, 8);
            $rest = $bits % 8;
            if (substr($ipBinary, 0, $whole) !== substr($netBinary, 0, $whole)) {
                continue;
            }
            if ($rest > 0 && ((ord($ipBinary[$whole]) ^ ord($netBinary[$whole])) & (0xFF << (8 - $rest))) !== 0) {
                continue;
            }
            return true;
        }
        return false;
    }

    private static function validCidr(string $cidr): bool
    {
        $parts = explode('/', $cidr, 2);
        if (count($parts) > 2 || filter_var($parts[0], FILTER_VALIDATE_IP) === false) {
            return false;
        }
        if (count($parts) === 1) {
            return true;
        }
        $bits = str_contains($parts[0], ':') ? 128 : 32;
        // Reject blanket 0/0 ranges: they allow anyone to forge HTTPS headers.
        return preg_match('/^(0|[1-9][0-9]*)$/D', $parts[1]) === 1
            && (int)$parts[1] >= 1 && (int)$parts[1] <= $bits;
    }

    private static function forwardedScheme(Request $request): ?string
    {
        $xfp = trim((string)$request->headers->get('X-Forwarded-Proto', ''));
        $forwarded = trim((string)$request->headers->get('Forwarded', ''));
        $candidates = [];
        if ($xfp !== '') {
            // Multi-hop values are accepted only if EVERY hop reports the same scheme.
            $values = array_map('trim', explode(',', strtolower($xfp)));
            if (count($values) > 8 || count(array_unique($values)) !== 1 || !in_array($values[0], ['https', 'http'], true)) {
                return null;
            }
            $candidates[] = $values[0];
        }
        if ($forwarded !== '') {
            if (strlen($forwarded) > 1024 || substr_count($forwarded, ',') > 7) {
                return null;
            }
            // RFC 7239: Forwarded: for=...;proto=https;by=...
            foreach (explode(',', $forwarded) as $element) {
                if (!preg_match('/(?:^|;)\s*proto\s*=\s*"?(https|http)"?\s*(?:;|$)/i', trim($element), $matches)) {
                    continue;
                }
                $candidates[] = strtolower($matches[1]);
            }
        }
        if ($candidates === [] || count(array_unique($candidates)) !== 1) {
            return null;
        }
        return $candidates[0];
    }
}
