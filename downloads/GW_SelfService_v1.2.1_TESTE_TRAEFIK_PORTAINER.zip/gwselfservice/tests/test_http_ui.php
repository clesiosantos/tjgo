<?php
// Lightweight HTTP UI render test without a running GLPI/Symfony instance.
namespace Symfony\Component\HttpFoundation {
    class Request {
        public object $request;
        private string $method;
        public function __construct(string $method='GET', array $data=[]) {
            $this->method = $method;
            $this->request = new class($data) {
                private array $data;
                public function __construct(array $data){$this->data=$data;}
                public function get(string $key,$default='') {return $this->data[$key] ?? $default;}
            };
        }
        public function isMethod(string $method): bool {return $this->method === $method;}
        public function getClientIp(): string {return '127.0.0.1';}
    }
    class Response {
        public function __construct(public string $content,public int $status=200,public array $headers=[]){}
    }
}
namespace {
    class Session {public static function getNewCSRFToken(): string {return 'glpi-test-csrf-token';}}
    $CFG_GLPI=['root_doc'=>'/glpi'];
    $_SESSION=[];
    require_once __DIR__.'/../src/Ui.php';
    require_once __DIR__.'/../src/TestSandbox.php';
    // DB and LDAP must never be required to render the public demo page.
    $r=\GlpiPlugin\Gwselfservice\TestSandbox::recovery(new \Symfony\Component\HttpFoundation\Request('GET'));
    if ($r->status !== 200 || !str_contains($r->content, 'AMBIENTE DE TESTE') || !str_contains($r->content, 'usuario.poc') || !str_contains($r->content, '123456')) {
        throw new RuntimeException('UI pública da edição de testes falhou.');
    }
    $s=\GlpiPlugin\Gwselfservice\TestSandbox::settings();
    if ($s->status !== 200 || str_contains($s->content, 'name="bind_secret"')) {
        throw new RuntimeException('Tela HTTP de configurações contém credenciais.');
    }
    $e=\GlpiPlugin\Gwselfservice\TestSandbox::enrollment();
    if ($e->status !== 200 || str_contains($e->content, 'name="ad_password"')) {
        throw new RuntimeException('Tela HTTP de cadastro solicita senha AD.');
    }
    echo "OK: UI HTTP de demonstração e bloqueios de formulários sensíveis.\n";
}
