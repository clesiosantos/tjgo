<?php
require_once __DIR__ . '/../src/TestPolicy.php';
require_once __DIR__ . '/../src/Directory.php';
require_once __DIR__ . '/../src/PasswordGenerator.php';
require_once __DIR__ . '/../src/Totp.php';

use GlpiPlugin\Gwselfservice\TestPolicy;
use GlpiPlugin\Gwselfservice\PasswordGenerator;
use GlpiPlugin\Gwselfservice\Totp;

$c = [
    'mode' => 'test_ad', 'enabled' => 1,
    'port' => 636, 'base_dn' => 'DC=poc,DC=local',
    'allowed_ou' => 'OU=UsuariosPOC,DC=poc,DC=local',
];
$dn = 'CN=Pessoa,OU=UsuariosPOC,DC=poc,DC=local';
assert(TestPolicy::mayWriteToAd($c, $dn, true) === true);
assert(TestPolicy::mayWriteToAd($c, $dn, false) === false);
assert(TestPolicy::mayWriteToAd($c, 'CN=Admin,CN=Users,DC=poc,DC=local', true) === false);
assert(TestPolicy::mayWriteToAd($c + ['other' => 'value'], '', true) === false);
assert(TestPolicy::mayWriteToAd(array_replace($c, ['mode' => 'simulation']), $dn, true) === false);
assert(TestPolicy::mayWriteToAd(array_replace($c, ['allowed_ou' => 'DC=poc,DC=local']), $dn, true) === false);
assert(TestPolicy::mayWriteToAd(array_replace($c, ['port' => 389]), $dn, true) === false);
for ($n = 0; $n < 100; $n++) {
    $password = PasswordGenerator::generate();
    assert(Totp::passwordStrong($password));
    assert(strlen($password) === 18);
}
echo "OK: mode / LDAPS / HTTPS / OU / password constraints\n";
