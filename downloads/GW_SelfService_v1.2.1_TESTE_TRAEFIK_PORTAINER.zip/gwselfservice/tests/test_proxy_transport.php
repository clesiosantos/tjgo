<?php
// No GLPI or Symfony installation needed: emulate the small Request surface.
namespace Symfony\Component\HttpFoundation {
    final class Request
    {
        public object $server;
        public object $headers;
        private bool $secure;
        private string $client;
        public function __construct(bool $secure, string $peer, array $headers = [], ?string $client = null)
        {
            $this->secure = $secure;
            $this->client = $client ?? $peer;
            $this->server = new class($peer) {
                public function __construct(private string $peer) {}
                public function get(string $key, $default = '') {return $key === 'REMOTE_ADDR' ? $this->peer : $default;}
            };
            $this->headers = new class($headers) {
                public function __construct(private array $items) {}
                public function get(string $key, $default = '') {
                    foreach ($this->items as $k => $v) {
                        if (strcasecmp($key, $k) === 0) return $v;
                    }
                    return $default;
                }
            };
        }
        public function isSecure(): bool {return $this->secure;}
        public function getClientIp(): string {return $this->client;}
    }
}
namespace {
    use GlpiPlugin\Gwselfservice\Transport;
    use Symfony\Component\HttpFoundation\Request;
    require_once __DIR__ . '/../src/Transport.php';
    function t(bool $pass, string $case): void {if (!$pass) throw new \RuntimeException('FAIL: ' . $case);}
    putenv('GWSS_TRUSTED_PROXY_CIDRS');
    t(Transport::isSecure(new Request(true, '198.51.100.10')), 'HTTPS direto reconhecido pelo GLPI');
    t(!Transport::isSecure(new Request(false, '198.51.100.10', ['X-Forwarded-Proto' => 'https'])), 'proibir spoof XFP direto');
    t(!Transport::isSecure(new Request(false, '10.0.1.7', ['Forwarded' => 'for=1.2.3.4;proto=https'])), 'sem proxy confiável bloquear Forwarded');
    putenv('GWSS_TRUSTED_PROXY_CIDRS=10.10.2.0/24,2001:db8:abcd::/48');
    t(Transport::isSecure(new Request(false, '10.10.2.19', ['X-Forwarded-Proto'=>'https'])), 'TLS externo com ingress permitido');
    t(Transport::isSecure(new Request(false, '10.10.2.19', ['Forwarded'=>'for=192.0.2.8;proto=https'])), 'Forwarded RFC 7239');
    t(Transport::isSecure(new Request(false, '2001:db8:abcd::2', ['X-Forwarded-Proto'=>'https'])), 'Ingress IPv6');
    t(!Transport::isSecure(new Request(false, '10.10.3.19', ['X-Forwarded-Proto'=>'https'])), 'peer não confiável');
    t(!Transport::isSecure(new Request(false, '10.10.2.19', ['X-Forwarded-Proto'=>'http'])), 'client HTTP externo');
    t(!Transport::isSecure(new Request(false, '10.10.2.19', ['X-Forwarded-Proto'=>'http, https'])), 'proibir esquema misto');
    t(!Transport::isSecure(new Request(false, '10.10.2.19', ['X-Forwarded-Proto'=>'https', 'Forwarded'=>'proto=http'])), 'proibir cabeçalhos conflitantes');
    t(!Transport::isSecure(new Request(false, '10.10.2.19', ['X-Forwarded-Proto'=>'https;evil'])), 'proibir conteúdo inválido');
    t(Transport::isSecure(new Request(false, '10.10.2.19', ['X-Forwarded-Proto'=>'https, https'])), 'aceitar mesma origem em cadeia');
    t(Transport::clientIp(new Request(false, '10.10.2.19', ['X-Forwarded-For'=>'203.0.113.66'])) === '203.0.113.66', 'IP cliente via ingress');
    t(Transport::clientIp(new Request(false, '10.10.2.19', ['X-Forwarded-For'=>'198.51.100.9, 203.0.113.66'])) === '203.0.113.66', 'ignorar XFF falso à esquerda');
    t(Transport::clientIp(new Request(false, '10.10.2.19', ['X-Forwarded-For'=>'203.0.113.66, 10.10.2.11'])) === '203.0.113.66', 'traversar proxies permitidos');
    putenv('GWSS_TRUSTED_PROXY_CIDRS=0.0.0.0/0');
    t(!Transport::isSecure(new Request(false, '203.0.113.66', ['X-Forwarded-Proto'=>'https'])), 'CIDR aberto proibido');
    putenv('GWSS_TRUSTED_PROXY_CIDRS=');
    echo "OK: HTTPS nativo, proxies CIDR/IPv6, cabeçalhos conflitantes, XFF, spoof e fail-closed\n";
}
