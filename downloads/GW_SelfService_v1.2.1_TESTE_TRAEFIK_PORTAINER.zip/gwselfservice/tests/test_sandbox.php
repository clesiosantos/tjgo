<?php
require __DIR__ . '/../src/TestPolicy.php';
require __DIR__ . '/../src/TestSandbox.php';
use GlpiPlugin\Gwselfservice\TestPolicy;
use GlpiPlugin\Gwselfservice\TestSandbox;
if (TestPolicy::mayWriteToAd() !== false) { throw new RuntimeException('Escrita AD indevidamente habilitada'); }
if (!TestSandbox::matchesDemo('usuario.poc', '123456')) { throw new RuntimeException('Demo deve aceitar dados de teste'); }
foreach ([['usuario.real','123456'], ['usuario.poc','654321'], ['','123456']] as [$u,$c]) {
  if (TestSandbox::matchesDemo($u,$c)) { throw new RuntimeException('Demo aceitou conta/código não demonstrativo'); }
}
echo "OK: edição de testes sem escrita AD e conta fictícia validada.\n";
