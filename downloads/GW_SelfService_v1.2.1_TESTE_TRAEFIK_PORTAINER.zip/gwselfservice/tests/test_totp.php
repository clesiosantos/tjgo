<?php
require_once __DIR__ . '/../src/Totp.php';
require_once __DIR__ . '/../src/Directory.php';

use GlpiPlugin\Gwselfservice\Totp;
use GlpiPlugin\Gwselfservice\Directory;

function expect(bool $condition, string $description): void {
    if (!$condition) { throw new RuntimeException('FAIL: ' . $description); }
    echo 'OK: ' . $description . PHP_EOL;
}
// RFC 6238 SHA1, t=59: eight digits 94287082 => truncated six digits 287082.
$secret = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';
expect(Totp::codeAt($secret, 1) === '287082', 'RFC 6238 known vector');
expect(Totp::verify($secret, '287082', 59) === 1, 'TOTP matches period');
expect(Totp::verify($secret, '287082', 120) === null, 'TOTP refuses distant period');
expect(Totp::verify($secret, '28708a', 59) === null, 'TOTP refuses non-digits');
expect(strlen(Totp::createSecret()) === 32, '160-bit random base32 secret');
expect(Totp::passwordStrong('Exemplo*Senha2026'), 'Strong password accepted');
expect(!Totp::passwordStrong('senha123'), 'Weak password refused');
expect(Directory::withinDn('CN=Teste,OU=POC,DC=poc,DC=local', 'OU=POC,DC=poc,DC=local'), 'DN inside allowed OU');
expect(!Directory::withinDn('CN=Teste,OU=PROD,DC=poc,DC=local', 'OU=POC,DC=poc,DC=local'), 'DN outside OU denied');
echo "All local tests passed.\n";
