<?php
namespace Symfony\Component\HttpFoundation {
    final class Request
    {
        public object $server;
        public object $headers;
        public function __construct(private string $peer, private string $scheme, private bool $secure = false)
        {
            $this->server = new class($peer) {
                public function __construct(private string $peer) {}
                public function get(string $key, $default = '') {return $key === 'REMOTE_ADDR' ? $this->peer : $default;}
            };
            $this->headers = new class($scheme) {
                public function __construct(private string $scheme) {}
                public function get(string $key, $default = '') {return $key === 'X-Forwarded-Proto' ? $this->scheme : $default;}
            };
        }
        public function isSecure(): bool {return $this->secure;}
        public function getClientIp(): string {return $this->peer;}
    }
}
namespace GlpiPlugin\Gwselfservice {
    final class Store
    {
        public static array $settings = ['trusted_proxy_cidrs' => ''];
        public static function config(): array { return self::$settings; }
    }
}
namespace {
    use Symfony\Component\HttpFoundation\Request;
    use GlpiPlugin\Gwselfservice\Transport;
    use GlpiPlugin\Gwselfservice\Store;
    require __DIR__ . '/../src/Transport.php';
    $GLOBALS['DB'] = new \stdClass();
    putenv('GWSS_TRUSTED_PROXY_CIDRS');
    function expect(bool $truth, string $case): void { if (!$truth) throw new \RuntimeException('FAIL: ' . $case); }
    $proxy = new Request('10.0.2.147', 'https');
    expect(!Transport::isSecure($proxy), 'sem configuração bloqueia o proxy');
    expect(Transport::canTrustCurrentProxy($proxy), 'a interface pode propor IP privado com TLS forwarded');
    expect(Transport::isSafeGuiProxyCidr('10.0.2.147'), 'IP único privado');
    expect(Transport::isSafeGuiProxyCidr('10.0.2.0/24'), 'rede Docker privada /24');
    foreach (['0.0.0.0/0','10.0.0.0/8','10.0.0.0/16','1.2.3.4/32','172.10.2.0/24','::/0','2001:db8::/64'] as $bad) {
        expect(!Transport::isSafeGuiProxyCidr($bad), 'bloquear faixa não segura ' . $bad);
    }
    expect(!Transport::canTrustCurrentProxy(new Request('10.0.2.147','http')), 'sem TLS externo não permite cadastrar');
    expect(!Transport::canTrustCurrentProxy(new Request('203.0.113.2','https')), 'IP externo não pode cadastrar');
    Store::$settings['trusted_proxy_cidrs'] = '10.0.2.147';
    expect(Transport::isSecure($proxy), 'autorização persistida no banco, sem restart');
    Store::$settings['trusted_proxy_cidrs'] = '10.0.2.0/24';
    expect(Transport::isSecure($proxy), 'range privado persistido no banco');
    expect(!Transport::isSecure(new Request('10.0.3.147','https')), 'não confiar em outra subnet');
    putenv('GWSS_TRUSTED_PROXY_CIDRS=192.168.2.5');
    expect(Transport::isSecure(new Request('192.168.2.5','https')), 'variável do Portainer continua compatível');
    echo "OK: Traefik GUI, DB persistente, sem reinício, sem CIDR aberto, ambiente Portainer\n";
}
