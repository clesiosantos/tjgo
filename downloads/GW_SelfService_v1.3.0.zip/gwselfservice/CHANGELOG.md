# GW Self-Service — Histórico

## 1.3.0 — POC sem bloqueio por proxy (17/11/2026)

- Remove toda a exigência de `trusted_proxy_cidrs` e `GWSS_TRUSTED_PROXY_CIDRS` no fluxo do plugin.
- Remove a verificação de HTTP/HTTPS como condição para acessar Configuração, Auditoria, Cadastro MFA e Recuperação.
- Permite operação com Traefik / Docker Compose / Portainer independentemente do IP do contêiner e de `X-Forwarded-Proto`.
- O caminho `/Transport` permanece somente informativo, sem formulário de aprovação do proxy.
- **Mantém** MFA nativo obrigatório, vínculo LDAP/GLPI, bloqueio de repetição de MFA, limites de tentativas, LDAPS certificado, OU delimitada e modo explícito de teste.
- Preserva banco e configuração do AD no upgrade, sem desinstalação. O campo legado `trusted_proxy_cidrs` fica sem efeito.

**Aviso:** remoção de gate HTTPS destina-se somente a ambiente isolado de POC. Configure TLS na borda do Traefik e não exponha a porta HTTP do GLPI. Código TOTP, credenciais de serviço e senha temporária não podem trafegar em HTTP acessível a terceiros.
