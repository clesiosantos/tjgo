# GW Self-Service 1.3.0 — POC TJ-GO

Plugin para GLPI 11, com autosserviço e integração com Active Directory local `poc.local`.

## Uso em Docker Compose + Portainer + Traefik

- **Sem trusted proxy no plugin.** Nenhum IP de contêiner, CIDR ou cabeçalho `X-Forwarded-*` precisa ser autorizado no GW Self-Service.
- O GLPI continua gerenciando sessões e autenticação. Use URL HTTPS externa do Traefik. A detecção de HTTPS no aplicativo é apenas informativa e **não bloqueia telas nem operações**.
- Mantenha TLS no Traefik e bloqueie acesso HTTP direto ao backend. A aplicação não tem como garantir confidencialidade se a rede entregar páginas de credenciais em HTTP.
- Não precisa de SSH para configurar o plugin após instalá-lo.

## Telas

- `/plugins/gwselfservice/Settings` — AD, conta de serviço, OU de teste, modo, grupo e artigo KB.
- `/plugins/gwselfservice/Recovery` — página pública, exige conta GLPI-LDAP importada e MFA nativo previamente habilitado.
- `/plugins/gwselfservice/Enrollment` — estado do MFA nativo (sessão autenticada).
- `/plugins/gwselfservice/Audits` — trilha de auditoria (admin).
- `/plugins/gwselfservice/Transport` — diagnóstico informativo, sem formulário de trust proxy (admin).

## Fluxo POP 086

1. Usuário cadastra MFA **nativo do GLPI 11** enquanto ainda conhece a senha.
2. Na página pública, informa login e código TOTP.
3. Plugin verifica no LDAPS a conta na OU de testes, vincula o usuário importado no GLPI pelo DN e valida o MFA.
4. Abre chamado categoria ITIL **954**, grupo N1 (padrão ID **12**), entidade raiz **0**, com o solicitante validado como requerente.
5. Vincula o artigo POP 086 por ID, cria acompanhamento e tarefa de alteração de senha ou desbloqueio.
6. Em `simulation`, registra a conclusão simulada no GLPI, sem alterar o AD.
7. Em `test_ad`, executa reset de senha via LDAPS ou desbloqueio dentro da OU autorizada; reset marca `pwdLastSet=0` para exigir troca no próximo login.
8. Cria solução, encerra o chamado quando todas as etapas completam, registra auditoria. A nova senha é exibida uma vez, sem gravá-la no chamado ou no log.

## Instalação

Faça backup e **substitua** a pasta `plugins/gwselfservice`. Use **Atualizar**, nunca **Desinstalar**, para preservar as tabelas, configurações LDAPS e histórico. A configuração antiga `trusted_proxy_cidrs` fica no banco por compatibilidade, mas não tem efeito.

## Escopo e segurança da POC

Esta edição remove unicamente **bloqueios dependentes de HTTPS e confiança em proxy**. Não elimina MFA, limitações de OU, validação LDAPS, limites de tentativas, anti-replay, permissões de administrador e auditoria. A operação real exige habilitação explícita no painel, com conta de serviço delegada somente na OU de laboratório.

**Risco aceito para laboratório isolado:** o PHP não verifica se o navegador chegou por HTTPS. Garanta HTTPS na borda e mantenha o contêiner inacessível diretamente. Nunca use esta edição como solução de produção sem revisão de segurança e testes completos no ambiente real.
