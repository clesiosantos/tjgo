# Segurança — edição POC 1.3.0

- O plugin **não bloqueia** acessos segundo o esquema HTTP / HTTPS e **não exige** lista de proxies confiáveis. A decisão é da infraestrutura Traefik/GLPI.
- O proxy reverso deve publicar HTTPS, e a porta HTTP interna não deve estar acessível aos usuários. Se o tráfego for realmente HTTP na rede de acesso, credenciais de serviço em formulários, OTP e senhas temporárias podem ser interceptados.
- O reset real **continua protegido** por MFA nativo do GLPI 11, usuário vinculado ao DN LDAP, consulta LDAPS com validação de certificado, limitação de tentativas, prevenção de reutilização do TOTP, modo real habilitado, OU específica, conta delegada e auditoria.
- Os detalhes do TOTP e a nova senha não são persistidos no GLPI.
- O modo `simulation` cria registros no GLPI sem alterar o AD. O modo `test_ad` só deve ser usado com contas e OUs fictícias.
- Use HTTPS externo para homologação da recuperação real; o plugin não faz essa verificação, então a equipe deve verificar a URL no navegador.
- Validações locais não substituem teste integrado na instalação real.
