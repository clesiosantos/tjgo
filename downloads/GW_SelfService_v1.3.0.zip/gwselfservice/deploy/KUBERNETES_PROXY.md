# Kubernetes / Ingress — mesma edição POC

O GW Self-Service 1.3.0 não verifica trusted proxies nem exige uma variável de ambiente no Kubernetes. O GLPI e o ingress devem atender corretamente às URLs, sessões, acesso HTTPS e encaminhamento de tráfego, conforme a infraestrutura da plataforma.

O autosserviço segue exigindo MFA GLPI nativo, vinculação LDAP, OU de testes e LDAPS para alterações reais. O diagnóstico `Transport` é informativo e não serve como autorização para executar o reset.

Em produção, revise o risco de o plugin deixar de exigir HTTPS na aplicação.
