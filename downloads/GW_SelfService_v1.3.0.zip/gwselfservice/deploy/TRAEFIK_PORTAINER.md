# Docker Compose + Traefik + Portainer — POC

**Sem configuração de trust proxy no GW Self-Service 1.3.0.** Não adicione `GWSS_TRUSTED_PROXY_CIDRS`. O IP que chega ao pod/contêiner pode variar; isso não bloqueia o plugin.

O Traefik deve: publicar o GLPI via HTTPS 443, encaminhar a requisição ao contêiner pela rede privada Docker, e impedir o acesso direto à porta HTTP do GLPI. Use o mesmo domínio/base de URL que o GLPI já utiliza. Sessões e CSRF devem funcionar no GLPI normalmente.

O plugin não escolhe confiabilidade a partir dos cabeçalhos `X-Forwarded-*`: essa lógica foi removida. Se o GLPI mostra a interface corretamente e a sessão administrativa permanece válida, as telas do GW Self-Service estarão acessíveis.

Teste: `Settings` (salvar AD), `Transport` (diagnóstico informativo), `Enrollment` (conta autenticada com MFA nativo), `Recovery` (login e TOTP). Para reset real, configure LDAPS 636 e OU exclusiva de laboratório.

**Alerta:** Não usar HTTP no navegador para trocar senhas reais. Retirada do bloqueio do aplicativo não torna o HTTP seguro.
