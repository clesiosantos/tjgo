<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\Directory;
use GlpiPlugin\Gwselfservice\Store;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class AdminController extends AbstractController
{
    #[Route('/Settings', name: 'gwselfservice_settings', methods: ['GET', 'POST'])]
    public function settings(Request $request): Response
    {
        $guard = self::guard();
        if ($guard) {
            return $guard;
        }
        $c = Store::config();
        $message = '';
        $ok = false;
        if ($request->isMethod('POST')) {
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada. Atualize a página.';
            } else {
                $action = (string)$request->request->get('action', 'save');
                if ($action === 'test') {
                    try {
                        $conn = Directory::connect($c);
                        $base = (string)($c['allowed_ou'] ?: $c['base_dn']);
                        $search = @ldap_read($conn, $base, '(objectClass=*)', ['dn'], 0, 1, 8);
                        if ($search === false) {
                            throw new \RuntimeException('Busca LDAP falhou.');
                        }
                        $ok = true;
                        $message = 'Conexão LDAPS, autenticação da conta de serviço e leitura do DN confirmadas.';
                        Store::audit('', (int)\Session::getLoginUserID(), 'config_test', 'success');
                    } catch (\Throwable $e) {
                        $message = 'Teste LDAPS falhou: valide hostname/certificado CA, conta de serviço, permissões, porta 636 e conectividade.';
                        Store::audit('', (int)\Session::getLoginUserID(), 'config_test', 'error');
                    }
                } elseif ($action === 'save') {
                    try {
                        $mode = (string)$request->request->get('mode', 'simulation');
                        $ou = trim((string)$request->request->get('allowed_ou', ''));
                        $base = trim((string)$request->request->get('base_dn', ''));
                        if (!in_array($mode, ['simulation', 'test_ad'], true)) {
                            throw new \RuntimeException('Modo de execução não reconhecido.');
                        }
                        if ($mode === 'test_ad' && !$request->request->has('test_ad_confirm')) {
                            throw new \RuntimeException('Confirme explicitamente a autorização de escritas na OU de testes.');
                        }
                        if (!Directory::withinDn($ou, $base) || $base === '') {
                            throw new \RuntimeException('A OU autorizada deve estar dentro do DN base do domínio.');
                        }
                        $host = trim((string)$request->request->get('host', ''));
                        $domain = trim((string)$request->request->get('domain', ''));
                        $port = (int)$request->request->get('port', 636);
                        if (!preg_match('/^[A-Za-z0-9_.-]{1,253}$/D', $host) || !preg_match('/^[A-Za-z0-9.-]{1,253}$/D', $domain) || $port < 1 || $port > 65535) {
                            throw new \RuntimeException('Host, domínio ou porta inválido.');
                        }
                        $data = [
                            'host' => $host,
                            'port' => $port,
                            'domain' => $domain,
                            'base_dn' => $base,
                            'allowed_ou' => $ou,
                            'bind_dn' => trim((string)$request->request->get('bind_dn', '')),
                            'ca_file' => trim((string)$request->request->get('ca_file', '')),
                            'mode' => $mode,
                            'enabled' => $request->request->has('enabled') ? 1 : 0,
                            'reset_enabled' => $request->request->has('reset_enabled') ? 1 : 0,
                            'unlock_enabled' => $request->request->has('unlock_enabled') ? 1 : 0,
                            'pwd_change_next' => 1, // Obrigatório para todas as redefinições reais
                            'notify_enabled' => 0, // Edição de teste não envia e-mail real
                            'mail_from' => trim((string)$request->request->get('mail_from', '')),
                            'entity_id' => (int)$request->request->get('entity_id', 0),
                            'group_id' => (int)$request->request->get('group_id', 12),
                            'kb_article_id' => (int)$request->request->get('kb_article_id', 0),
                        ];
                        if ($data['entity_id'] !== 0 || $data['group_id'] < 1 || $data['kb_article_id'] < 0) {
                            throw new \RuntimeException('Configuração ITSM inválida: entidade 0, grupo N1 e artigo KB válido.');
                        }
                        if ($mode === 'test_ad' && ($data['kb_article_id'] < 1 || $ou === '' || strcasecmp($ou, $base) === 0)) {
                            throw new \RuntimeException('Modo AD de testes exige OU específica e ID de artigo da base.');
                        }
                        $secret = (string)$request->request->get('bind_secret', '');
                        if ($secret !== '') {
                            $data['bind_secret'] = Store::encrypt($secret);
                        }
                        Store::saveConfig($data);
                        $c = Store::config();
                        $ok = true;
                        $message = 'Configurações salvas. Utilize Testar conexão antes da homologação.';
                        Store::audit('', (int)\Session::getLoginUserID(), 'config', 'saved', 'Modo ' . $mode);
                    } catch (\Throwable $e) {
                        $message = $e->getMessage();
                        Store::audit('', (int)\Session::getLoginUserID(), 'config', 'denied');
                    }
                }
            }
        }
        $body = '<div class="test-banner"><strong>AMBIENTE DE TESTE — POC</strong><p>Sem checagem de proxy/HTTPS no plugin. Simulação por padrão; alterações reais exigem MFA, LDAPS verificado, OU exclusiva e habilitação explícita. Configure HTTPS externo no Traefik.</p></div>';
        if ($message) {
            $body .= Ui::alert($message, $ok);
        }
        $body .= '<section class="panel"><h2>Servidor do Active Directory</h2><form method="post">' . Ui::formToken() . '<input type="hidden" name="action" value="save">'
            . '<div class="two">'
            . Ui::input('host', 'Host do controlador AD (FQDN recomendado)', (string)($c['host'] ?? '172.19.35.22'), 'text', 'O nome precisa coincidir com o certificado LDAPS.', true)
            . Ui::input('port', 'Porta LDAPS', (string)($c['port'] ?? 636), 'number', 'TLS obrigatório; não suporta LDAP sem TLS.', true)
            . Ui::input('domain', 'Domínio', (string)($c['domain'] ?? 'poc.local'), 'text', '', true)
            . Ui::input('base_dn', 'DN base', (string)($c['base_dn'] ?? 'DC=poc,DC=local'), 'text', '', true)
            . '</div>'
            . Ui::input('allowed_ou', 'OU autorizada (obrigatória, especialmente no modo real)', (string)($c['allowed_ou'] ?? ''), 'text', 'Ex.: OU=POC-Usuarios,DC=poc,DC=local', true)
            . Ui::input('bind_dn', 'Conta de serviço do AD (UPN ou DN)', (string)($c['bind_dn'] ?? ''), 'text', 'Conta sem permissões de administrador do domínio.', true)
            . Ui::input('bind_secret', 'Senha da conta de serviço', '', 'password', 'Deixe em branco para preservar a senha criptografada anteriormente.')
            . Ui::input('ca_file', 'Caminho do certificado CA (opcional)', (string)($c['ca_file'] ?? ''), 'text', 'Arquivo PEM acessível pelo PHP; caso vazio, usar CAs confiáveis do sistema.')
            . '<section class="note"><h3>Vinculação com GLPI — POP 086</h3><p>Categoria 954 (Reset de senha de acesso); grupo de atendimento N1; requerente será o usuário LDAP/MFA validado. A categoria da base de conhecimento não é um artigo: escolha o ID do artigo POP 086 na base.</p></section>'
            . '<div class="two">'
            . Ui::input('entity_id', 'Entidade GLPI (raiz TJ-GO)', (string)($c['entity_id'] ?? 0), 'number', 'Na POC: 0', true)
            . Ui::input('group_id', 'Grupo solucionador N1 (ID)', (string)($c['group_id'] ?? 12), 'number', 'Categoria da captura: POC TJGO - Solucionadores N1 (ID 12)', true)
            . Ui::input('kb_article_id', 'Artigo da base (ID, obrigatório)', (string)($c['kb_article_id'] ?? 0), 'number', 'ID de artigo de conhecimento POP 086, não ID de categoria', true)
            . '</div>'
            . '<label class="field"><span>Modo</span><select name="mode"><option value="simulation"' . (($c['mode'] ?? 'simulation') === 'simulation' ? ' selected' : '') . '>Simulação com registros GLPI (sem alteração no AD)</option><option value="test_ad"' . (($c['mode'] ?? '') === 'test_ad' ? ' selected' : '') . '>AD TESTE REAL (executa reset/desbloqueio apenas na OU configurada)</option></select></label>'
            . self::checkbox('test_ad_confirm', 'Confirmo que o controlador e OU são de laboratório e autorizo alterações reais somente neste escopo', 0)
            . self::checkbox('enabled', 'Habilitar autosserviço', (int)($c['enabled'] ?? 0))
            . self::checkbox('reset_enabled', 'Permitir redefinir senha', (int)($c['reset_enabled'] ?? 1))
            . self::checkbox('unlock_enabled', 'Permitir desbloquear conta', (int)($c['unlock_enabled'] ?? 1))
            . '<p class="info">A troca da senha no próximo login (pwdLastSet=0) é obrigatória e não pode ser desativada. HTTPS deve ser fornecido pelo Traefik; o plugin não configura nem valida trusted proxies.</p>'
            . '<div class="actions"><button type="submit">Salvar configurações</button></div></form>'
            . '<form method="post">' . Ui::formToken() . '<input type="hidden" name="action" value="test"><button type="submit" class="secondary">Testar conexão salva</button></form></section>'
            . '<section class="note"><strong>Links para o TJ-GO:</strong><p>MFA nativo: <a href="' . Ui::h(Ui::url('Enrollment')) . '">' . Ui::h(Ui::url('Enrollment')) . '</a></p><p>Esqueci minha senha (público): <a href="' . Ui::h(Ui::url('Recovery')) . '">' . Ui::h(Ui::url('Recovery')) . '</a></p></section>';
        return Ui::page('Configuração do Active Directory', $body);
    }

    #[Route('/Audits', name: 'gwselfservice_audits', methods: ['GET', 'POST'])]
    public function audits(Request $request): Response
    {
        $guard = self::guard();
        if ($guard) {
            return $guard;
        }
        $message = '';
        if ($request->isMethod('POST')) {
            if (!Ui::checkCsrf((string)$request->request->get('gwss_csrf', ''))) {
                $message = 'Sessão expirada.';
            } else {
                $id = (int)$request->request->get('factor_id', 0);
                $confirm = (string)$request->request->get('confirm', '');
                $factor = $id > 0 ? Store::first('glpi_plugin_gwselfservice_factors', ['id' => $id]) : null;
                if (!$factor || $confirm !== 'REVOGAR') {
                    $message = 'Fator não encontrado ou confirmação inválida.';
                } else {
                    Store::resetFactor($id);
                    Store::audit((string)$factor['login'], (int)$factor['users_id'], 'factor_revoke', 'success', 'Revogado por administrador ID ' . \Session::getLoginUserID());
                    $message = 'Autenticador revogado. O fator legado foi revogado; MFA nativo GLPI não foi alterado.';
                }
            }
        }
        global $DB;
        $rows = '';
        foreach ($DB->request(['FROM' => 'glpi_plugin_gwselfservice_audits', 'ORDER' => ['id DESC'], 'LIMIT' => 100]) as $r) {
            $rows .= '<tr><td>' . Ui::h((string)$r['created_at']) . '</td><td>' . Ui::h((string)$r['login']) . '</td><td>' . Ui::h((string)$r['operation']) . '</td><td>' . Ui::h((string)$r['result']) . '</td><td>' . (int)($r['tickets_id'] ?? 0) . '</td><td>' . Ui::h((string)$r['ip']) . '</td></tr>';
        }
        $factors = '';
        foreach ($DB->request(['FROM' => 'glpi_plugin_gwselfservice_factors', 'ORDER' => ['id DESC'], 'LIMIT' => 200]) as $r) {
            $factors .= '<tr><td>' . (int)$r['id'] . '</td><td>' . Ui::h((string)$r['login']) . '</td><td>' . ((int)$r['enabled'] ? 'Ativo' : 'Revogado') . '</td><td>' . Ui::h((string)$r['updated_at']) . '</td></tr>';
        }
        $body = ($message !== '' ? Ui::alert($message) : '')
            . '<section class="panel"><h2>Últimas 100 operações (com número do chamado)</h2><div class="table"><table><thead><tr><th>Data</th><th>Login</th><th>Ação</th><th>Resultado</th><th>Chamado</th><th>IP</th></tr></thead><tbody>' . $rows . '</tbody></table></div></section>'
            . '<section class="panel"><h2>Fatores legados da versão anterior</h2><div class="table"><table><thead><tr><th>ID</th><th>Login</th><th>Situação</th><th>Atualização</th></tr></thead><tbody>' . $factors . '</tbody></table></div>'
            . '<form method="post">' . Ui::formToken()
            . Ui::input('factor_id', 'ID do fator a revogar', '', 'number', '', true)
            . Ui::input('confirm', 'Confirme com REVOGAR', '', 'text', 'Não fornece reset de senha nem permite assumir a identidade do usuário.', true)
            . '<button class="danger" type="submit">Revogar fator</button></form></section>';
        return Ui::page('Auditoria e cadastro de autenticadores', $body);
    }

    private static function guard(): ?Response
    {
        return \Session::haveRight('config', UPDATE)
            ? null
            : Ui::page('Acesso restrito', Ui::alert('Apenas administradores com permissão de configuração podem acessar esta página.'), false, 403);
    }

    private static function checkbox(string $name, string $label, int $enabled): string
    {
        return '<label class="checkbox"><input type="checkbox" name="' . Ui::h($name) . '" value="1" ' . ($enabled ? 'checked' : '') . '> ' . Ui::h($label) . '</label>';
    }
}
