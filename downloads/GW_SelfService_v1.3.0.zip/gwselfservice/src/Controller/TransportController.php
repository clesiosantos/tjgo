<?php
namespace GlpiPlugin\Gwselfservice\Controller;

use Glpi\Controller\AbstractController;
use GlpiPlugin\Gwselfservice\Transport;
use GlpiPlugin\Gwselfservice\Ui;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

/** Read-only environment information, without trusted-proxy setup or access blocks. */
final class TransportController extends AbstractController
{
    #[Route('/Transport', name: 'gwselfservice_transport', methods: ['GET'])]
    public function __invoke(Request $request): Response
    {
        if (!\Session::haveRight('config', UPDATE)) {
            return Ui::page('Acesso restrito', Ui::alert('Apenas administradores podem visualizar o diagnóstico.'), false, 403);
        }
        $d = Transport::diagnostic($request);
        $rows = [
            'GLPI/Symfony indica HTTPS' => $d['glpi_https'] ? 'Sim' : 'Não',
            'Esquema informado pelo Traefik (apenas informativo)' => $d['reported_scheme'],
            'IP de conexão ao contêiner' => $d['peer'],
            'IP usado para o controle de tentativas' => $d['audit_ip'],
            'Dependência de proxy de confiança no plugin' => 'NENHUMA',
            'Bloqueio do plugin por HTTP ou cabeçalhos de proxy' => 'NENHUM',
        ];
        $table = '';
        foreach ($rows as $key => $value) {
            $table .= '<tr><th>' . Ui::h($key) . '</th><td>' . Ui::h((string)$value) . '</td></tr>';
        }
        $body = '<div class="test-banner"><strong>POC TJ-GO · Docker Compose + Traefik + Portainer</strong>'
            . '<p>Não é necessário cadastrar CIDR, configurar trusted proxy, variável de ambiente ou alterar o código do GLPI para liberar este plugin.</p></div>'
            . '<section class="panel"><h2>Ambiente de execução (informativo)</h2><div class="table"><table><tbody>' . $table . '</tbody></table></div></section>'
            . '<section class="note"><strong>Atenção:</strong> a remoção da verificação de HTTPS é exclusiva desta edição de POC. '
            . 'O protocolo apresentado acima não comprova a segurança da conexão. Publique o portal por HTTPS no Traefik, '
            . 'restrinja o acesso HTTP direto ao contêiner e mantenha LDAPS certificado para o AD. '
            . 'MFA nativo, vínculo LDAP, limite de tentativas, OU de testes e auditoria continuam obrigatórios.</section>';
        return Ui::page('Ambiente de teste — sem bloqueio de proxy', $body);
    }
}
