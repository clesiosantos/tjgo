<?php
namespace GlpiPlugin\Gwselfservice;

/** POC: no reverse-proxy/HTTP gate. Real AD writes still require explicit mode, LDAPS and scoped test OU. */
final class TestPolicy
{
    public static function mayWriteToAd(?array $config = null, string $dn = ''): bool
    {
        $c = $config ?? Store::config();
        $allowed = trim((string)($c['allowed_ou'] ?? ''));
        $base = trim((string)($c['base_dn'] ?? ''));
        return (string)($c['mode'] ?? '') === 'test_ad'
            && (int)($c['enabled'] ?? 0) === 1
            && (int)($c['port'] ?? 0) === 636
            && $allowed !== '' && $base !== ''
            && strcasecmp($allowed, $base) !== 0
            && Directory::withinDn($allowed, $base)
            && $dn !== '' && Directory::withinDn($dn, $allowed);
    }
}
