<?php
namespace GlpiPlugin\Gwselfservice;

use Symfony\Component\HttpFoundation\Request;

/**
 * POC edition: the plugin does not decide whether a request passed through
 * Traefik, NGINX, Kubernetes Ingress, or an intermediate TLS terminator.
 * This information is informational only; never an authorization condition.
 * Client IP is taken from Symfony's trusted proxy configuration (if any),
 * otherwise from the immediate peer. Spoofed X-Forwarded-* is not parsed.
 */
final class Transport
{
    public static function clientIp(Request $request): string
    {
        $candidate = (string)($request->getClientIp() ?? '');
        if (filter_var($candidate, FILTER_VALIDATE_IP) !== false) {
            return $candidate;
        }
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        return filter_var($peer, FILTER_VALIDATE_IP) !== false ? $peer : '';
    }

    public static function clientIpFromGlobals(): string
    {
        // Used by the audit store before a Symfony Request is available.
        // Never consume client-controlled forwarded headers directly.
        $peer = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        return filter_var($peer, FILTER_VALIDATE_IP) !== false ? $peer : '';
    }

    /** Read-only details. Nothing in this diagnostic is used to block the POC. */
    public static function diagnostic(Request $request): array
    {
        $peer = (string)$request->server->get('REMOTE_ADDR', '');
        return [
            'glpi_https' => $request->isSecure(),
            'reported_scheme' => (string)$request->headers->get('X-Forwarded-Proto', 'não informado'),
            'peer' => filter_var($peer, FILTER_VALIDATE_IP) !== false ? $peer : 'desconhecido',
            'audit_ip' => self::clientIp($request),
        ];
    }
}
