<?php
namespace Symfony\Component\HttpFoundation {
    class MockParamBag { function __construct(private array $items) {} function get($k,$d='') {return $this->items[$k] ?? $d;} }
    class Request {
        public MockParamBag $server;
        public MockParamBag $headers;
        function __construct($server,$headers) { $this->server=new MockParamBag($server); $this->headers=new MockParamBag($headers); }
        function getClientIp(){return $this->server->get('REMOTE_ADDR');}
        function isSecure(){return false;}
    }
}
namespace {
    require_once __DIR__ . '/../src/Transport.php';
    $r = new \Symfony\Component\HttpFoundation\Request(['REMOTE_ADDR'=>'10.0.2.147'],['X-Forwarded-Proto'=>'https']);
    $info = \GlpiPlugin\Gwselfservice\Transport::diagnostic($r);
    assert($info['glpi_https'] === false);
    assert($info['reported_scheme'] === 'https');
    assert(\GlpiPlugin\Gwselfservice\Transport::clientIp($r) === '10.0.2.147');
    assert(!method_exists(\GlpiPlugin\Gwselfservice\Transport::class, 'trustedProxies'));
    echo 'OK: diagnostics informational; no trusted proxy configuration' . "\n";
}
