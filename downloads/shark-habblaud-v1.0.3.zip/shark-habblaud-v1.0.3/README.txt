SHARK INNOVATION OFFICE — Habblaud v1.0.3
=======================================
Este pacote altera apenas o cliente da copia local /opt/ai-stack/habblaud-src.
Nao altera autenticacao Codex, banco Paperclip, nem os bind mounts de sessao.

Instalacao:
  cd /opt/ai-stack
  unzip shark-habblaud-v1.0.3.zip -d /opt/ai-stack
  bash /opt/ai-stack/shark-habblaud-v1.0.3/deploy.sh

Verificacao:
  docker service ps ai_habblaud --no-trunc
  docker service logs ai_habblaud --tail 50
  docker service inspect ai_habblaud --format '{{.Spec.TaskTemplate.ContainerSpec.Image}}'
  curl -IL https://office.inovacao.sharksolucoes.com.br

Rollback:
  cp /opt/ai-stack/backups/shark-office-AAAAmmdd-HHMMSS/stack.yml /opt/ai-stack/stack.yml
  cd /opt/ai-stack
  set -a; source .env; set +a
  docker stack config -c stack.yml >/dev/null && docker stack deploy -c stack.yml ai
  # Nao remova a imagem antiga; volume /data e diretorios Codex permanecem intactos.

Atenção: departamentos FIXOS sao um painel de departamentos persistente no frontend.
Salas 2D dentro do predio continuam dinamicas, uma por projeto/sessao. A contagem do
painel representa somente agentes presentes em salas ativas. O nome Alexander Morgan
nao e automaticamente aplicado a sessoes manuais: exige correspondencia com o
agente real do Paperclip e seu workspace. Nao e integrado via API de Paperclip.

Seguranca:
  mantenha HTTP Basic Auth no Traefik; nao monte auth.json no Habblaud.
  Nao remova a restricao de terminal remoto.
  Build exige conectividade da VPS para obter deps npm / imagem node se ainda nao em cache.

Requisitos: repositorio Habblaud v1.0.3, docker swarm, python3, bash.
