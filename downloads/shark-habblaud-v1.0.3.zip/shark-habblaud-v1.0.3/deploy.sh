#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/opt/ai-stack
SRC="$ROOT/habblaud-src"
PACK="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
test -f "$SRC/package.json" || { echo 'ERRO: codigo-fonte nao encontrado'; exit 1; }
TS=$(date +%Y%m%d-%H%M%S)
mkdir -p "$ROOT/backups/shark-office-$TS"
BACKUP="$ROOT/backups/shark-office-$TS"
cp -a stack.yml "$BACKUP/stack.yml"
cp -a "$SRC/client/src/ui/index.ts" "$SRC/client/src/ui/topbar.ts" "$SRC/Dockerfile" "$BACKUP/"
cp -a "$SRC/client/src/ui/shark-office.ts" "$BACKUP/shark-office.ts" 2>/dev/null || true
cp -a "$SRC/client/src/ui/shark-office.css" "$BACKUP/shark-office.css" 2>/dev/null || true
python3 "$PACK/install_patch.py" "$SRC"
IMAGE='habblaud:shark-1.0.3-v1'
echo '== Construindo imagem versionada =='
docker build --tag "$IMAGE" "$SRC"
echo '== Verificando imagem =='
docker image inspect "$IMAGE" >/dev/null
# Alteracao de imagem somente, preservando redes, volumes, secrets, labels e env.
python3 - "$ROOT/stack.yml" <<'PY'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); y=p.read_text();
assert re.search(r'^  habblaud:\s*$',y,re.M), 'Servico habblaud ausente ou mal indentado'
pat=r'(?m)^(  habblaud:\s*\n(?:.*\n)*?    image: )[^\n]+'
m=re.search(pat,y)
assert m, 'Imagem do Habblaud nao encontrada; stack preservado'
y=y[:m.start()]+m.group(1)+'habblaud:shark-1.0.3-v1'+y[m.end():]
p.write_text(y)
PY
set -a
# shellcheck disable=SC1091
source "$ROOT/.env"
set +a
docker stack config -c "$ROOT/stack.yml" >/dev/null
echo '== Fazendo deploy somente do Habblaud =='
docker stack deploy -c "$ROOT/stack.yml" ai
echo "Backup: $BACKUP"
echo 'Confira: docker service ps ai_habblaud --no-trunc'
echo 'Se falhar, restaure o stack.yml a partir do backup e execute docker stack deploy novamente.'
