#!/usr/bin/env python3
"""Idempotent patch for the *existing* marmottajr/habblaud v1.0.3 source checkout."""
import pathlib, shutil, sys
root=pathlib.Path(sys.argv[1]).resolve()
package=root/'package.json'
if not package.exists() or '"version": "1.0.3"' not in package.read_text():
    raise SystemExit('ERRO: confira se o diretorio contem Habblaud 1.0.3; nenhuma mudanca aplicada')
ui=root/'client/src/ui'
source=pathlib.Path(__file__).resolve().parent/'overlay'
for name in ['shark-office.ts','shark-office.css']:
    shutil.copy2(source/name,ui/name)
index=ui/'index.ts'; text=index.read_text()
anchor="import './styles.css';"
assert anchor in text, 'Import CSS da UI nao encontrado'
if "import './shark-office.css';" not in text:
    text=text.replace(anchor,anchor+"\nimport './shark-office.css';\nimport { mountSharkOffice } from './shark-office';")
anchor='  area = new FreeArea(world,'
assert anchor in text, 'Ponto de montagem UI nao encontrado'
if 'mountSharkOffice(root, store' not in text:
    text=text.replace(anchor,"  mountSharkOffice(root, store, (roomId) => ctx.select({ type: 'room', id: roomId }, { focus: true }));\n"+anchor)
index.write_text(text)
bar=ui/'topbar.ts'; text=bar.read_text()
anchor="    mark.append(logo);"
if anchor in text:
    text=text.replace(anchor,"    mark.append(h('span', { text: 'S' }));")
elif "mark.append(h('span', { text: 'S' }));" not in text:
    raise SystemExit('Marca nao encontrada')
anchor='wordmark(), this.status'
if anchor in text:
    text=text.replace(anchor,"h('div', { class: 'shark-wordmark' }, h('span', { text: 'SHARK SOLUÇÕES' }), h('small', { text: 'INNOVATION OFFICE' })), this.status")
elif "class: 'shark-wordmark'" not in text:
    raise SystemExit('Wordmark nao encontrado')
text=text.replace("import { wordmark } from './widgets';\n", '')
bar.write_text(text)
# Correcao de permissao para runtime Node non-root, sem executar o Habblaud como root.
dockerfile=root/'Dockerfile'
docker_text=dockerfile.read_text()
if 'RUN chmod -R a+rX /app' not in docker_text:
    assert 'USER node' in docker_text, 'USER node nao encontrado no Dockerfile'
    docker_text=docker_text.replace('USER node', 'RUN chmod -R a+rX /app\nUSER node')
    dockerfile.write_text(docker_text)
print('OK: logo textual, CSS corporativo e departamentos fixos adicionados. Nenhum arquivo do servidor foi alterado.')
