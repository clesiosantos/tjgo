import type { OfficeStore } from '../net/store';

interface Department {
  name: string;
  short: string;
  match: RegExp;
  description: string;
}

const DEPARTMENTS: Department[] = [
  { name: 'Diretoria Executiva', short: 'CEO', match: /(alexander|diretoria|executiv|ceo|strategy)/i, description: 'Alexander Morgan • Estratégia' },
  { name: 'Inovação e Produtos', short: 'P&D', match: /(inovacao|innovation|produto|product|research|pesquisa|mvp)/i, description: 'Pesquisa • Novos produtos' },
  { name: 'Marketing e Growth', short: 'MKT', match: /(marketing|growth|seo|conteudo|campaign|campanha)/i, description: 'Marca • Conteúdo • Demanda' },
  { name: 'Tecnologia e Web', short: 'TECH', match: /(shark-dev|tecnologia|technology|tech|dev|web|site|frontend)/i, description: 'Site • Engenharia • Automação' },
];

/** Camada visual fixa; não cria sessões artificiais nem altera o modelo do servidor. */
export function mountSharkOffice(root: HTMLElement, store: OfficeStore, focus: (roomId: string) => void): void {
  const panel = document.createElement('aside');
  panel.className = 'shark-departments';
  panel.setAttribute('aria-label', 'Departamentos Shark Soluções');
  const heading = document.createElement('div');
  heading.className = 'shark-departments__heading';
  const caption = document.createElement('strong');
  caption.textContent = 'SHARK INNOVATION OFFICE';
  const hint = document.createElement('span');
  hint.textContent = 'UNIDADES DE NEGÓCIO';
  heading.append(caption, hint);
  panel.append(heading);

  const entries = DEPARTMENTS.map((dep) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'shark-department';
    const code = document.createElement('span');
    code.className = 'shark-department__code';
    code.textContent = dep.short;
    const middle = document.createElement('span');
    middle.className = 'shark-department__text';
    const name = document.createElement('strong');
    name.textContent = dep.name;
    const description = document.createElement('small');
    description.textContent = dep.description;
    middle.append(name, description);
    const count = document.createElement('span');
    count.className = 'shark-department__count';
    count.textContent = '0';
    btn.append(code, middle, count);
    panel.append(btn);
    return { dep, btn, count };
  });

  const footer = document.createElement('p');
  footer.className = 'shark-departments__foot';
  footer.textContent = 'Departamentos permanentes · salas ativadas por sessões Codex';
  panel.append(footer);
  root.append(panel);

  const update = (): void => {
    const rooms = store.snapshot?.rooms ?? [];
    const agents = store.snapshot?.agents ?? [];
    for (const { dep, btn, count } of entries) {
      const matches = rooms.filter((room) => dep.match.test(`${room.path} ${room.name}`));
      const ids = new Set(matches.map((room) => room.id));
      const total = agents.filter((agent) => ids.has(agent.roomId) && agent.kind === 'main').length;
      const active = agents.filter((agent) => ids.has(agent.roomId) && agent.status === 'working').length;
      count.textContent = String(total);
      btn.classList.toggle('is-active', active > 0);
      btn.classList.toggle('has-room', matches.length > 0);
      btn.disabled = matches.length === 0;
      btn.title = matches.length ? `Abrir sala de ${dep.name} (${active} trabalhando)` : `${dep.name}: nenhuma sessão detectada`;
      btn.onclick = () => { if (matches[0]) focus(matches[0].id); };
    }
  };
  store.on('snapshot', update);
  update();
}
