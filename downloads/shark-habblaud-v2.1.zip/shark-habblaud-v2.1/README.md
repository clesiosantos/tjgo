# Shark Innovation Office v2.1 — integração Paperclip ↔ Habblaud

Atualização da customização Shark v2 sobre Habblaud 1.0.3. Feita para o stack Docker Swarm `ai` da Shark Soluções. Não reinicia o Paperclip, não modifica o PostgreSQL nem altera workspaces ou agentes do Paperclip.

## Arquitetura

- Serviço de sincronização `shark-paperclip-sync.service` e `.timer` no host, a cada aproximadamente 15 s após terminar a execução anterior.
- Um processo Node temporário dentro do container Paperclip consulta **somente GET** em `http://127.0.0.1:3100` usando uma credencial Board dedicada, aprovada pelo administrador. Endpoints: `/api/companies/{id}/agents`, `/api/companies/{id}/heartbeat-runs?limit=100&summary=false`, `/api/issues/{id}`. O processo reduz as respostas a nomes, papéis, estados, vínculos, títulos e identificadores de tarefas/sessões; não publica logs, prompts, conteúdo de tarefas ou credenciais.
- A projeção sanitizada é publicada atomicamente em `/data/ai-stack/habblaud/shark-paperclip.json` com permissão 0640, acessível ao usuário do Habblaud pelo volume `/data`. Não monte o diretório de credenciais do Paperclip no Habblaud. Não há socket Docker dentro do Habblaud. A credencial Board tem autoridade administrativa: o código utiliza apenas GET, mas isso não transforma a credencial em uma chave de escopo somente leitura. O arquivo permanece no volume privado Paperclip, com permissão 0600; proteja esse volume.
- O endpoint interno do Habblaud GET `/api/shark/paperclip` serve somente a projeção. A página atualiza a cada 10 s; após 120 s sem sincronização válida, a projeção é considerada desatualizada e voltam a ser mostradas as sessões locais, com indicação de falha. Mantenha a autenticação Traefik do escritório.
- A interface utiliza ID de agente Paperclip como identidade de agrupamento e uma sessão real representativa (preferência à sessão trabalhando/aguardando; depois à mais recente). Os IDs originais do Habblaud são preservados para operações de histórico. A aparência é derivada do ID oficial e a alias explícita de Alexander usa visual masculino. O personagem de cadastro sem sessão é explicitamente identificado como tal, tem status baseado no Paperclip e não tem transcript inventado. Ao mudar de sessão/representante o personagem pode transitar visualmente; histórico detalhado é o da sessão representativa, não uma fusão de transcripts.
- Casos não correlacionados aparecem em `Paperclip · Sessões a vincular`, com nomes numerados, sem UUID como título da sala. Não são atribuídos arbitrariamente ao CEO. Outros projetos locais são preservados. Para o SHA-2, o fallback mapeia o UUID do workspace isolado somente se a tarefa estiver atribuída ao ID configurado e as execuções recentes observadas confirmarem o mesmo proprietário, sem conflito. Para novos casos a correlação principal é o ID de sessão retornado nas execuções; sem esse ID não há associação automática indevida. A lista é limitada às 100 execuções mais recentes da API.
- Departamentos automáticos por papel/título/nome, com overrides de `config.json`; papéis não reconhecidos ficam em `Equipe a classificar`. O cadastro do Shark CEO é apresentado como Alexander Morgan. O nome armazenado no Paperclip não é alterado. Ao criar outros agentes, configure papel/título e, se necessário, o override por ID.

## Requisitos

VPS original: `/opt/ai-stack`, fonte em `habblaud-src`, serviços `ai_paperclip` e `ai_habblaud` no mesmo nó, volume `/data/ai-stack/habblaud:/data` e sessões da empresa já montadas em `/codex/shark-company/sessions:ro`, junto de `/codex/shark-main/sessions`. A v2 já deve estar aplicada. Docker Swarm, systemd, Python 3, coreutils (timeout), `unzip`. O instalador verifica os pontos de ancoragem da v2 e falha se houver divergências. Não altera redes ou volumes.

## Instalação

Transfira o ZIP para `/opt/ai-stack`. Na VPS, como root:

```sh
cd /opt/ai-stack
unzip -o shark-habblaud-v2.1.zip
cd shark-habblaud-v2.1
bash authorize.sh
```

Abra a URL de aprovação no seu navegador já autenticado no Paperclip; aprove a CLI. Não envie o link de aprovação ou o token para ninguém. Este login é dedicado ao bridge e separado do utilizado na recuperação SHA-2. Depois:

```sh
bash deploy.sh
```

O deploy faz sincronização inicial, verifica montagem, prepara backup de source e stack.yml, aplica patch, constrói a imagem versionada e atualiza **somente** `ai_habblaud` via `docker service update`. O timer é ativado após o teste de leitura da projeção nova. O supervisor Swarm converge para a nova imagem. A imagem anterior não é apagada. Se uma etapa de instalação falhar depois do backup, o script tenta rollback automático. A camada UI mantém as quatro salas físicas da v2, inclusive vazias. A versão base pode continuar aparecendo como v1.0.3 no cabeçalho.

## Verificação

```sh
systemctl status shark-paperclip-sync.timer --no-pager
journalctl -u shark-paperclip-sync.service -n 20 --no-pager
docker service ps ai_habblaud --no-trunc
docker service logs ai_habblaud --since 5m --tail 60
```

Abra https://office.inovacao.sharksolucoes.com.br e recarregue a página. O rodapé do painel deverá indicar `Paperclip sincronizado`. A Diretoria Executiva deverá exibir Alexander Morgan. O SHA-2 deverá aparecer pelo identificador e título ao invés de seu UUID. O número global inclui agentes locais (Pietra etc.) e agentes cadastrados no Paperclip, não apenas threads Codex. Sessões sem vínculo confirmado podem aparecer separadamente; não representam novos funcionários do Paperclip.

É possível confirmar somente os contadores da projeção, sem mostrar credenciais ou conteúdo:

```sh
python3 - <<'PY'
import json
x=json.load(open('/data/ai-stack/habblaud/shark-paperclip.json'))
print('Agentes:', len(x['agents']))
print('Sessões correlacionadas:', len(x['sessions']))
print('Tarefas com vínculo verificado:', len(x['issueOwners']))
for a in x['agents']:
    print(a['name'], a['department'], a['status'])
PY
```

Se erro de credencial 401/403 ocorrer no timer, execute `authorize.sh` novamente e `systemctl start shark-paperclip-sync.service` (sem reiniciar Paperclip). Se o build falhar, confira o log antes de tentar instalar novamente.

## Rollback

O deploy informa o diretório real `/opt/ai-stack/backups/shark-v21-...`. Use:

```sh
bash /opt/ai-stack/shark-habblaud-v2.1/rollback.sh /opt/ai-stack/backups/shark-v21-AAAAMMDD-HHMMSS
```

Restaura a imagem anterior do Habblaud, o stack e fontes modificadas; desativa o timer. Não mexe no Paperclip, credenciais ou dados de sessões. Para revogar a credencial dedicada, execute `bash revoke.sh` no diretório do pacote. Isso desativa o bridge e não revoga a sessão normal do navegador.

## Testes realizados e limites

- Node: testes de projeção da API com dados simulados, alias CEO, papéis técnicos, conflito de propriedade, remoção de dados sensíveis.
- TypeScript: compilação estrita do módulo de projeção com fixtures dos tipos relevantes do Habblaud 1.0.3; simulação de três sessões da SHA-2 consolidada em um CEO, preservação de sessão local, avatar de cadastro, expiração de cache e remoção do UUID da sala.
- Validação sintática do Python, Bash e JavaScript; teste da alteração seletiva de imagem no YAML.
- Não foi executado o build completo do repositório na VPS, nem chamadas contra sua instância real. `deploy.sh` valida o build e a integração antes da ativação completa. Os testes são reproduzíveis com Node, `tsc` e `bash tests/run.sh` (fixtures, sem rede).
