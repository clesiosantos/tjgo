#!/usr/bin/env bash
set -euo pipefail
CID=$(docker ps -q --filter 'label=com.docker.swarm.service.name=ai_paperclip' | head -1)
test -n "$CID"
echo 'Aprove o acesso no navegador. Não compartilhe o link nem o token.'
docker exec -it --user node --workdir /app \
  -e PAPERCLIP_AUTH_STORE=/paperclip/shark-bridge-auth.json \
  -e PAPERCLIP_PUBLIC_URL=https://agents.inovacao.sharksolucoes.com.br \
  "$CID" pnpm paperclipai auth login --api-base http://127.0.0.1:3100 --company-id 9b4436f1-6b72-4cfe-b32b-2f35c0f7b19a --no-browser
# A credencial fica no volume privado do Paperclip.
docker exec --user node "$CID" chmod 600 /paperclip/shark-bridge-auth.json
