/* Executado somente dentro do Paperclip. API GET; nunca imprime token ou resposta bruta. */
const fs = require('node:fs');
const BASE = 'http://127.0.0.1:3100';
const STORE = '/paperclip/shark-bridge-auth.json';
const uuid = v => typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
const clean = (v, max=160) => typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g,' ').trim().slice(0,max) : '';
const when = r => Date.parse(r.createdAt || r.startedAt || '') || 0;
const issueOf = r => [r.issueId,r.contextIssueId,r.contextTaskId].find(uuid);
const live = r => ['running','queued','scheduled_retry'].includes(r.status);
const dept = a => {
  const role = clean(a.role).toLowerCase();
  const s = `${role} ${clean(a.title)} ${clean(a.name)}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  if (role === 'ceo' || /\b(ceo|diretoria executiva)\b/.test(s)) return 'ceo';
  if (/\b(cmo|marketing|growth|seo|sales|vendas|comercial|conteudo)\b/.test(s)) return 'marketing';
  if (/\b(research|pesquisa|inovacao|innovation|product|produto|produtos)\b/.test(s)) return 'innovation';
  if (/\b(cto|engineer|engineering|engenharia|developer|desenvolvedor|devops|tecnologia|web|software|tech)\b/.test(s)) return 'technology';
  return 'unassigned';
};
async function collect(config, get) {
  if (!uuid(config.companyId)) throw Error('companyId inválido');
  const root = `/api/companies/${config.companyId}`;
  const [agents,runs] = await Promise.all([get(`${root}/agents`),get(`${root}/heartbeat-runs?limit=100&summary=false`)]);
  if (!Array.isArray(agents) || !Array.isArray(runs)) throw Error('Formato inesperado da API');
  const known = new Map(agents.filter(a=>uuid(a.id)&&!['terminated','deleted'].includes(a.status)).map(a=>[a.id,a]));
  const rr = runs.filter(r=>!r.redacted && uuid(r.id) && known.has(r.agentId)).sort((a,b)=>when(b)-when(a));
  const latest = new Map();
  for(const r of rr){const old=latest.get(r.agentId); if(!old || (live(r)&&!live(old))) latest.set(r.agentId,r);}
  const issueIds = [...new Set([...Object.keys(config.verifiedIssueOwners||{}), ...rr.slice(0,30).map(issueOf), ...[...latest.values()].map(issueOf)].filter(uuid))].slice(0,40);
  const issueMap = {};
  // Limite de concorrência; não carrega logs, comentários, credenciais nem corpo de tarefas na saída.
  for(let i=0;i<issueIds.length;i+=5) await Promise.all(issueIds.slice(i,i+5).map(async id=>{
    try { const v=await get(`/api/issues/${id}`); if(v.id===id) issueMap[id]={id,identifier:clean(v.identifier,32),title:clean(v.title),assigneeAgentId:uuid(v.assigneeAgentId)?v.assigneeAgentId:null}; } catch(e){ if(e.status!==404 && e.status!==403) throw e; }
  }));
  const sessions = {}, ambiguous = new Set();
  for(const r of rr){
    for(const id of [r.sessionIdAfter,r.sessionIdBefore]){
      if(!uuid(id))continue; const key=id.toLowerCase();
      if(sessions[key] && sessions[key].agentId!==r.agentId){ambiguous.add(key);delete sessions[key];continue;}
      if(!ambiguous.has(key)&&!sessions[key])sessions[key]={agentId:r.agentId,issueId:issueOf(r)||null};
    }
  }
  const issueOwners = {};
  // Fallback restrito às tarefas explicitamente verificadas pelo operador. Nunca adivinha por assignee sozinho.
  for(const [id,owner] of Object.entries(config.verifiedIssueOwners||{})){
    const relevant=rr.filter(r=>issueOf(r)===id);
    if(uuid(id)&&known.has(owner)&&issueMap[id]?.assigneeAgentId===owner&&relevant.length&&relevant.every(r=>r.agentId===owner)) issueOwners[id]=owner;
  }
  const outputAgents=[...known.values()].map(a=>{
    const override=config.agents?.[a.id]||{};const r=latest.get(a.id);const i=issueOf(r||{});
    const department=['ceo','innovation','marketing','technology','unassigned'].includes(override.department)?override.department:dept(a);
    return {id:a.id,name:clean(override.name||a.name)||'Agente Paperclip',role:clean(override.role||a.title||a.role)||'Agente',department,look:override.look==='m'?'m':override.look==='f'?'f':null,status:clean(a.status,40),runStatus:r?clean(r.status,40):null,issueId:i||null,updatedAt:Date.parse(a.updatedAt||'')||when(r||{})||Date.now()};
  });
  const issues=Object.fromEntries(Object.entries(issueMap).map(([id,v])=>[id,{identifier:v.identifier,title:v.title}]));
  return {schema:1,generatedAt:Date.now(),agents:outputAgents,sessions,issueOwners,issues};
}
async function main(){
  const config=JSON.parse(process.argv[2]);
  const store=JSON.parse(fs.readFileSync(STORE,'utf8'));const token=store.credentials?.[BASE]?.token;
  if(!token)throw Error('Credencial do bridge inexistente; execute authorize.sh');
  const get=async path=>{const r=await fetch(BASE+path,{method:'GET',headers:{Authorization:`Bearer ${token}`,Accept:'application/json'},signal:AbortSignal.timeout(12000),redirect:'error'});if(!r.ok){const e=Error(`Paperclip HTTP ${r.status} na consulta ${path.split('?')[0]}`);e.status=r.status;throw e;}return r.json();};
  process.stdout.write(JSON.stringify(await collect(config,get))+'\n');
}
module.exports={collect};
if(require.main===module || process.argv[1]==='-')main().catch(e=>{console.error('Bridge:',e.message);process.exitCode=1;});
