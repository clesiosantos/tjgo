#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/opt/ai-stack
PACK=$(cd "$(dirname "$0")" && pwd)
SRC="$ROOT/habblaud-src"
[[ "$PACK" == "$ROOT/shark-habblaud-v2.1" ]] || { echo 'Extraia em /opt/ai-stack/shark-habblaud-v2.1'; exit 1; }
[[ $EUID == 0 ]] || { echo 'Execute como root na VPS'; exit 1; }
for f in "$SRC/package.json" "$ROOT/stack.yml" "$ROOT/.env"; do test -f "$f"; done
# Auth/sync antes de qualquer alteração de código ou serviço.
chmod +x "$PACK"/*.sh
"$PACK/sync.sh"
HAB=$(docker ps -q --filter 'label=com.docker.swarm.service.name=ai_habblaud' | head -1)
test -n "$HAB"
docker exec "$HAB" test -r /data/shark-paperclip.json || { echo 'Projeção não legível no Habblaud. Confira volume /data e GID.'; exit 1; }
# Confirma montagem exclusiva de sessões da empresa e fonte observada.
docker inspect "$HAB" --format '{{range .Mounts}}{{println .Destination}}{{end}}' | grep -Fxq /codex/shark-company/sessions || { echo 'Montagem /codex/shark-company/sessions ausente; configure a integração de sessões da empresa primeiro.'; exit 1; }
# Não sobrescreve um timer anterior sem backup.
if systemctl is-active --quiet shark-paperclip-sync.timer; then echo 'Bridge já ativo; faça rollback antes de nova instalação.'; exit 1; fi
umask 077
TS=$(date +%Y%m%d-%H%M%S)
IMAGE="habblaud:shark-1.0.3-v2.1-$TS"
BACKUP="$ROOT/backups/shark-v21-$TS"
mkdir -p "$BACKUP/source"
cp -p "$ROOT/stack.yml" "$BACKUP/stack.yml"
docker service inspect ai_habblaud --format '{{.Spec.TaskTemplate.ContainerSpec.Image}}' > "$BACKUP/old-image.txt"
FILES=(client/src/net/store.ts client/src/net/shark-paperclip.ts client/src/ui/shark-office.ts client/src/ui/feed.ts server/http/app.ts)
for f in "${FILES[@]}"; do
 if [[ -f "$SRC/$f" ]]; then mkdir -p "$BACKUP/source/$(dirname "$f")"; cp -p "$SRC/$f" "$BACKUP/source/$f"; else printf '%s\n' "$f" >> "$BACKUP/new-files.txt"; fi
done
printf 'Backup: %s\n' "$BACKUP"
trap 'echo "Falha: restaurando v2" >&2; "$PACK/rollback.sh" "$BACKUP" || true' ERR
python3 "$PACK/install_patch.py" "$SRC"
# Original Dockerfile da instalação v2; build valida TypeScript/Vite.
docker build -t "$IMAGE" "$SRC"
# Valida arquivos mínimos da imagem sem iniciar um servidor nem montar credenciais.
docker run --rm --entrypoint node "$IMAGE" -e 'require("node:fs").accessSync("/app/dist/server/index.js")'
python3 - "$ROOT/stack.yml" "$IMAGE" <<'PY'
import sys,re,pathlib
p=pathlib.Path(sys.argv[1]); s=p.read_text(); image=sys.argv[2]
# Apenas imagem dentro do bloco habblaud, sem tocar nos demais serviços.
m=re.search(r'(?m)^  habblaud:[ \t]*\n(?:(?:[ ]{4,}[^\n]*|[ \t]*#[^\n]*|[ \t]*)\n)*',s)
if not m: raise SystemExit('Serviço habblaud não encontrado')
b=m.group(); new,n=re.subn(r'(?m)^(    image:[ \t]*).+$',lambda x:x.group(1)+image,b,count=1)
if n!=1: raise SystemExit('Imagem de habblaud não encontrada')
p.write_text(s[:m.start()]+new+s[m.end():])
PY
cd "$ROOT"
set -a; source .env; set +a
docker stack config -c stack.yml >/dev/null
# Atualiza apenas Habblaud; não redeploy do stack inteiro nem do Paperclip.
docker service update --detach=false --no-resolve-image --image "$IMAGE" ai_habblaud
HAB=$(docker ps -q --filter 'label=com.docker.swarm.service.name=ai_habblaud' | head -1)
[[ -n "$HAB" ]]
# Nova imagem deve responder antes de ativar o timer.
"$PACK/sync.sh"
OK=0
for n in {1..10}; do
 if docker exec "$HAB" node -e 'fetch("http://127.0.0.1:4747/api/shark/paperclip").then(async r=>{if(!r.ok) throw Error("HTTP "+r.status);const x=await r.json();if(x.schema!==1)throw Error("schema");console.log("Bridge OK:",x.agents.length,"agentes")}).catch(e=>{console.error(e.message);process.exitCode=1})'; then OK=1; break; fi
 sleep 3
done
[[ "$OK" == 1 ]]
install -m 0644 "$PACK/shark-paperclip-sync.service" /etc/systemd/system/shark-paperclip-sync.service
install -m 0644 "$PACK/shark-paperclip-sync.timer" /etc/systemd/system/shark-paperclip-sync.timer
systemctl daemon-reload
systemctl enable --now shark-paperclip-sync.timer
# Dispara imediatamente para manter a projeção fresca.
systemctl start shark-paperclip-sync.service
trap - ERR
printf '\nOK. Abra office.inovacao.sharksolucoes.com.br e recarregue a página.\nBackup: %s\nRollback: bash %s/rollback.sh %s\n' "$BACKUP" "$PACK" "$BACKUP"
