#!/usr/bin/env python3
"""Atualização sobre a v2. Falha fechada se as âncoras não correspondem à revisão instalada."""
from pathlib import Path
import sys, shutil, json
root=Path(sys.argv[1]).resolve()
pack=Path(__file__).resolve().parent
assert json.loads((root/'package.json').read_text())['version']=='1.0.3','Versão diferente de 1.0.3'
net=root/'client/src/net/store.ts'
assert 'private ensureSharkDepartments(' in (root/'client/src/world/sim/sim.ts').read_text(),'Instale a v2 primeiro'
assert 'shark:ceo' in (root/'client/src/ui/shark-office.ts').read_text(),'Painel v2 não encontrado'
# Prepare all changes in memory, no partial writes on anchor errors.
changes={}
def load(path):
    return changes.get(path,(root/path).read_text())
def replace(path,old,new):
    s=load(path)
    if s.count(old)!=1: raise SystemExit(f'Âncora inválida: {path}: {old[:120]}')
    changes[path]=s.replace(old,new,1)
store='client/src/net/store.ts'
if 'SHARK_PAPERCLIP_V21' in net.read_text(): raise SystemExit('v2.1 já aplicada; faça rollback antes de reinstalar.')
replace(store,"import { DemoSimulator } from '../../../shared/demo/simulator';","""import { DemoSimulator } from '../../../shared/demo/simulator';
import { freshSharkData, projectShark, mapSharkFeed, type SharkData, type Projection } from './shark-paperclip';""")
replace(store,'  private replay = false;','''  // SHARK_PAPERCLIP_V21: mantém o snapshot original, sem alterar o SSE ou seus IDs de sessão.
  private sharkData: SharkData | null = null;
  private sharkRaw: OfficeSnapshot | null = null;
  private sharkAliases: Projection['aliases'] = new Map();
  private sharkTimer: ReturnType<typeof setInterval> | null = null;
  private sharkPolling = false;
  sharkConnected(): boolean { return freshSharkData(this.sharkData); }
  sharkFeedItem(item: FeedItem): FeedItem { return this.mock || this.replay ? item : mapSharkFeed(item, this.sharkAliases); }
  private async refreshShark(): Promise<void> {
    if (this.sharkPolling || this.stopped || this.mock) return;
    this.sharkPolling = true;
    try {
      const res = await fetch('/api/shark/paperclip', {cache:'no-store', signal:AbortSignal.timeout(7000)});
      if (res.ok) {
        const data = await res.json() as SharkData;
        if (freshSharkData(data)) this.sharkData = data;
      }
    } catch { /* Cache expirado nunca é interpretado como estado atual. */ }
    finally {
      this.sharkPolling = false;
      if (!this.stopped && !this.replay && this.sharkRaw) this.setSnapshot(this.sharkRaw);
    }
  }
  private replay = false;''')
replace(store,'    if (this.mock) return this.startMock();\n    this.startSSE();','''    if (this.mock) return this.startMock();
    if (typeof window !== 'undefined') {
      void this.refreshShark();
      this.sharkTimer = setInterval(() => void this.refreshShark(), 10000);
    }
    this.startSSE();''')
replace(store,'    this.stopped = true;\n    if (typeof removeEventListener', '''    this.stopped = true;
    if (this.sharkTimer) clearInterval(this.sharkTimer);
    this.sharkTimer = null;
    if (typeof removeEventListener''')
replace(store,'      this.live = this.snapshot ? { snap: this.snapshot, at: Date.now() } : null;', '      this.live = this.sharkRaw ? { snap: this.sharkRaw, at: Date.now() } : this.snapshot ? { snap: this.snapshot, at: Date.now() } : null;')
replace(store,'    if (this.replay) this.live = { snap, at: Date.now() };\n    else this.setSnapshot(snap);','''    this.sharkRaw = snap;
    if (this.replay) this.live = { snap, at: Date.now() };
    else this.setSnapshot(snap);''')
# Replace the v2 setSnapshot implementation as a whole; bounded by method marker.
s=load(store); start=s.index('  private setSnapshot(snap: OfficeSnapshot): void {'); end=s.index('\n  private updateAnnounced',start)
old=s[start:end]
assert 'this.agentIndex' in old and 'this.roomIndex' in old and 'ceoIds' in old,'setSnapshot não corresponde à v2'
new='''  private setSnapshot(snap: OfficeSnapshot): void {
    if (!this.mock && !this.replay && !snap.meta.demo) {
      const projected = projectShark(snap, this.sharkData);
      snap = projected.snapshot;
      for (const [id, alias] of projected.aliases) this.sharkAliases.set(id, alias);
      // Limita o cache de aliases sem modificar registros históricos do servidor.
      while (this.sharkAliases.size > 3000) { const first = this.sharkAliases.keys().next(); if (first.done) break; this.sharkAliases.delete(first.value); }
      this.feed = this.feed.map(f => mapSharkFeed(f, this.sharkAliases));
    }
    this.snapshot = snap;
    this.agentIndex = new Map(snap.agents.map((a) => [a.id, a]));
    this.roomIndex = new Map(snap.rooms.map((r) => [r.id, r]));
    this.emit('snapshot', snap);
  }
'''
changes[store]=s[:start]+new+s[end:]
replace(store,'    if (this.mock || this.replay) return this.agent(id)?.recent ?? [];','    if (this.mock || this.replay || id.startsWith(\'shark-roster:\')) return this.agent(id)?.recent ?? [];')
replace(store,"    if (this.mock || this.replay) return tr('Editar o personagem só funciona com o escritório ao vivo.');","    if (id.startsWith('shark-roster:')) return 'Identidade gerenciada no Paperclip; nenhuma sessão local aberta.';\n    if (this.mock || this.replay) return tr('Editar o personagem só funciona com o escritório ao vivo.');")
replace(store,'    const fresh = items.filter((f) => !known.has(f.id));','    const fresh = items.filter((f) => !known.has(f.id)).map(f => !this.mock && !this.replay ? mapSharkFeed(f, this.sharkAliases) : f);')
feed='client/src/ui/feed.ts'
replace(feed,'    const visible = filtering ? this.items.filter((f) => this.visible(f)) : this.items;\n    const pending = filtering ? this.pending.filter((f) => this.visible(f)) : this.pending;', '''    const visible = (filtering ? this.items.filter((f) => this.visible(f)) : this.items).map(f => this.ctx.store.sharkFeedItem(f));
    const pending = (filtering ? this.pending.filter((f) => this.visible(f)) : this.pending).map(f => this.ctx.store.sharkFeedItem(f));''')
replace(feed,"      if (this.ctx.agent(f.agentId)) this.ctx.select({ type: 'agent', id: f.agentId }, { focus: true });\n      else if (this.ctx.store.room(f.roomId)) this.ctx.select({ type: 'room', id: f.roomId }, { focus: true });", '''      const item = this.ctx.store.sharkFeedItem(f);
      if (this.ctx.agent(item.agentId)) this.ctx.select({ type: 'agent', id: item.agentId }, { focus: true });
      else if (this.ctx.store.room(item.roomId)) this.ctx.select({ type: 'room', id: item.roomId }, { focus: true });''')
server='server/http/app.ts'
replace(server,"import type { IncomingMessage, ServerResponse } from 'node:http';","import type { IncomingMessage, ServerResponse } from 'node:http';\nimport { readFileSync, statSync } from 'node:fs';")
replace(server,"    if (path === '/api/snapshot') {",'''    // SHARK_PAPERCLIP_V21: somente projeção sanitizada, sem token ou proxy administrativo.
    if (path === '/api/shark/paperclip') {
      if (!isRead) methodNotAllowed(res, 'GET');
      else if (isRemote(req)) sendJson(res, 403, {error:'local office only'});
      else {
        try {
          const file='/data/shark-paperclip.json';
          if (statSync(file).size > 2*1024*1024) throw new Error('projection too large');
          const data=JSON.parse(readFileSync(file,'utf8'));
          if(data.schema!==1 || !Number.isFinite(data.generatedAt) || Date.now()-data.generatedAt>=120000 || data.generatedAt-Date.now()>30000) throw new Error('projection stale');
          sendJson(res,200,data);
        } catch { sendJson(res,503,{error:'Paperclip bridge unavailable or stale'}); }
      }
      return true;
    }
    if (path === '/api/snapshot') {''')
ui='client/src/ui/shark-office.ts'
s=load(ui)
# The v2 modifies the v1 footer; update independent of text variation on deployed copy.
import re
s,n=re.subn(r"footer\.textContent = '[^']*';", "footer.textContent = 'Paperclip · sincronização de identidade';",s,count=1)
assert n==1,'Footer não localizado'
needle='    const rooms = store.snapshot?.rooms ?? [];'
assert s.count(needle)==1
s=s.replace(needle,"    footer.textContent = store.sharkConnected() ? 'Paperclip sincronizado · agentes reais e sessões vinculadas' : 'Paperclip sem sincronização recente · exibindo sessões locais';\n"+needle)
# Explicit counts by canonical room ID and conventional technical path.
s=s.replace('rooms.filter((room) => dep.match.test(`${room.path} ${room.name}`))','rooms.filter((room) => room.id === dep.id || dep.match.test(`${room.path} ${room.name}`))')
# Keep v2 button focus behavior and count only mains.
changes[ui]=s
for p,s in changes.items(): (root/p).write_text(s)
shutil.copy2(pack/'overlay/shark-paperclip.ts',root/'client/src/net/shark-paperclip.ts')
print('OK: integração v2.1 aplicada.')
