import type { AgentInfo, FeedItem, OfficeSnapshot, RoomInfo } from '../../../shared/types';
import { SHARK_DEPARTMENTS } from '../world/layout/shark-departments';
export interface PaperAgent { id:string; name:string; role:string; department:string; look:'m'|'f'|null; status:string; runStatus:string|null; issueId:string|null; updatedAt:number }
export interface SharkData { schema:1; generatedAt:number; agents:PaperAgent[]; sessions:Record<string,{agentId:string;issueId:string|null}>; issueOwners:Record<string,string>; issues:Record<string,{identifier:string;title:string}> }
const UUID=/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const DEPT_PATH:Record<string,string>={ceo:'alexander-ceo',innovation:'inovacao-produtos',marketing:'marketing-growth',technology:'tecnologia-web'};
const seed=(s:string):number=>{let n=2166136261;for(let i=0;i<s.length;i++)n=Math.imul(n^s.charCodeAt(i),16777619);return n>>>0;};
const rank=(a:AgentInfo)=>a.status==='working'||a.status==='waiting'?2:a.status==='offline'?0:1;
const byPriority=(a:AgentInfo,b:AgentInfo)=>rank(b)-rank(a)||b.lastEventAt-a.lastEventAt||a.id.localeCompare(b.id);
export function freshSharkData(d:SharkData|null, now=Date.now()):d is SharkData {return !!d&&d.schema===1&&Number.isFinite(d.generatedAt)&&now-d.generatedAt<120000&&d.generatedAt-now<30000&&Array.isArray(d.agents)&&!!d.sessions&&!!d.issues&&!!d.issueOwners;}
export interface Projection {snapshot:OfficeSnapshot; aliases:Map<string,{agentId:string;agentName:string;roomId:string;roomName:string}>;}
export function projectShark(raw:OfficeSnapshot,data:SharkData|null):Projection {
  const aliases:Projection['aliases']=new Map();
  const valid=freshSharkData(data)?data:null;
  const roster=new Map((valid?.agents??[]).map(a=>[a.id,a]));
  const originalRooms=new Map(raw.rooms.map(r=>[r.id,r]));
  const accounts=raw.accounts.map(a=>a.configDir?.replace(/\/$/,'').endsWith('/shark-company')||a.id==='shark-company'?{...a,name:'Shark AI'}:a);
  const companyAccounts=new Set(accounts.filter(a=>a.name==='Shark AI').map(a=>a.id));
  const companyRoom=(a:AgentInfo)=>a.provider==='codex'&&companyAccounts.has(a.account);
  const isolatedIssue=(a:AgentInfo)=>{const p=originalRooms.get(a.roomId)?.path??'';if(!/(^|\/)isolated-workspaces(?:\/|$)/i.test(p))return undefined;const end=p.split('/').filter(Boolean).pop()??'';return UUID.test(end)?end.toLowerCase():undefined;};
  const resolve=(a:AgentInfo):{owner:PaperAgent;issueId:string|null}|undefined=>{
    if(!valid||!companyRoom(a))return;
    const exact=valid.sessions[a.sessionId.toLowerCase()]; const issueId=isolatedIssue(a);
    const id=exact?.agentId||(issueId?valid.issueOwners[issueId]:undefined);
    const owner=id?roster.get(id):undefined; if(owner)return {owner,issueId:exact?.issueId||issueId||null};
  };
  const roomMap=new Map<string,RoomInfo>();
  const putRoom=(department:string):RoomInfo=>{
    const d=SHARK_DEPARTMENTS.find(x=>x.id===`shark:${department}`);
    const id=d?.id??'shark-unassigned';const existing=roomMap.get(id);if(existing)return existing;
    const room:RoomInfo={id,name:d?.name??'Equipe a classificar',path:d?`/shark/departments/${DEPT_PATH[department]}`:'/shark/equipe-a-classificar',slot:d?SHARK_DEPARTMENTS.indexOf(d):90,seed:d?.seed??seed(id),createdAt:raw.serverTime};roomMap.set(id,room);return room;
  };
  const unlinkedRoom=():RoomInfo=>{const id='shark-unlinked';let r=roomMap.get(id);if(!r){r={id,name:'Paperclip · Sessões a vincular',path:'/shark/sessoes-a-vincular',slot:99,seed:seed(id),createdAt:raw.serverTime};roomMap.set(id,r);}return r;};
  const out:AgentInfo[]=[];const groups=new Map<string,Array<{a:AgentInfo;owner:PaperAgent;issueId:string|null}>>();
  let unlinkedCount=0;
  const main=raw.agents.filter(a=>a.kind==='main').sort((a,b)=>a.id.localeCompare(b.id));
  for(const a of main){const match=resolve(a);if(match){const list=groups.get(match.owner.id)??[];list.push({a,...match});groups.set(match.owner.id,list);}
    else if(companyRoom(a)){const room=unlinkedRoom();const name='Sessão não vinculada '+(++unlinkedCount);out.push({...a,roomId:room.id,name,role:'Sessão Codex · vínculo pendente',title:'Sessão Codex sem vínculo confirmado'});aliases.set(a.id,{agentId:a.id,agentName:name,roomId:room.id,roomName:room.name});}
    else {out.push(a);const r=originalRooms.get(a.roomId);if(r)roomMap.set(r.id,r);}}
  const taskTitle=(issueId:string|null)=>{const i=issueId&&valid?.issues[issueId];return i?[i.identifier,i.title].filter(Boolean).join(' — '):undefined;};
  for(const owner of roster.values()){
    const group=(groups.get(owner.id)??[]).sort((a,b)=>byPriority(a.a,b.a));const room=putRoom(owner.department);
    const active=owner.runStatus==='running'||owner.status==='running';
    const representative=group.find(x=>x.a.status!=='offline');
    const title=taskTitle(representative?.issueId||owner.issueId);
    let a:AgentInfo;
    if(representative){const base=representative.a;a={...base,name:owner.name,role:owner.role,look:owner.look??base.look,seed:seed(owner.id),roomId:room.id,title:title||base.title,canMessage:false};}
    else{const id=`shark-roster:${owner.id}`;const status:AgentInfo['status']=active?'working':'idle';const at=owner.updatedAt||raw.serverTime;a={id,kind:'main',provider:'codex',roomId:room.id,name:owner.name,role:`${owner.role} · sem sessão local${owner.status==='paused'?' · pausado':owner.status==='error'?' · erro':''}`,title:title||'Cadastro Paperclip',look:owner.look??'m',sessionId:id,account:[...companyAccounts][0]??'shark-company',status,startedAt:at,lastEventAt:at,statusSince:at,recent:[],tasks:[],stats:{toolCalls:0,tokensIn:0,tokensOut:0,subagents:0},seed:seed(owner.id),canMessage:false};}
    out.push(a);
    for(const item of group)aliases.set(item.a.id,{agentId:a.id,agentName:a.name,roomId:room.id,roomName:room.name});
  }
  // Subagentes reais ficam vinculados ao representante do pai; não representam funcionários adicionais.
  for(const a of raw.agents.filter(x=>x.kind==='sub')){
    const parent=a.parentId?aliases.get(a.parentId):undefined;
    if(parent){out.push({...a,roomId:parent.roomId,parentId:parent.agentId});}
    else if(!companyRoom(a)){out.push(a);const r=originalRooms.get(a.roomId);if(r)roomMap.set(r.id,r);}
  }
  // Preserva salas sem agentes de fontes manuais. Não deixa UUID de workspace isolado no escritório.
  for(const r of raw.rooms){if(!raw.agents.some(a=>a.roomId===r.id)&&!/(^|\/)isolated-workspaces(?:\/|$)/i.test(r.path))roomMap.set(r.id,r);}
  return {snapshot:{...raw,agents:out,rooms:[...roomMap.values()],accounts},aliases};
}
export function mapSharkFeed(f:FeedItem, aliases:Projection['aliases']):FeedItem {const a=aliases.get(f.agentId);return a?{...f,...a}:f;}
