#!/usr/bin/env bash
set -euo pipefail
systemctl disable --now shark-paperclip-sync.timer 2>/dev/null || true
systemctl stop shark-paperclip-sync.service 2>/dev/null || true
CID=$(docker ps -q --filter 'label=com.docker.swarm.service.name=ai_paperclip' | head -1)
test -n "$CID"
docker exec --user node --workdir /app -e PAPERCLIP_AUTH_STORE=/paperclip/shark-bridge-auth.json "$CID" pnpm paperclipai auth logout --api-base http://127.0.0.1:3100
