#!/usr/bin/env bash
set -euo pipefail
ROOT=/opt/ai-stack
BACKUP=$(realpath "${1:?Informe caminho do backup criado no deploy}")
case "$BACKUP" in "$ROOT"/backups/shark-v21-*) ;; *) echo 'Backup inválido'; exit 1;; esac
test -f "$BACKUP/stack.yml" && test -f "$BACKUP/old-image.txt"
systemctl disable --now shark-paperclip-sync.timer 2>/dev/null || true
systemctl stop shark-paperclip-sync.service 2>/dev/null || true
rm -f /etc/systemd/system/shark-paperclip-sync.timer /etc/systemd/system/shark-paperclip-sync.service
systemctl daemon-reload
cp -a "$BACKUP/source/." "$ROOT/habblaud-src/"
if [[ -f "$BACKUP/new-files.txt" ]]; then while IFS= read -r f; do case "$f" in client/src/net/shark-paperclip.ts) rm -f "$ROOT/habblaud-src/$f";; esac; done < "$BACKUP/new-files.txt"; fi
cp -p "$BACKUP/stack.yml" "$ROOT/stack.yml"
OLD=$(cat "$BACKUP/old-image.txt")
# Nao remove sessões, dados de agentes, credenciais ou PostgreSQL.
CURRENT=$(docker service inspect ai_habblaud --format '{{.Spec.TaskTemplate.ContainerSpec.Image}}')
if [[ "$CURRENT" != "$OLD" ]]; then docker service update --detach=false --no-resolve-image --image "$OLD" ai_habblaud; fi
echo 'v2 restaurada. Para revogar a credencial do bridge, use revoke.sh.'
