#!/usr/bin/env bash
set -Eeuo pipefail
PACK=$(cd "$(dirname "$0")" && pwd)
DATA=/data/ai-stack/habblaud
[[ -d "$DATA" ]] || { echo 'Volume Habblaud não encontrado' >&2; exit 1; }
CID=$(docker ps -q --filter 'label=com.docker.swarm.service.name=ai_paperclip' | head -1)
HAB=$(docker ps -q --filter 'label=com.docker.swarm.service.name=ai_habblaud' | head -1)
[[ -n "$CID" && -n "$HAB" ]] || { echo 'Serviços indisponíveis' >&2; exit 1; }
umask 077
TMP=$(mktemp "$DATA/.shark-paperclip.XXXXXX")
trap 'rm -f "$TMP"' EXIT
# Código em stdin, sem credenciais na linha de comando ou no ambiente do Habblaud.
timeout 85 docker exec -i --user node --workdir /app "$CID" node - "$(cat "$PACK/config.json")" < "$PACK/collect.cjs" > "$TMP"
python3 - "$TMP" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]))
assert x.get('schema')==1 and isinstance(x.get('agents'),list) and isinstance(x.get('sessions'),dict)
print(f"Paperclip: {len(x['agents'])} agentes, {len(x['sessions'])} sessões correlacionadas, {len(x['issueOwners'])} vínculos verificados.")
PY
GID=$(docker exec "$HAB" id -g)
chown "root:$GID" "$TMP"
chmod 0640 "$TMP"
mv -f "$TMP" "$DATA/shark-paperclip.json"
