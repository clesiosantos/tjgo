#!/usr/bin/env bash
set -Eeuo pipefail
PACK=$(cd "$(dirname "$0")/.." && pwd)
node "$PACK/tests/collector.test.cjs"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/client/src/net" "$TMP/client/src/world/layout" "$TMP/shared"
cp "$PACK/overlay/shark-paperclip.ts" "$TMP/client/src/net/"
cp "$PACK/tests/shark-departments.fixture.ts" "$TMP/client/src/world/layout/shark-departments.ts"
cp "$PACK/tests/types.fixture.ts" "$TMP/shared/types.ts"
cp "$PACK/tests/projection.test.cjs" "$TMP/test.cjs"
tsc --strict --target ES2022 --module commonjs --outDir "$TMP/out" "$TMP/client/src/net/shark-paperclip.ts"
node "$TMP/test.cjs"
