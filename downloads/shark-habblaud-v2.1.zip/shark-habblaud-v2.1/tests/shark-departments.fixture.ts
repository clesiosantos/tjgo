/** Unidades físicas da Shark Soluções. Somente cenários; nunca agentes falsos. */
export const SHARK_DEPARTMENTS = [
  { id: 'shark:ceo', name: 'Diretoria Executiva', seed: 48201, carpet: '#08354c', carpet2: '#11617b', accent: '#31d5e8', pattern: 'glass' as const },
  { id: 'shark:innovation', name: 'Inovação e Produtos', seed: 48202, carpet: '#134253', carpet2: '#197e8a', accent: '#41d5b7', pattern: 'glass' as const },
  { id: 'shark:marketing', name: 'Marketing e Growth', seed: 48203, carpet: '#273750', carpet2: '#315d9c', accent: '#58a9ff', pattern: 'glass' as const },
  { id: 'shark:technology', name: 'Tecnologia e Web', seed: 48204, carpet: '#152c48', carpet2: '#1d6695', accent: '#52cbff', pattern: 'glass' as const },
] as const;

/** Roteia uma sessão REAL para um departamento visual fixo pelo caminho do workspace. */
export function sharkDepartmentForPath(path: string): string | undefined {
  const p = path.toLowerCase();
  if (/(alexander-ceo|diretoria-executiva|ceo-innovation)/.test(p)) return 'shark:ceo';
  if (/(inovacao-produtos|innovation-products|pesquisa-produtos)/.test(p)) return 'shark:innovation';
  if (/(marketing-growth|marketing-digital)/.test(p)) return 'shark:marketing';
  if (/(shark-dev|tecnologia-web|shark-web)/.test(p)) return 'shark:technology';
  return undefined;
}
