> **Revisão v2.2.1 (correção do `prepare`):** A primeira edição do pacote v2.2
> procurava a linha original `const fresh = items.filter(...)` no `store.ts`.
> A integração Shark v2.1 já havia substituído essa linha por uma versão com
> `mapSharkFeed`. Esta revisão utiliza a âncora real da v2.1, preserva o
> mapeamento existente e acrescenta a associação segura dos novos eventos.
> Se `prepare` falhar por outro motivo, não continue com `install`.
>
# Shark Innovation Office v2.2 — Feed de atividades do Paperclip

Patch adicional sobre a **personalização Shark v2.1** do Habblaud 1.0.3.

## Problema

A integração v2.1 projeta *identidades e departamentos* do Paperclip, mas o feed nativo do Habblaud continua usando principalmente os transcripts das sessões Codex antigas. O Paperclip Runner nativo grava atividade em `heartbeat_run_events` e usa diretórios de sessões diferentes.

## Solução

1. Um coletor Python **somente de leitura** consulta `heartbeat_run_events` do PostgreSQL existente por `docker exec ... psql` a cada ~10 s. Coleta apenas nomes dos agentes, IDs de tarefas, horário e tipos de evento **permitidos**. Não lê `payload`, `message`, prompts, respostas, credenciais, comandos nem arquivos privados.
2. Salva `shark-activity.json` de modo atômico em `/data/ai-stack/habblaud`, volume já presente no Habblaud (`/data`).
3. Uma pequena extensão do Hub SSE do Habblaud lê o arquivo a cada 5 s e envia os novos `FeedItem` pelo **mesmo** evento `feed` do `/api/stream` existente. Não cria endpoint adicional, não abre portas e não exige alterações no Traefik.
4. Um ajuste opcional no cliente resolve o avatar/sala do agente por nome (quando o agente da v2.1 já aparece no snapshot).

## Pré-requisitos

- VPS com Docker Swarm (serviço `ai_habblaud`) e PostgreSQL (`ai_postgres`).
- Código-fonte da versão **Shark v2.1** em `/opt/ai-stack/habblaud-src`.
- O pacote extraído exatamente em `/opt/ai-stack/shark-habblaud-v2.2`.
- O serviço Habblaud mantém o volume `/data/ai-stack/habblaud:/data`.
- `docker build` funcionando no host, acesso aos pacotes npm da imagem, e root para `systemctl`.

## Instalação gradual

```bash
cd /opt/ai-stack/shark-habblaud-v2.2
./deploy.sh prepare          # SOMENTE valida código e consulta eventos (sem alterações)
./deploy.sh install          # patch fontes + timer coletor
./deploy.sh status           # conferir criação de shark-activity.json
./deploy.sh build            # compila nova imagem, sem alterar container ativo
./deploy.sh deploy           # atualiza somente o serviço ai_habblaud no Swarm
./deploy.sh status           # confirmar 1/1, logs e coletor
```

Depois de ver o feed real funcionando no navegador, persistir a imagem nova no stack:

```bash
./deploy.sh persist
```

O script não executa `docker stack deploy` sozinho, pois isso poderia afetar outros serviços. O serviço é atualizado pontualmente com `docker service update` e uma eventual falha de atualização terá política automática de rollback.

## Conferência visual e SSE

- Recarregar `https://office.inovacao.sharksolucoes.com.br` (limpar cache se necessário).
- Ativar conta `Shark AI` nos filtros da barra lateral.
- Conferir novas atividades do tipo `Iniciou execução de ferramenta · SHA-13` / `Concluiu etapa de trabalho · SHA-13` associadas ao nome real do agente.
- Atualização estimada: 10–20 segundos (coleta e SSE), conforme latência da VPS.
- Ver logs: `journalctl -u shark-paperclip-activity.service -n 20 --no-pager` e `docker service logs ai_habblaud --tail 50`.

### Diagnóstico rápido do arquivo

```bash
python3 - <<'PY'
import json,time
p='/data/ai-stack/habblaud/shark-activity.json'
x=json.load(open(p))
print('eventos',len(x['items']),'idade (segundos)',round((time.time()*1000-x['generatedAt'])/1000))
print('últimos nomes/tarefas:', [(i['agentName'],i['activity']['text']) for i in x['items'][-5:]])
PY
```

## Rollback

```bash
cd /opt/ai-stack/shark-habblaud-v2.2
./deploy.sh rollback
```

Restaura a imagem do serviço Habblaud, o `stack.yml` anterior, os dois arquivos-fonte alterados e desativa o timer novo. Não modifica o PostgreSQL, o Paperclip, nem seus dados persistentes. O arquivo JSON coletado permanece no disco, mas não será lido pela imagem antiga.

## Limitações e critérios

- O painel anterior continua podendo apresentar eventos Codex antigos; os novos eventos Paperclip serão acrescentados e ordenados pelo horário com o feed existente. O painel é limitado aos 50 itens recentes.
- São ignorados `item.delta` e dados detalhados dos `payloads` para evitar ruído e vazamento de informações. As descrições dos eventos são genéricas por design; não afirmam qual ferramenta específica rodou.
- A projeção visual de nomes/personagens é baseada nos agentes já conhecidos pelo Habblaud. Se houver agentes homônimos, o avatar pode permanecer genérico; o nome exibido vem do PostgreSQL.
- O coletor precisa de acesso Docker como root (o root já gerencia o Stack); não cria usuário externo nem expõe PostgreSQL.
- O patch usa âncoras únicas e **aborta** se os arquivos-fonte diferirem da versão v2.1 esperada. A imagem não é publicada antes de passar por `docker build` e validação do código gerado.
- Não modifica os campos `status` dos agentes, nem desbloqueia/reexecuta tarefas.
