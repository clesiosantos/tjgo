import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1] / 'scripts'

def load(name, path):
    sp = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(m)
    return m

patch = load('patch_habblaud', ROOT / 'patch_habblaud.py')
collector = load('collect_activity', ROOT / 'collect_activity.py')


def server_fixture():
    return '\n'.join([
        patch.SERVER_IMPORT,
        'class Hub {',
        '  start(){', patch.SERVER_START, '  }',
        '  stop(){', patch.SERVER_STOP, '  }',
        '  attach(){', patch.SERVER_ATTACH, '  }',
        patch.SERVER_METHOD,
        '  }', '}',
    ])


class Tests(unittest.TestCase):
    def test_feed_avoids_prompts(self):
        inputs = [
            {'id':'11','at':1234000,'agent_id':'id1','agent_name':'Marina Costa',
             'issue_identifier':'SHA-13','event_type':'tool.execution.started',
             'run_status':'running','payload':'TOP_SECRET'},
            {'id':'12','at':1234001,'agent_id':'id1','agent_name':'Marina Costa',
             'issue_identifier':'SHA-13','event_type':'item.delta',
             'run_status':'running','payload':'TOP_SECRET'}
        ]
        feed = collector.make_feed(inputs,{})
        self.assertEqual(len(feed),1)
        self.assertEqual(feed[0]['agentName'],'Marina Costa')
        self.assertIn('SHA-13',feed[0]['activity']['text'])
        self.assertNotIn('TOP_SECRET',str(feed))

    def test_patch_anchors_fail_closed(self):
        with self.assertRaises(ValueError):
            patch.patched('invalid','invalid')

    def test_patch_accepts_actual_v21_anchor_and_keeps_mapping(self):
        server, client = patch.patched(server_fixture(), patch.CLIENT_ANCHOR)
        self.assertIn('private pollSharkFeed()', server)
        self.assertIn('mapSharkFeed(f, this.sharkAliases)', client)
        self.assertIn("shark-activity:", client)
        self.assertIn('shark-roster:', client)
        self.assertNotIn(patch.CLIENT_ANCHOR, client)

    def test_patch_does_not_reapply(self):
        server, client = patch.patched(server_fixture(), patch.CLIENT_ANCHOR)
        with self.assertRaises(ValueError):
            patch.patched(server, client)

    def test_original_unpatched_store_is_rejected(self):
        with self.assertRaises(ValueError):
            patch.patched(server_fixture(), '    const fresh = items.filter((f) => !known.has(f.id));')

    def test_labels(self):
        self.assertNotIn('item.delta',collector.LABELS)
        self.assertIn('run.terminal',collector.LABELS)

if __name__=='__main__':
    unittest.main()
