#!/usr/bin/env bash
set -euo pipefail
umask 077

PKG="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="${HABBLAUD_SRC:-/opt/ai-stack/habblaud-src}"
STACK="${SHARK_STACK:-/opt/ai-stack/stack.yml}"
DATA="${SHARK_DATA_DIR:-/data/ai-stack/habblaud}"
SYSTEMD=/etc/systemd/system

need() { command -v "$1" >/dev/null || { echo "ERRO: falta $1" >&2; exit 1; }; }
preflight() {
  need docker; need python3; need systemctl
  test -f "$SRC/server/http/sse.ts" || { echo 'ERRO: não encontrei fontes Habblaud' >&2; exit 1; }
  test -f "$SRC/client/src/net/store.ts"
  test -f "$STACK"
  docker service inspect ai_habblaud >/dev/null
  test -d "$DATA"
  python3 "$PKG/scripts/patch_habblaud.py" --check-only "$SRC"
  python3 "$PKG/scripts/collect_activity.py" --dry-run
}

prepare() {
  preflight
  echo 'VALIDAÇÃO PRÉVIA APROVADA — sem alterações.'
}

install() {
  preflight
  python3 "$PKG/scripts/patch_habblaud.py" "$SRC"
  cp -a "$PKG/scripts/shark-paperclip-activity.service" "$SYSTEMD/"
  cp -a "$PKG/scripts/shark-paperclip-activity.timer" "$SYSTEMD/"
  systemctl daemon-reload
  systemctl start shark-paperclip-activity.service
  systemctl enable --now shark-paperclip-activity.timer
  test -s "$DATA/shark-activity.json"
  echo 'COLETOR INSTALADO — feed sanitizado gerado.'
}

build() {
  need docker; test -f "$SRC/server/http/sse.ts"
  grep -q 'private pollSharkFeed()' "$SRC/server/http/sse.ts" || {
    echo 'ERRO: instale o patch primeiro' >&2; exit 1;
  }
  cat "$SRC/Dockerfile" > "$SRC/Dockerfile.shark-v2.2"
  cat >> "$SRC/Dockerfile.shark-v2.2" <<'EOF'

# Shark v2.2: preserva ajuste anterior para permissões de leitura do Habblaud
USER root
RUN find /app -type d -exec chmod a+rx {} + && find /app -type f -exec chmod a+r {} +
USER node
EOF
  local img="habblaud:shark-1.0.3-v2.2-$(date +%Y%m%d-%H%M%S)"
  docker build -f "$SRC/Dockerfile.shark-v2.2" --tag "$img" "$SRC"
  docker run --rm --entrypoint node "$img" --check dist/server/index.js
  docker run --rm --entrypoint sh "$img" -c 'test -r /app/package.json; grep -q shark-activity.json /app/dist/server/index.js'
  printf '%s\n' "$img" > "$PKG/built-image.txt"
  echo "IMAGEM HOMOLOGADA PARA DEPLOY: $img"
}

persist_image() {
  local img="$1"
  python3 - "$STACK" "$img" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); image=sys.argv[2]
lines=p.read_text().splitlines(keepends=True)
starts=[i for i,s in enumerate(lines) if re.fullmatch(r'  habblaud:\s*',s.strip('\n'))]
if len(starts)!=1: raise SystemExit('ERRO: localização do serviço habblaud ambígua no stack.yml; alterar manualmente')
a=starts[0]
end=next((i for i in range(a+1,len(lines)) if re.match(r'^  [\w-]+:\s*(?:#.*)?$',lines[i])),len(lines))
idx=[i for i in range(a+1,end) if re.match(r'^    image:\s*',lines[i])]
if len(idx)!=1: raise SystemExit('ERRO: linha image ambígua no serviço habblaud; alterar manualmente')
lines[idx[0]]='    image: '+image+'\n'
p.write_text(''.join(lines))
print('stack.yml atualizado de maneira persistente')
PY
}

deploy() {
  need docker
  local img prev
  img="$(cat "$PKG/built-image.txt")"
  docker image inspect "$img" >/dev/null
  prev="$(docker service inspect ai_habblaud --format '{{.Spec.TaskTemplate.ContainerSpec.Image}}')"
  printf '%s\n' "$prev" > "$PKG/previous-image.txt"
  cp -a "$STACK" "$PKG/stack.pre-v2.2.yml"
  docker service update --image "$img" --update-order stop-first --update-failure-action rollback --update-monitor 30s ai_habblaud
  docker service ps ai_habblaud --no-trunc | head -12
  echo 'Aguardando validação manual de UI e feed antes de persistir no stack.yml.'
  echo "Se estiver tudo OK: cd '$PKG' && ./deploy.sh persist"
}

persist() {
  local img
  img="$(cat "$PKG/built-image.txt")"
  local cur
  cur="$(docker service inspect ai_habblaud --format '{{.Spec.TaskTemplate.ContainerSpec.Image}}')"
  test "$cur" = "$img" || { echo "ERRO: serviço atual é $cur, esperado $img" >&2; exit 1; }
  persist_image "$img"
  echo 'IMPORTANTE: em futuros deploys, execute docker stack deploy usando este stack.yml atualizado.'
}

status() {
  docker service ls --filter name=ai_habblaud
  systemctl status shark-paperclip-activity.timer --no-pager -l || true
  python3 - "$DATA/shark-activity.json" <<'PY'
from pathlib import Path
import json,sys,time
p=Path(sys.argv[1]);print('Arquivo:',p,'existe:',p.exists())
if p.exists():
 d=json.loads(p.read_text());print('Eventos:',len(d.get('items',[])),'atualizado há',round((time.time()*1000-d['generatedAt'])/1000),'segundos')
PY
  docker service logs ai_habblaud --tail 15 || true
}

rollback() {
  test -s "$PKG/previous-image.txt" || { echo 'ERRO: imagem anterior indisponível' >&2; exit 1; }
  local prev
  prev="$(cat "$PKG/previous-image.txt")"
  docker service update --image "$prev" --update-order stop-first ai_habblaud
  if test -f "$PKG/stack.pre-v2.2.yml"; then
    cp -a "$PKG/stack.pre-v2.2.yml" "$STACK"
  fi
  systemctl disable --now shark-paperclip-activity.timer || true
  local last
  last="$(find "$SRC/.shark-v22-backup" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | sort | tail -1 || true)"
  if test -n "$last" && test -f "$last/sse.ts"; then
    cp -a "$last/sse.ts" "$SRC/server/http/sse.ts"
    cp -a "$last/store.ts" "$SRC/client/src/net/store.ts"
  fi
  echo "ROLLBACK EXECUTADO para $prev. Banco de dados não alterado."
}

case "${1:-}" in
  prepare) prepare ;;
  install) install ;;
  build) build ;;
  deploy) deploy ;;
  persist) persist ;;
  status) status ;;
  rollback) rollback ;;
  *) echo 'Uso: ./deploy.sh prepare|install|build|deploy|persist|status|rollback'; exit 2;;
esac
