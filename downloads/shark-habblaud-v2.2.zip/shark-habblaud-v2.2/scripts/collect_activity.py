#!/usr/bin/env python3
"""Leitor somente de eventos não sensíveis do Paperclip, para o feed do Habblaud.

Não utiliza prompts, stdout, stderr ou payload dos eventos. Não altera o banco.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time

DATA_DIR = Path(os.environ.get('SHARK_HABBLAUD_DATA_DIR', '/data/ai-stack/habblaud'))
DEST = DATA_DIR / 'shark-activity.json'
LABELS = {
    'tool.execution.started': ('run', '⚙', 'Iniciou execução de ferramenta'),
    'tool.execution.completed': ('done', '✓', 'Concluiu execução de ferramenta'),
    'turn.started': ('think', '◷', 'Iniciou processamento'),
    'turn.completed': ('done', '✓', 'Concluiu etapa de trabalho'),
    'run.terminal': ('done', '✓', 'Execução encerrada'),
    'research.started': ('search', '⌕', 'Iniciou pesquisa'),
    'research.completed': ('done', '✓', 'Concluiu pesquisa'),
}
SQL = r"""
SELECT row_to_json(t)::text
FROM (
  SELECT e.id::text AS id,
         floor(extract(epoch from e.created_at) * 1000)::bigint AS at,
         a.id::text AS agent_id,
         a.name AS agent_name,
         COALESCE(i.identifier,'') AS issue_identifier,
         e.event_type,
         COALESCE(r.status,'') AS run_status
  FROM heartbeat_run_events e
  JOIN heartbeat_runs r ON r.id = e.run_id
  JOIN agents a ON a.id = e.agent_id
  LEFT JOIN issues i ON i.id = r.issue_id
  WHERE e.event_type IN (
    'tool.execution.started',
    'tool.execution.completed',
    'turn.started',
    'turn.completed',
    'run.terminal',
    'research.started',
    'research.completed'
  )
  AND e.created_at >= now() - interval '36 hours'
  ORDER BY e.id DESC
  LIMIT 160
) t
ORDER BY t.id::bigint ASC;
"""

def docker(*args: str, timeout: int = 25) -> str:
    p = subprocess.run(['docker', *args], capture_output=True, text=True, timeout=timeout)
    if p.returncode != 0:
        raise RuntimeError(f'Falha no Docker (codigo {p.returncode}): {p.stderr[:400]}')
    return p.stdout


def db_container() -> str:
    ids = docker('ps', '-q', '--filter', 'label=com.docker.swarm.service.name=ai_postgres').split()
    if len(ids) != 1:
        # fallback, caso a label não esteja disponível no host
        ids = docker('ps', '-q', '--filter', 'name=ai_postgres').split()
    if len(ids) != 1:
        raise RuntimeError(f'Esperado um Postgres, encontrados {len(ids)} containers')
    return ids[0]


def fetch_records() -> list[dict]:
    cid = db_container()
    lines = docker('exec', '-i', cid, 'psql', '-X', '-U', 'paperclip', '-d', 'paperclip',
                   '-v', 'ON_ERROR_STOP=1', '-At', '-c', SQL, timeout=45).splitlines()
    return [json.loads(line) for line in lines if line.strip()]


def department_names() -> dict[str, str]:
    try:
        raw = json.loads((DATA_DIR / 'shark-paperclip.json').read_text())
        result = {}
        for agent in raw.get('agents', []):
            id_ = str(agent.get('id') or agent.get('agentId') or '')
            dept = agent.get('department') or agent.get('departmentName') or agent.get('roomName')
            if isinstance(dept, dict):
                dept = dept.get('name')
            if id_ and isinstance(dept, str) and dept:
                result[id_] = dept[:80]
        return result
    except (OSError, ValueError, TypeError):
        return {}


def make_feed(records: list[dict], departments: dict[str, str]) -> list[dict]:
    result = []
    for row in records:
        typ = row.get('event_type')
        if typ not in LABELS:
            continue
        kind, icon, label = LABELS[typ]
        ident = str(row.get('issue_identifier') or '').strip()
        at = int(row['at'])
        agent_id = str(row['agent_id'])
        rid = str(row['id'])
        agent_name = str(row.get('agent_name') or 'Agente Paperclip')[:90]
        if typ == 'run.terminal':
            status = str(row.get('run_status') or '').lower()
            if status == 'succeeded':
                label = 'Execução concluída'
            elif status in ('failed', 'cancelled', 'timed_out'):
                label, kind, icon = 'Execução interrompida', 'error', '!'
        text = label + (f' · {ident}' if ident else '')
        result.append({
            'id': 'shark-activity:' + rid,
            'agentId': 'paperclip-agent:' + agent_id,
            'roomId': 'paperclip-room:' + agent_id,
            'agentName': agent_name,
            'roomName': departments.get(agent_id, 'Shark Innovation Office'),
            'activity': {
                'id': 'shark-activity:' + rid,
                'kind': kind,
                'icon': icon,
                'text': text[:110],
                'at': at,
            },
        })
    return result[-160:]


def write_atomic(output: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmpname = tempfile.mkstemp(prefix='.shark-activity.', suffix='.tmp', dir=str(DATA_DIR))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as fp:
            json.dump(output, fp, ensure_ascii=False, separators=(',', ':'))
            fp.write('\n')
            fp.flush()
            os.fsync(fp.fileno())
        os.chmod(tmpname, 0o644)
        os.replace(tmpname, DEST)
    finally:
        if os.path.exists(tmpname):
            os.unlink(tmpname)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    data = make_feed(fetch_records(), department_names())
    result = {'schema': 1, 'generatedAt': int(time.time() * 1000), 'items': data}
    if not args.dry_run:
        write_atomic(result)
    print(f'Shark activity: {len(data)} eventos sanitizados, dry_run={args.dry_run}')


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'ERRO: {exc}', file=sys.stderr)
        raise SystemExit(1)
