#!/usr/bin/env python3
"""Extensão compatível com o SSE de Habblaud v1.0.3 (+ Shark v2.1).

Faz backup, verifica âncoras e evita instalar duas vezes.
"""
from pathlib import Path
import argparse
import shutil
import time

SERVER_IMPORT = "import type { OfficeSnapshot } from '../../shared/types';"
SERVER_START = "    this.pinger.unref?.();"
SERVER_STOP = "    if (this.pinger) clearInterval(this.pinger);"
SERVER_ATTACH = "    res.write(frame('feed', this.office.recentFeed(50)));"
SERVER_METHOD = "  private writeAll(chunk: string): void {"
CLIENT_ANCHOR = "    const fresh = items.filter((f) => !known.has(f.id));"

SERVER_CODE = r'''
  // Shark v2.2: feed sanitizado do Paperclip, independente dos transcripts Codex.
  private sharkTimer: ReturnType<typeof setInterval> | null = null;
  private sharkFeed: FeedItem[] = [];
  private sharkSeen = new Set<string>();
  private sharkInitialized = false;

  private readSharkFeed(): FeedItem[] | null {
    try {
      const obj = JSON.parse(readFileSync('/data/shark-activity.json', 'utf8')) as {
        schema?: number;
        generatedAt?: number;
        items?: FeedItem[];
      };
      if (obj.schema !== 1 || typeof obj.generatedAt !== 'number' ||
          Math.abs(Date.now() - obj.generatedAt) > 180_000 || !Array.isArray(obj.items)) return null;
      return obj.items.filter((f): f is FeedItem =>
        typeof f?.id === 'string' && f.id.startsWith('shark-activity:') &&
        typeof f.agentName === 'string' && typeof f.agentId === 'string' &&
        !!f.activity && typeof f.activity.at === 'number' &&
        typeof f.activity.text === 'string'
      ).slice(-160);
    } catch {
      return null;
    }
  }

  private pollSharkFeed(): void {
    const items = this.readSharkFeed();
    if (!items) return;
    const fresh = items.filter((x) => !this.sharkSeen.has(x.id));
    for (const item of items) this.sharkSeen.add(item.id);
    if (this.sharkSeen.size > 2000) {
      this.sharkSeen = new Set(items.map((x) => x.id));
    }
    this.sharkFeed = items;
    if (!this.sharkInitialized) {
      this.sharkInitialized = true;
      if (this.clients.size && items.length) this.writeAll(frame('feed', items.slice(-50)));
    } else if (fresh.length) {
      this.writeAll(frame('feed', fresh));
    }
  }
'''

CLIENT_CODE = r'''    const fresh = items.filter((f) => !known.has(f.id)).map((f) => {
      if (!f.id.startsWith('shark-activity:')) return f;
      // O Shark v2.1 projeta os agentes reais no snapshot do cliente.
      const match = this.snapshot?.agents.find((a) => a.name === f.agentName);
      if (!match) return f;
      const room = this.snapshot?.rooms.find((r) => r.id === match.roomId);
      return {
        ...f,
        agentId: match.id,
        roomId: match.roomId,
        roomName: room?.name ?? f.roomName,
        account: match.account,
      };
    });'''


def require_one(s: str, token: str, file: Path):
    n = s.count(token)
    if n != 1:
        raise ValueError(f'{file}: âncora não encontrada de maneira inequívoca ({n}) {token!r}')


def patched(server: str, client: str) -> tuple[str, str]:
    if 'private pollSharkFeed()' in server or "shark-activity:" in client:
        raise ValueError('Patch v2.2 já aplicado ou conflito com outro patch')
    for s, a, n in [
        (server, SERVER_IMPORT, 'server'),
        (server, SERVER_START, 'server'),
        (server, SERVER_STOP, 'server'),
        (server, SERVER_ATTACH, 'server'),
        (server, SERVER_METHOD, 'server'),
        (client, CLIENT_ANCHOR, 'client'),
    ]:
        if s.count(a) != 1:
            raise ValueError(f'Âncora ambígua em {n}: {a!r}; ocorrências: {s.count(a)}')
    server = server.replace(SERVER_IMPORT, "import { readFileSync } from 'node:fs';\nimport type { FeedItem, OfficeSnapshot } from '../../shared/types';", 1)
    server = server.replace(SERVER_START, SERVER_START + "\n    this.pollSharkFeed();\n    this.sharkTimer = setInterval(() => this.pollSharkFeed(), 5000);\n    this.sharkTimer.unref?.();", 1)
    server = server.replace(SERVER_STOP, SERVER_STOP + '\n    if (this.sharkTimer) clearInterval(this.sharkTimer);', 1)
    server = server.replace(SERVER_ATTACH, SERVER_ATTACH + "\n    if (this.sharkFeed.length) res.write(frame('feed', this.sharkFeed.slice(-50)));", 1)
    server = server.replace(SERVER_METHOD, SERVER_CODE + '\n' + SERVER_METHOD, 1)
    client = client.replace(CLIENT_ANCHOR, CLIENT_CODE, 1)
    return server, client


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('source_root', type=Path)
    ap.add_argument('--check-only', action='store_true')
    args = ap.parse_args()
    src = args.source_root
    sf = src / 'server/http/sse.ts'
    cf = src / 'client/src/net/store.ts'
    server = sf.read_text()
    client = cf.read_text()
    if 'sharkFeedItem' not in client:
        raise SystemExit('ABORTADO: personalização Shark v2.1 não detectada no store.ts')
    if 'shark-paperclip' not in (src / 'server/http/app.ts').read_text():
        raise SystemExit('ABORTADO: personalização Shark v2.1 não detectada no app.ts')
    ns, nc = patched(server, client)
    if args.check_only:
        print('Âncoras verificadas, nenhuma alteração realizada')
        return
    backup = src / '.shark-v22-backup' / time.strftime('%Y%m%d-%H%M%S')
    backup.mkdir(parents=True, exist_ok=False)
    shutil.copy2(sf, backup / 'sse.ts')
    shutil.copy2(cf, backup / 'store.ts')
    try:
        sf.write_text(ns)
        cf.write_text(nc)
    except Exception:
        shutil.copy2(backup / 'sse.ts', sf)
        shutil.copy2(backup / 'store.ts', cf)
        raise
    print(f'Patch aplicado; backup: {backup}')


if __name__ == '__main__':
    main()
