# Shark Innovation Office v2 — Habblaud 1.0.3

**Base:** instalação do Habblaud v1.0.3 com Shark Office v1 já aplicada, em `/opt/ai-stack/habblaud-src`.

## Conteúdo
- `install_patch.py`: acrescenta salas corporativas permanentes na simulação do navegador; distribui execuções reais de workspaces conhecidos para as salas correspondentes; coloca o painel de departamentos na barra lateral; altera o nome exibido de agentes principais do workspace `alexander-ceo`.
- `overlay/shark-departments.ts`: cores, nomes e regras de associação por workspace.
- `deploy.sh`: backup, patch, Docker build, validação YAML, atualização da imagem no Docker Swarm.
- `rollback.sh`: restaura arquivos-fonte e `stack.yml` a partir de backup e republica versão anterior.

## Comportamento
As quatro salas permanentes são criadas na **simulação do cliente**, não na base de dados do Habblaud ou do Paperclip. O cabeçalho do Habblaud continua mostrando a quantidade de **salas com sessões reais**, não as quatro salas institucionais.

- Slot 0: Diretoria Executiva; `alexander-ceo`, `diretoria-executiva`, `ceo-innovation`.
- Slot 1: Inovação e Produtos; `inovacao-produtos`, `innovation-products`, `pesquisa-produtos`.
- Slot 2: Marketing e Growth; `marketing-growth`, `marketing-digital`.
- Slot 3: Tecnologia e Web; `shark-dev`, `tecnologia-web`, `shark-web`.

As execuções dos projetos associados são mostradas dentro da sala física do departamento e continuam sendo agentes **reais**. Projetos não classificados abrem outras salas, sem interferir nos quatro espaços reservados.

Somente sessões Codex efetivamente detectadas de um workspace cujo caminho contenha `alexander-ceo` são exibidas com nome e cargo **Alexander Morgan / CEO de Inovação**. Nenhum agente fictício é gerado. A renomeação é visual: não modifica o cadastro do Paperclip.

Os diretórios da autenticação ChatGPT, volumes, labels do Traefik e variáveis de execução não são alterados.

## Instalar
No Mac (na pasta onde o ZIP foi salvo):
```bash
scp shark-habblaud-v2.zip root@195.26.242.208:/opt/ai-stack/
```
Na VPS:
```bash
cd /opt/ai-stack
unzip -o shark-habblaud-v2.zip
bash /opt/ai-stack/shark-habblaud-v2/deploy.sh
```
O processo executa `docker build`, que inclui `npm ci` e `npm run build` no Dockerfile oficial. Nenhuma imagem é publicada caso o build falhe.

## Verificar
```bash
docker stack services ai
docker service ps ai_habblaud --no-trunc
docker service logs ai_habblaud --since 5m --tail 70
```
Abra `https://office.inovacao.sharksolucoes.com.br` e faça atualização forçada no navegador. Se a tela ficar antiga, confira a imagem ativa:
```bash
docker service inspect ai_habblaud --format '{{.Spec.TaskTemplate.ContainerSpec.Image}}'
```

## Rollback
O deploy imprime o caminho do backup como `/opt/ai-stack/backups/shark-v2-YYYYMMDD-HHMMSS`.
```bash
bash /opt/ai-stack/shark-habblaud-v2/rollback.sh /opt/ai-stack/backups/shark-v2-YYYYMMDD-HHMMSS
```
Rollback não apaga `sessions`, `/data/ai-stack/habblaud`, PostgreSQL ou credenciais.

## Limitações
- O mapa é personalização do frontend; **não** cria departamentos no Paperclip nem sincroniza tarefas/organograma por API.
- O contador original de salas continua sendo a contagem de projetos reais; o painel de departamentos mostra agentes reais por departamento.
- Não foi possível executar o Docker build na máquina que preparou o pacote, pois o checkout completo e um daemon Docker da VPS não estão acessíveis neste ambiente. O script de deploy valida o build antes de publicar.
