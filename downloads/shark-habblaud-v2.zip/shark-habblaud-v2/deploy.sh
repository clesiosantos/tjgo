#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=/opt/ai-stack
SRC="$ROOT/habblaud-src"
PACK="$(cd "$(dirname "$0")" && pwd)"
IMAGE='habblaud:shark-1.0.3-v2'
cd "$ROOT"
test -f "$SRC/client/src/ui/shark-office.ts" || { echo 'ERRO: Shark Office v1 não instalada'; exit 1; }
test -f "$ROOT/.env" && test -f "$ROOT/stack.yml" || { echo 'ERRO: .env ou stack.yml ausente'; exit 1; }
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$ROOT/backups/shark-v2-$TIMESTAMP"
mkdir -p "$BACKUP/source"
# Snapshot apenas dos arquivos alterados; estado Habblaud e chaves nao sao copiados
FILES=(client/src/world/sim/sim.ts client/src/world/index.ts client/src/net/store.ts client/src/ui/index.ts client/src/ui/shark-office.ts client/src/ui/shark-office.css client/src/world/layout/shark-departments.ts)
for relative in "${FILES[@]}"; do
  if [[ -f "$SRC/$relative" ]]; then
    mkdir -p "$BACKUP/source/$(dirname "$relative")"
    cp -p "$SRC/$relative" "$BACKUP/source/$relative"
  else
    printf '%s\n' "$relative" >> "$BACKUP/new-files.txt"
  fi
done
cp -p "$ROOT/stack.yml" "$BACKUP/stack.yml"
printf 'Backup criado em %s\n' "$BACKUP"
rollback_local() {
  echo 'Falha no procedimento; restaurando código e stack.yml do backup.' >&2
  "$PACK/rollback.sh" "$BACKUP" || true
}
trap rollback_local ERR
python3 "$PACK/install_patch.py" "$SRC"
echo '== Docker build (inclui npm ci + npm run build) =='
docker build -t "$IMAGE" "$SRC"
docker image inspect "$IMAGE" >/dev/null
python3 - "$ROOT/stack.yml" "$IMAGE" <<'PY'
import pathlib, re, sys
p=pathlib.Path(sys.argv[1]); image=sys.argv[2]; s=p.read_text()
needle=r'(?m)^(  habblaud:\s*\n(?:.*\n)*?    image: )[^\n]+'
m=re.search(needle,s)
if not m: raise SystemExit('Serviço habblaud e sua imagem não encontrados no YAML')
s=s[:m.start()]+m.group(1)+image+s[m.end():]
p.write_text(s)
PY
set -a
# shellcheck disable=SC1091
source "$ROOT/.env"
set +a
docker stack config -c "$ROOT/stack.yml" >/dev/null
echo '== Publicando nova imagem Docker Swarm =='
docker stack deploy -c "$ROOT/stack.yml" ai
sleep 4
docker service ps ai_habblaud --no-trunc
printf '\nImagens: anterior no backup do stack.yml, nova %s\n' "$IMAGE"
printf 'Backup/rollback: %s\n' "$BACKUP"
printf 'Para voltar: bash %s/rollback.sh %s\n' "$PACK" "$BACKUP"
trap - ERR
