#!/usr/bin/env python3
"""Aplica v2 sobre Shark Office v1, com pontos de ancoragem explícitos.
Uso: python3 install_patch.py /opt/ai-stack/habblaud-src
"""
import pathlib, shutil, sys
root = pathlib.Path(sys.argv[1]).resolve()
if '"version": "1.0.3"' not in (root/'package.json').read_text():
    raise SystemExit('ERRO: somente Habblaud 1.0.3')
ui = root/'client/src/ui'
if 'mountSharkOffice(root, store' not in (ui/'index.ts').read_text():
    raise SystemExit('ERRO: Shark Office v1 não encontrada. Instale v1 antes.')
source = pathlib.Path(__file__).resolve().parent / 'overlay'
shutil.copy2(source/'shark-departments.ts', root/'client/src/world/layout/shark-departments.ts')

def patch(path, needle, replacement, signature):
    p = root/path
    t = p.read_text()
    if signature in t:
        print('Já aplicado:', path, signature)
        return
    if t.count(needle) != 1:
        raise SystemExit(f'ERRO: âncora não encontrada exatamente uma vez: {path}: {needle[:100]}')
    p.write_text(t.replace(needle, replacement, 1))

# 4 ambientes físicos sempre existentes; slots 0-3 reservados; salas de projeto reais a partir de 4.
patch('client/src/world/sim/sim.ts',
      "import { layoutProjectRoom } from '../layout/room';",
      "import { layoutProjectRoom } from '../layout/room';\nimport { SHARK_DEPARTMENTS, sharkDepartmentForPath } from '../layout/shark-departments';",
      'import { SHARK_DEPARTMENTS, sharkDepartmentForPath }')
# Sessões de projetos conhecidos ocupam a sala fixa do departamento correspondente.
# O mapeamento ocorre APENAS na simulação visual; no servidor e na sidebar são originais.
patch('client/src/world/sim/sim.ts',
      '    this.lastSnapshot = input;',
      '''    const departmentByRoom = new Map(snap.rooms
      .map((r) => [r.id, sharkDepartmentForPath(r.path)] as const)
      .filter((entry): entry is readonly [string, string] => !!entry[1]));
    if (departmentByRoom.size) snap = {
      ...snap,
      rooms: snap.rooms.filter((r) => !departmentByRoom.has(r.id)),
      agents: snap.agents.map((a) => {
        const department = departmentByRoom.get(a.roomId);
        return department ? { ...a, roomId: department } : a;
      }),
    };
    this.lastSnapshot = input;''',
      'const departmentByRoom = new Map(snap.rooms')

patch('client/src/world/sim/sim.ts',
      '    let layoutDirty = false;\n    const listed = new Set<string>();',
      '    let layoutDirty = this.ensureSharkDepartments(now);\n    const listed = new Set<string>(SHARK_DEPARTMENTS.map((d) => d.id));',
      'let layoutDirty = this.ensureSharkDepartments(now)')
anchor = '  private createRoom(r: RoomInfo, first: boolean, now: number): RoomState {'
implementation = '''  /** Salas corporativas visuais. Não entram no snapshot de agentes reais do servidor. */
  private ensureSharkDepartments(now: number): boolean {
    if (this.rooms.has(SHARK_DEPARTMENTS[0].id)) return false;
    for (const [slot, d] of SHARK_DEPARTMENTS.entries()) {
      const theme: RoomTheme = {
        carpet: d.carpet,
        carpet2: d.carpet2,
        accent: d.accent,
        wall: { base: '#d6e8ed', trim: '#3b6b82', pattern: d.pattern },
        deskVariant: 'wood',
        chairVariant: 'black',
      };
      const info: RoomInfo = {
        id: d.id, name: d.name, path: `/shark/departments/${d.id.split(':')[1]}`,
        slot, seed: d.seed, createdAt: now,
      };
      const layout = layoutProjectRoom({ id: d.id, slot, seed: d.seed }, theme);
      const room = new RoomState(info, theme, layout, 'ready', now, true, slot);
      this.rooms.set(d.id, room);
    }
    return true;
  }

'''
patch('client/src/world/sim/sim.ts', anchor, implementation+anchor, 'private ensureSharkDepartments(now: number)')
# Navegação ao cenário do departamento não tenta abrir gaveta de sala ausente do backend.
patch('client/src/ui/index.ts',
      "mountSharkOffice(root, store, (roomId) => ctx.select({ type: 'room', id: roomId }, { focus: true }));",
      "mountSharkOffice(root, store, (roomId) => {\n    if (roomId.startsWith('shark:')) world.focusRoom(roomId);\n    else ctx.select({ type: 'room', id: roomId }, { focus: true });\n  });",
      "if (roomId.startsWith('shark:')) world.focusRoom(roomId)")
# Renomeie exclusivamente sessões do workspace oficial do CEO; não confundir projetos manuais.
patch('client/src/net/store.ts',
      '    this.snapshot = snap;\n    this.agentIndex = new Map(snap.agents.map((a) => [a.id, a]));',
      '''    const ceoIds = new Set(snap.rooms.filter((r) => /(^|\\/|\\\\)alexander-ceo(?:\\/|\\\\|$)/i.test(r.path)).map((r) => r.id));
    const named = ceoIds.size ? { ...snap, agents: snap.agents.map((a) =>
      ceoIds.has(a.roomId) && a.kind === 'main' ? { ...a, name: 'Alexander Morgan', role: 'CEO de Inovação' } : a,
    ) } : snap;
    this.snapshot = named;
    this.agentIndex = new Map(named.agents.map((a) => [a.id, a]));''',
      'const ceoIds = new Set(snap.rooms.filter')
patch('client/src/net/store.ts',
      "    this.emit('snapshot', snap);",
      "    this.emit('snapshot', this.snapshot!);",
      "this.emit('snapshot', this.snapshot!)")

# Evita abrir a gaveta de sala que não existe no snapshot do backend.
patch('client/src/world/index.ts',
      "if (room.present && !room.ghost && inRect(room.layout.rect, tx, ty))",
      "if (room.present && !room.ghost && !room.id.startsWith('shark:') && inRect(room.layout.rect, tx, ty))",
      "!room.id.startsWith('shark:')")
# Os botões do painel físico devem levar às salas permanentes, mesmo vazias.
p = ui/'shark-office.ts'; text = p.read_text()
if "id: 'shark:ceo'" not in text:
    for old, new in [
      ("name: 'Diretoria Executiva', short:", "id: 'shark:ceo', name: 'Diretoria Executiva', short:"),
      ("name: 'Inovação e Produtos', short:", "id: 'shark:innovation', name: 'Inovação e Produtos', short:"),
      ("name: 'Marketing e Growth', short:", "id: 'shark:marketing', name: 'Marketing e Growth', short:"),
      ("name: 'Tecnologia e Web', short:", "id: 'shark:technology', name: 'Tecnologia e Web', short:"),
    ]:
        if old not in text: raise SystemExit('ERRO: formato v1 mudou: '+old)
        text = text.replace(old,new)
    text = text.replace("interface Department {\n", "interface Department {\n  id: string;\n")
    text = text.replace("btn.disabled = matches.length === 0;", "btn.disabled = false;")
    text = text.replace("btn.onclick = () => { if (matches[0]) focus(matches[0].id); };", "btn.onclick = () => focus(dep.id);")
    text = text.replace('Departamentos permanentes · salas ativadas por sessões Codex', 'Salas corporativas permanentes · agentes exibidos somente em sessões reais')
    text = text.replace('  root.append(panel);', "  const sidebar = root.querySelector('.ui-sidebar');\n  const scroller = sidebar?.querySelector('.ui-side__scroll');\n  if (sidebar && scroller) sidebar.insertBefore(panel, scroller);\n  else root.append(panel);")
    p.write_text(text)
# Layout compacto na barra lateral: libera a área do mapa.
css = ui/'shark-office.css'
t = css.read_text()
marker = '/* SHARK INNOVATION OFFICE V2: SIDEBAR */'
if marker not in t:
    t += '''
'''+marker+'''
.ui-sidebar .shark-departments { position:relative; right:auto; bottom:auto; width:auto; max-height:330px; flex:none; overflow-y:auto; margin:10px 10px 8px; padding:9px; border-radius:10px; box-shadow:none; z-index:auto; background:rgba(5,22,35,.92); }
.ui-sidebar .shark-departments__heading { padding-bottom:8px; }
.ui-sidebar .shark-departments__heading strong { font-size:10px; }
.ui-sidebar .shark-departments__heading span { display:none; }
.ui-sidebar .shark-department { padding:6px 4px; gap:6px; }
.ui-sidebar .shark-department__code {min-width:36px;height:29px;font-size:10px;}
.ui-sidebar .shark-department__text strong {font-size:11px;}
.ui-sidebar .shark-department__text small {font-size:9px;}
.ui-sidebar .shark-departments__foot {font-size:9px;margin:7px 2px 0;}
@media (max-width:920px) {.ui-sidebar .shark-departments { max-height:36vh; width:auto; }}
'''
    css.write_text(t)

print('OK: v2 aplicada; quatro salas reais no canvas, sem injetar sessões de IA fictícias')
