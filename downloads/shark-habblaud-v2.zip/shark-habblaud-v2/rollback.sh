#!/usr/bin/env bash
set -Eeuo pipefail
BACKUP="${1:?Uso: bash rollback.sh /opt/ai-stack/backups/shark-v2-AAAA...}"
ROOT=/opt/ai-stack
SRC="$ROOT/habblaud-src"
test -f "$BACKUP/stack.yml" || { echo 'Backup invalido'; exit 1; }
cp -p "$BACKUP/stack.yml" "$ROOT/stack.yml"
if [[ -d "$BACKUP/source" ]]; then
  while IFS= read -r -d '' f; do
    rel="${f#"$BACKUP/source/"}"
    mkdir -p "$SRC/$(dirname "$rel")"
    cp -p "$f" "$SRC/$rel"
  done < <(find "$BACKUP/source" -type f -print0)
fi
if [[ -f "$BACKUP/new-files.txt" ]]; then
  while IFS= read -r rel; do rm -f "$SRC/$rel"; done < "$BACKUP/new-files.txt"
fi
cd "$ROOT"
set -a
# shellcheck disable=SC1091
source "$ROOT/.env"
set +a
docker stack config -c stack.yml >/dev/null
docker stack deploy -c stack.yml ai
echo 'Rollback enviado ao Swarm. Verifique: docker service ps ai_habblaud'
