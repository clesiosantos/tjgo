# Shark Paperclip — migração para Docker Compose

Procedimento experimental para a instalação de nó único descrita na conversa. Não foi executado contra a VPS. O script foi validado sintaticamente, mas depende das verificações locais e da homologação. O banco, os volumes e a autenticação atual serão reutilizados; não há alteração intencional de schema. A migração recria as tarefas de PostgreSQL e Traefik durante uma janela de manutenção.

## Pré-requisitos

- `/opt/ai-stack/stack.yml` e sua `.env` existentes; serviços `ai_paperclip`, `ai_postgres`, `ai_traefik` com uma réplica.
- Imagem `paperclip:shark-sandbox-test` derivada do hotfix01 da revisão `c0f132898d2a2677312d8c72096187b27a3d9a38`.
- Perfil AppArmor `shark-paperclip-container (enforce)` carregado; `/opt/ai-stack/paperclip-sandbox/paperclip-seccomp.json` presente.
- Overlay `ai_public` attachable, `ai_ai_backend` existente; Docker Compose moderno (suporte a `gw_priority`).
- Pausar o envio de tarefas e triggers; cancelar/encerrar tentativas automáticas pelo Paperclip, sem alterar o banco diretamente. Certificar-se de que não há trabalhos ativos nem retries agendados. O script verifica o banco, mas essa verificação não constitui um lock distribuído: a janela precisa impedir novas execuções.
- Verificar espaço em disco para o dump e manter backup recente do diretório persistente `/data/ai-stack/paperclip` (inclui credenciais; proteger e não compartilhar). O script faz backup do banco e copia o stack, mas não faz backup integral dos workspaces/arquivos.

## Passos

1. `python3 migrate.py prepare` — lê a configuração real dos serviços e prepara arquivos em `/opt/ai-stack/paperclip-compose`, com permissões privadas. Não modifica serviços. Não compartilhe esses arquivos, pois podem conter credenciais. Se falhar, não prossiga. O procedimento deliberadamente aborta se houver montagem, segredo, configuração ou topologia diferente das previstas.
2. `python3 migrate.py apply` — somente na janela autorizada. Digite `MIGRAR` quando solicitado. Cria overlay privada `shark_paperclip_backend`, faz backup do PostgreSQL, cria o container Compose parado, desliga o Paperclip Swarm antes de iniciar o Compose, associa o PostgreSQL à nova rede, habilita o provider Docker do Traefik com restrição ao Paperclip e inicia o container dedicado. Não publica portas no host. A nova rede é interna; a saída para Internet permanece pela rede `ai_public`.
3. `python3 migrate.py status` — verifica serviços, container dedicado, sandbox e HTTP local. O servidor pode ainda estar inicializando; verifique os logs se necessário. Testar também HTTPS, Run test e uma tarefa curta no Paperclip, incluindo um ciclo de perguntas/respostas. Não concluir que a SHA-2 está corrigida antes de uma execução nativa bem-sucedida.
4. `python3 migrate.py rollback` — após parar novas execuções, desmonta o Compose e restaura o serviço Swarm e as configurações de rede/Traefik. Se o banco estiver indisponível, o script falha de forma segura: restaure primeiro o serviço PostgreSQL; não inicie os dois controladores em paralelo. O rollback não reverte a migração do adaptador do agente para `paperclip_runner`.

## Persistência após homologação

O `stack.yml` original não é editado. O override `stack.override.json` mantém o serviço Paperclip no Swarm com zero réplicas, desativa a rota Swarm antiga, acrescenta a rede dedicada ao PostgreSQL e preserva os argumentos Traefik com o novo provider. Valide a mesclagem primeiro, incluindo versões de imagem fixadas e customizações do Habblaud. Em deploys futuros use o stack com o override **somente enquanto o Compose estiver em produção**; nunca rode apenas o stack original, pois isso pode iniciar uma segunda instância do Paperclip. Não execute o deploy completo só para persistir a configuração: ele já foi aplicada pela migração. Se houver rollback, volte ao stack original sem o override.

```bash
cd /opt/ai-stack
set -a; source .env; set +a
docker stack config -c stack.yml -c paperclip-compose/stack.override.json >/dev/null
# Somente em uma futura janela de deploy, depois de conferir imagens e replicas:
# docker stack deploy --resolve-image never -c stack.yml -c paperclip-compose/stack.override.json ai
```

## Verificações funcionais e segurança

- `docker logs --tail 80 ai_paperclip_runtime` (revisar localmente; não divulgar tokens).
- URL: `https://agents.inovacao.sharksolucoes.com.br`.
- AppArmor e Seccomp específicos, usuário `1000:1000`, sem capabilities, `no-new-privileges`.
- Nenhum Docker socket será montado no Paperclip; somente as montagens de dados previamente configuradas dentro de `/data/ai-stack/` são aceitas.
- O provider Docker do Traefik tem `exposedByDefault=false` e constraint `shark.traefik.standalone=true`. A porta 5432 não é publicada na Internet. A nova rede privada é attachable, acessível a administradores Docker autorizados.
- Verificar a sincronização do Habblaud, sobretudo se algum script usa `docker service inspect ai_paperclip` em vez de localizar o container `ai_paperclip_runtime`; a persistência de sessão continua no volume original.
- Os perfis de segurança importados foram testados com Bubblewrap, não constituem certificação de segurança de todo o Paperclip. Não executar agentes sem permissões apropriadas nem montar diretórios host sensíveis.
