#!/usr/bin/env python3
"""Prepare and migrate the single-node Shark Paperclip deployment. Run as root."""
import argparse, json, os, pathlib, shlex, shutil, subprocess, sys, time, urllib.parse

ROOT=pathlib.Path('/opt/ai-stack')
WORK=ROOT/'paperclip-compose'
SANDBOX=ROOT/'paperclip-sandbox'
NETWORK='shark_paperclip_backend'
IMAGE='paperclip:shark-sandbox-test'
COMPOSE=WORK/'compose.json'
OVERRIDE=WORK/'stack.override.json'
STATE=WORK/'original.json'
NAME='ai_paperclip_runtime'
PROJECT='shark-paperclip'
ISSUE='https://agents.inovacao.sharksolucoes.com.br'

os.umask(0o077)

def cmd(*a, capture=True, inp=None):
    p=subprocess.run(a, input=inp, text=True, stdout=subprocess.PIPE if capture else None, stderr=subprocess.PIPE if capture else None)
    if p.returncode:
        # Avoid leaking credentials from the Docker/Compose command or output.
        raise RuntimeError(f'Falha: {a[0]} {a[1] if len(a)>1 else ""} (RC {p.returncode}). Consulte os logs localmente.')
    return p.stdout.strip() if capture else ''

def dock(*a, **kw): return cmd('docker',*a,**kw)
def service(name): return json.loads(dock('service','inspect',name))[0]
def container(cid): return json.loads(dock('inspect',cid))[0]
def cid_for(svc):
    rows=dock('ps','-q','--filter',f'label=com.docker.swarm.service.name={svc}').splitlines()
    if len(rows)!=1: raise RuntimeError(f'Esperado exatamente um container ativo: {svc}; encontrado {len(rows)}')
    return rows[0]
def spec(s): return s['Spec']['TaskTemplate']['ContainerSpec']
def existing_network(name):
    ids=dock('network','ls','--filter',f'name=^{name}$','--format','{{.Name}}').splitlines()
    return name in ids

def write_json(path, value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
    os.chmod(path,0o600)

def escape(value):
    # Compose YAML/JSON interpolates $ even in already-resolved values.
    if isinstance(value,str): return value.replace('$','$$')
    if isinstance(value,list): return [escape(x) for x in value]
    if isinstance(value,dict): return {k:escape(v) for k,v in value.items()}
    return value

def compose(*a, **kw): return dock('compose','-p',PROJECT,'-f',str(COMPOSE),*a,**kw)

def assert_idle():
    db=cid_for('ai_postgres')
    query="SELECT count(*) FROM heartbeat_runs WHERE finished_at IS NULL OR status NOT IN ('succeeded','failed','cancelled','timed_out','interrupted') OR scheduled_retry_at > now();"
    result=dock('exec',db,'psql','-X','-U','paperclip','-d','paperclip','-v','ON_ERROR_STOP=1','-Atc',query)
    if result!='0': raise RuntimeError(f'Existem {result} execucoes abertas ou retries agendados. Nao migre ate resolver/pausar as execucoes.')

def prep():
    if STATE.exists(): raise RuntimeError('Migracao anterior preparada. Nao sobrescreva os arquivos; use status ou rollback.')
    if NAME in dock('ps','-a','--format','{{.Names}}').splitlines(): raise RuntimeError('Container dedicado ja existe.')
    if not (SANDBOX/'paperclip-seccomp.json').is_file(): raise RuntimeError('Perfil Seccomp nao encontrado.')
    profiles=pathlib.Path('/sys/kernel/security/apparmor/profiles').read_text()
    if 'shark-paperclip-container (enforce)' not in profiles: raise RuntimeError('Perfil AppArmor nao esta em enforce.')
    dock('image','inspect',IMAGE)
    # This package intentionally supports the simple single-node deployment only.
    if len(dock('node','ls','-q').splitlines())!=1: raise RuntimeError('Este procedimento foi preparado para um Swarm de um no.')
    p=service('ai_paperclip'); d=service('ai_postgres'); t=service('ai_traefik')
    for s in (p,d,t):
        if s['Spec']['Mode'].get('Replicated',{}).get('Replicas')!=1: raise RuntimeError('Esperada uma replica em cada servico.')
    pc=container(cid_for('ai_paperclip')); tc=container(cid_for('ai_traefik'))
    cfg=pc['Config']; hc=pc['HostConfig']; sc=spec(p)
    live_img=json.loads(dock('image','inspect',pc['Image']))[0]
    new_img=json.loads(dock('image','inspect',IMAGE))[0]
    rev=(live_img.get('Config',{}).get('Labels') or {}).get('org.opencontainers.image.revision')
    if rev!='c0f132898d2a2677312d8c72096187b27a3d9a38' or (new_img.get('Config',{}).get('Labels') or {}).get('org.opencontainers.image.revision')!=rev:
        raise RuntimeError('Revisao da imagem nao corresponde ao hotfix homologado.')
    if (new_img.get('Config',{}).get('Labels') or {}).get('shark.hotfix')!='runner-platform-01':
        raise RuntimeError('Imagem de sandbox nao contem o hotfix de plataforma esperado.')
    if sc.get('Secrets') or sc.get('Configs') or (sc.get('Privileges') or {}).get('CredentialSpec'):
        raise RuntimeError('Paperclip usa secrets/configs Swarm. Exige conversao especifica; nenhum segredo sera extraido.')
    if (p.get('Endpoint',{}).get('Spec',{}).get('Ports') or hc.get('Privileged') or hc.get('Devices')):
        raise RuntimeError('Paperclip tem portas publicadas, dispositivos ou modo privilegiado inesperados.')
    env=dict(x.split('=',1) for x in cfg.get('Env',[]) if '=' in x)
    url=env.get('DATABASE_URL') or env.get('PAPERCLIP_DATABASE_URL') or ''
    try: host=urllib.parse.urlsplit(url).hostname
    except ValueError: host=None
    if host not in {'postgres','ai_postgres'}: raise RuntimeError('Hostname do banco nao e postgres/ai_postgres; exige ajuste manual (URL nao exibida).')
    if not any(m.get('Destination')=='/paperclip' and m.get('RW') for m in pc.get('Mounts',[])):
        raise RuntimeError('Persistencia /paperclip nao encontrada.')
    vols=[]
    for m in sc.get('Mounts',[]) or []:
        ty=m['Type']; target=m['Target']
        if ty=='tmpfs':
            opt=m.get('TmpfsOptions') or {}; size=opt.get('SizeBytes'); mode=opt.get('Mode')
            entry={'type':'tmpfs','target':target}
            if size or mode: entry['tmpfs']={**({'size':size} if size else {}),**({'mode':mode} if mode else {})}
            vols.append(entry); continue
        if ty!='bind' or not m.get('Source','').startswith('/data/ai-stack/'):
            raise RuntimeError('Montagem nao prevista. Nenhum volume foi alterado.')
        v={'type':'bind','source':m['Source'],'target':target,'read_only':bool(m.get('ReadOnly')), 'bind':{'create_host_path':False}}
        if (m.get('BindOptions') or {}).get('Propagation'): v['bind']['propagation']=m['BindOptions']['Propagation']
        vols.append(v)
    if not any(v.get('target')=='/paperclip' for v in vols): raise RuntimeError('Volume /paperclip nao consta na definicao do servico.')
    labels={k:v for k,v in p['Spec'].get('Labels',{}).items() if k.startswith('traefik.') and not k.startswith(('traefik.swarm.','traefik.docker.'))}
    if not any(k.endswith('.rule') and 'agents.inovacao.sharksolucoes.com.br' in v for k,v in labels.items()): raise RuntimeError('Rota HTTPS do Paperclip nao encontrada nos labels do Swarm.')
    if not any(k.endswith('.loadbalancer.server.port') and str(v)=='3100' for k,v in labels.items()): raise RuntimeError('Porta Traefik 3100 nao identificada.')
    # References to explicitly scoped middleware or services are left alone except
    # for names which move with this same service; retain references to other providers.
    local_defs={k.split('.')[3] for k in labels if len(k.split('.'))>4 and k.startswith(('traefik.http.middlewares.','traefik.http.services.','traefik.http.serverstransports.'))}
    for k,v in list(labels.items()):
        if k.endswith(('.middlewares','.service','.serverstransport')):
            labels[k]=','.join((part[:-6]+'@docker' if part.endswith('@swarm') and part[:-6] in local_defs else part) for part in v.split(','))
    labels.update({'traefik.enable':'true','traefik.docker.network':'ai_public','shark.traefik.standalone':'true'})
    ts=spec(t); args=ts.get('Args') or []
    if not any(a.lower().startswith('--providers.swarm') for a in args): raise RuntimeError('Traefik nao usa argumentos CLI Swarm esperados; exige ajuste manual.')
    if any(a.lower().startswith('--providers.docker') for a in args): raise RuntimeError('Provider Docker ja configurado; revisar restricoes antes da migracao.')
    if any(a.lower().startswith('--configfile') for a in args): raise RuntimeError('Traefik usa arquivo de configuracao; exige ajuste manual.')
    if not any(m.get('Destination')=='/var/run/docker.sock' for m in tc.get('Mounts',[])): raise RuntimeError('Socket Docker local nao identificado no Traefik.')
    additions=['--providers.docker=true','--providers.docker.exposedbydefault=false','--providers.docker.network=ai_public','--providers.docker.constraints=Label(`shark.traefik.standalone`,`true`)']
    new_args=args+additions
    for n in ('ai_public','ai_ai_backend'):
        if not existing_network(n): raise RuntimeError(f'Rede {n} nao encontrada.')
    pub=json.loads(dock('network','inspect','ai_public'))[0]
    if not pub.get('Attachable'): raise RuntimeError('ai_public precisa ser attachable.')
    if existing_network(NETWORK): raise RuntimeError('Rede dedicada ja existe; nao sera reutilizada automaticamente.')
    # Resolve original service/network keys without displaying secrets.
    stack=json.loads(dock('compose','--project-directory',str(ROOT),'-p','ai','-f',str(ROOT/'stack.yml'),'config','--format','json'))
    services=stack['services']; networks=stack['networks']
    for n in ('paperclip','postgres','traefik'):
        if n not in services: raise RuntimeError(f'Servico {n} nao encontrado no stack.yml.')
    backend_keys=[k for k,v in networks.items() if v.get('name')=='ai_ai_backend']
    if len(backend_keys)!=1: raise RuntimeError('Chave da rede backend no stack.yml nao identificada.')
    pg_nets=services['postgres'].get('networks',{}) or {}
    if isinstance(pg_nets,list): pg_nets={k:{} for k in pg_nets}
    if backend_keys[0] not in pg_nets: raise RuntimeError('Rede atual do PostgreSQL nao corresponde ao stack.yml.')
    # Build the dedicated Compose spec from the live container, not guessed env.
    svc={'image':IMAGE,'container_name':NAME,'user':'1000:1000','restart':'unless-stopped',
         'environment':env,'volumes':vols,'cap_drop':['ALL'],'security_opt':['no-new-privileges=true','apparmor=shark-paperclip-container',f'seccomp={SANDBOX}/paperclip-seccomp.json'],
         'networks':{'public':{'aliases':['shark-paperclip-runtime'],'gw_priority':1},'backend':{'aliases':['paperclip','ai_paperclip']}},
         'labels':labels,'stop_grace_period':'90s','pull_policy':'never'}
    if cfg.get('Entrypoint'): svc['entrypoint']=cfg['Entrypoint']
    if cfg.get('Cmd'): svc['command']=cfg['Cmd']
    if cfg.get('WorkingDir'): svc['working_dir']=cfg['WorkingDir']
    if hc.get('ReadonlyRootfs'): svc['read_only']=True
    if hc.get('Memory'): svc['mem_limit']=str(hc['Memory'])
    resources=p['Spec']['TaskTemplate'].get('Resources',{}).get('Limits',{})
    if resources.get('NanoCPUs'): svc['cpus']=str(resources['NanoCPUs']/1e9)
    if hc.get('PidsLimit',0) and hc['PidsLimit']>0: svc['pids_limit']=hc['PidsLimit']
    if cfg.get('Healthcheck'):
        health=cfg['Healthcheck']; h={}
        if health.get('Test'): h['test']=health['Test']
        for field, dest in [('Interval','interval'),('Timeout','timeout'),('StartPeriod','start_period'),('StartInterval','start_interval')]:
            if health.get(field): h[dest]=str(health[field])+'ns'
        if health.get('Retries'): h['retries']=health['Retries']
        svc['healthcheck']=h
    doc={'services':{'paperclip':svc},'networks':{'public':{'external':True,'name':'ai_public'},'backend':{'external':True,'name':NETWORK}}}
    pg_nets={**pg_nets,NETWORK:{'aliases':[host]}}
    override={'version':'3.8','services':{'paperclip':{'deploy':{'replicas':0,'labels':{'traefik.enable':'false'}}},'postgres':{'networks':pg_nets},'traefik':{'command':new_args}},'networks':{NETWORK:{'external':True,'name':NETWORK}}}
    WORK.mkdir(mode=0o700,parents=True,exist_ok=True); os.chmod(WORK,0o700)
    shutil.copyfile(ROOT/'stack.yml', WORK/'stack.original.yml'); os.chmod(WORK/'stack.original.yml',0o600)
    write_json(COMPOSE,escape(doc)); write_json(OVERRIDE,escape(override))
    compose('config','--quiet')
    write_json(STATE,{'old_args':args,'new_args':new_args,'db_alias':host,'old_enable':p['Spec'].get('Labels',{}).get('traefik.enable'),'paperclip_image':sc['Image'],'paperclip_spec_version':p['Version']['Index'],'postgres_spec_version':d['Version']['Index'],'traefik_spec_version':t['Version']['Index']})
    print('Preparacao concluida. Nenhum servico foi alterado. Arquivos sensiveis protegidos em',WORK)
    print('Proxima etapa: validar a configuracao e executar apply em janela de manutencao.')

def wait_old_stopped():
    for _ in range(60):
        if not dock('ps','-q','--filter','label=com.docker.swarm.service.name=ai_paperclip'): return
        time.sleep(2)
    raise RuntimeError('Paperclip Swarm ainda possui container ativo; nao iniciar o Compose.')

def backup():
    db=cid_for('ai_postgres'); out=ROOT/'backups'; out.mkdir(mode=0o700,exist_ok=True)
    path=out/('paperclip-pre-compose-'+time.strftime('%Y%m%d-%H%M%S')+'.dump')
    with path.open('wb') as f:
        rc=subprocess.run(['docker','exec',db,'pg_dump','-U','paperclip','-d','paperclip','-Fc'],stdout=f).returncode
    if rc or not path.stat().st_size: raise RuntimeError('Backup falhou; migracao abortada.')
    with path.open('rb') as f:
        if subprocess.run(['docker','exec','-i',db,'pg_restore','-l'],stdin=f,stdout=subprocess.DEVNULL).returncode: raise RuntimeError('Catalogo do backup invalido.')
    print('Backup com catalogo validado:',path,flush=True)

def apply():
    s=json.loads(STATE.read_text())
    for name,k in [('ai_paperclip','paperclip'),('ai_postgres','postgres'),('ai_traefik','traefik')]:
        if service(name)['Version']['Index']!=s[k+'_spec_version']: raise RuntimeError(f'Servico {name} mudou apos prepare; revisar antes da migracao.')
    if existing_network(NETWORK): raise RuntimeError('Rede dedicada ja existe. Use rollback se houve tentativa anterior.')
    assert_idle(); backup(); assert_idle()
    if input('Janela autorizada, sem novos trabalhos/triggers? Digite MIGRAR: ')!='MIGRAR': raise RuntimeError('Cancelado.')
    assert_idle()
    # Save intent before any changes; rollback checks the live state.
    (WORK/'migration.started').touch(mode=0o600)
    dock('network','create','--driver','overlay','--attachable','--internal',NETWORK,capture=False)
    # Create only; do not start against the same database as the former controller.
    compose('create','--no-build',capture=False)
    assert_idle()
    dock('service','update','--no-resolve-image','--detach=false','--replicas','0','--label-add','traefik.enable=false','ai_paperclip',capture=False)
    wait_old_stopped()
    print('Paperclip Swarm parado. Volumes existentes serao reutilizados sem copia ou alteracao.',flush=True)
    dock('service','update','--no-resolve-image','--detach=false','--network-add',f'name={NETWORK},alias={s["db_alias"]}','ai_postgres',capture=False)
    # Wait for the existing database to accept connections, without modifying schema.
    for _ in range(60):
        try:
            db=cid_for('ai_postgres'); dock('exec',db,'pg_isready','-U','paperclip','-d','paperclip'); break
        except RuntimeError: time.sleep(2)
    else: raise RuntimeError('PostgreSQL nao ficou pronto; execute rollback.')
    dock('service','update','--no-resolve-image','--detach=false','--args',shlex.join(s['new_args']),'ai_traefik',capture=False)
    compose('up','-d','--no-build','--pull','never',capture=False)
    print('Container dedicado iniciado. Valide saude local, HTTPS e o sandbox antes de retomar tarefas.',flush=True)
    print('Use status. Se falhar, execute rollback; nao suba outro Paperclip em paralelo.')

def status():
    dock('stack','services','ai',capture=False)
    compose('ps','-a',capture=False)
    if NAME in dock('ps','--format','{{.Names}}').splitlines():
        dock('inspect',NAME,'--format','User={{.Config.User}} AppArmor={{.AppArmorProfile}} CapDrop={{json .HostConfig.CapDrop}}',capture=False)
        dock('exec','--user','node',NAME,'sh','-c','grep -E "CapEff|NoNewPrivs|Seccomp" /proc/self/status; cat /proc/self/attr/current; bwrap --unshare-user --unshare-net --ro-bind / / /bin/true && echo BUBBLEWRAP_OK',capture=False)
        dock('exec',NAME,'node','-e','fetch("http://127.0.0.1:3100/api/health").then(r=>{console.log("HTTP local:",r.status);process.exitCode=r.ok?0:1}).catch(e=>{console.error(e.message);process.exitCode=1})',capture=False)

def rollback():
    s=json.loads(STATE.read_text())
    if not (WORK/'migration.started').exists(): raise RuntimeError('Nenhuma migracao iniciada.')
    assert_idle()
    if input('Parar Compose e restaurar Swarm? Digite VOLTAR: ')!='VOLTAR': raise RuntimeError('Cancelado.')
    assert_idle()
    compose('down',capture=False)
    if NAME in dock('ps','--format','{{.Names}}').splitlines(): raise RuntimeError('Container dedicado ainda ativo; nao iniciar Swarm.')
    t=service('ai_traefik')
    if (spec(t).get('Args') or [])!=s['old_args']:
        if (spec(t).get('Args') or [])!=s['new_args']: raise RuntimeError('Traefik mudou por outro motivo; rollback manual necessario.')
        dock('service','update','--no-resolve-image','--detach=false','--args',shlex.join(s['old_args']),'ai_traefik',capture=False)
    if existing_network(NETWORK):
        net=json.loads(dock('network','inspect',NETWORK))[0]['Id']
        if any(x['Target']==net for x in service('ai_postgres')['Spec']['TaskTemplate'].get('Networks',[])):
            dock('service','update','--no-resolve-image','--detach=false','--network-rm',NETWORK,'ai_postgres',capture=False)
    flags=['--label-rm','traefik.enable'] if s['old_enable'] is None else ['--label-add','traefik.enable='+s['old_enable']]
    dock('service','update','--no-resolve-image','--detach=false','--image',s['paperclip_image'],'--replicas','1',*flags,'ai_paperclip',capture=False)
    if existing_network(NETWORK): dock('network','rm',NETWORK,capture=False)
    (WORK/'migration.started').unlink()
    print('Swarm restaurado. O agente continua configurado com o adaptador nativo; o erro original do sandbox pode retornar.')

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('action',choices=('prepare','apply','status','rollback')); a=parser.parse_args()
    if os.geteuid()!=0: raise RuntimeError('Execute como root.')
    {'prepare':prep,'apply':apply,'status':status,'rollback':rollback}[a.action]()

if __name__=='__main__':
    try: main()
    except (RuntimeError,OSError,ValueError,KeyError) as e:
        print('ABORTADO:',str(e),file=sys.stderr); sys.exit(1)
